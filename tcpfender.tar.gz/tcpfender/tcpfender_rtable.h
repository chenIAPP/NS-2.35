/*
 * tcpfender_rtable.h
 *
 *  Created on: 2015-07-21
 *      Author: winemocol
 */

#ifndef TCPFENDER_RTABLE_H_
#define TCPFENDER_RTABLE_H_

#include <trace.h>

#include <map>

typedef std::map<nsaddr_t, nsaddr_t> rtable_t;

class tcpfender_rtable {

   rtable_t rt_;

   public:

   tcpfender_rtable();

   void print(Trace*);

   void clear();

   void rm_entry(nsaddr_t);

   void add_entry(nsaddr_t, nsaddr_t);

   nsaddr_t lookup(nsaddr_t);

   u_int32_t size();

};

#endif /* TCPFENDER_RTABLE_H_ */

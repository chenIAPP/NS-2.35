/*
 * tcpfender.h
 *
 *  Created on: 2015-07-21
 *      Author: winemocol
 */

#ifndef TCPFENDER_H_
#define TCPFENDER_H_


 #include "tcpfender_pkt.h" //数据包报头

#include "tcpfender_rtable.h"

#include <agent.h>  //代理基本类

#include <packet.h> //数据包类

#include <trace.h> //跟踪类，用于在跟踪文件里记录输出的仿真结果

#include <timer-handler.h> //计时器基本类，创建我们自定义的计时器

#include <random.h> //随机类，用于产生伪随机数

#include <classifier-port.h> //端口分类器类，用于淘汰向上层传输的数据包

#include <mobilenode.h>

#include "arp.h"

#include "ll.h"

#include "mac.h"

#include "ip.h"

#include "delay.h"

#define CURRENT_TIME Scheduler::instance().clock() //定义了一个用于得到当前仿真时间的宏

        //通过一个调度类的实例完成

#define JITTER (Random::uniform()*0.5) //在0-0.5之间去随机数作为发送数据的延迟时间

class Tcpfender; // forward declaration

/* Timers */   //自定义计时器发送定时的控制包

class Tcpfender_PktTimer : public TimerHandler {

    public:

	Tcpfender_PktTimer(Tcpfender* agent) : TimerHandler() {

        agent_ = agent;

    }

    protected:

	Tcpfender* agent_;

    virtual void expire(Event* e);

};

class Tcpfender : public Agent {

    /* Friends */

    friend class Tcpfender_PktTimer;

     /* Private members */ //封装了自身的地址、内状态、路由表、可变的Tcl

                                       //以及一个负责指定输出数量的计数器

    nsaddr_t ra_addr_;

    tcpfender_rtable rtable_;

    int accesible_var_; //用来读取Tcl代码或脚本语言

    u_int8_t seq_num_;

 protected:

     MobileNode* node_;

     PortClassifier* dmux_; // For passing packets up to agents.端口分类器

     Trace* logtarget_; // For logging.跟踪器

     Tcpfender_PktTimer pkt_timer_; // Timer for sending packets.自定义计时器

    //内部属性

     inline nsaddr_t& ra_addr() { return ra_addr_; }

     inline int& accessible_var() { return accesible_var_; }

     void forward_data(Packet*); //数据包被正确传输的目的地

     void recv_tcpfender_pkt(Packet*);

     void send_tcpfender_pkt();

     void reset_tcpfender_pkt_timer();

 public:

     Tcpfender(nsaddr_t);

     int command(int, const char*const*);

     void recv(Packet*, Handler*);

};


#endif /* TCPFENDER_H_ */

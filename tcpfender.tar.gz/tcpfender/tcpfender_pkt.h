/*
 * tcpfender_pkt.h
 *
 *  Created on: 2015-07-21
 *      Author: winemocol
 */

#ifndef TCPFENDER_PKT_H_
#define TCPFENDER_PKT_H_

#define TCPFENDER_DATA  	0x01

#include <packet.h>

 #define HDR_T_PKT(p) hdr_tcpfender_pkt::access(p)

 struct hdr_tcpfender_pkt {

    nsaddr_t pkt_src_; // Node which originated this packet

    u_int16_t pkt_len_; // Packet length (in bytes)

    u_int8_t pkt_seq_num_; // Packet sequence number

    u_int8_t        data_type;

    inline nsaddr_t& pkt_src() { return pkt_src_; }

    inline u_int16_t& pkt_len() { return pkt_len_; }

    inline u_int8_t& pkt_seq_num() { return pkt_seq_num_; }

    static int offset_;

    inline static int& offset() { return offset_; }

    inline static hdr_tcpfender_pkt* access(const Packet* p) {

           return (hdr_tcpfender_pkt*)p->access(offset_);

    }

};

#endif /* TCPFENDER_PKT_H_ */

/*
 * more_op.cc
 *
 *  Created on: 2015-09-21
 *      Author: winemocol
 */

#include "more_op.h"
#include "ip.h"
#include "udp.h"
#include <packet.h>
#include "tcp.h"

More_op::More_op()
{
	setReceiveAndForwardList();
}

void
More_op::setReceiveAndForwardList()
{
	//node 0;
	node_0.forwarderList[0] = 1;node_0.forwarderList[1] = 2;node_0.forwarderList[2] = 3;

	//node 1
	node_1.receiveList[0] = 0;
	node_1.forwarderList[0] = 2;node_1.forwarderList[1] = 3;node_1.forwarderList[2] = 4;

	//node 2
	node_2.receiveList[0] = 0;node_2.receiveList[1] = 1;
	node_2.forwarderList[0] = 3;node_2.forwarderList[1] = 4;node_2.forwarderList[2] = 5;

	//node 3
	node_3.receiveList[0] = 0;node_3.receiveList[1] = 1;node_3.receiveList[2] = 2;
	node_3.forwarderList[0] = 4;node_3.forwarderList[1] = 5;

	//node 4
	node_4.receiveList[0] = 1;node_4.receiveList[1] = 2;node_4.receiveList[2] = 3;
	node_4.forwarderList[0] = 5;

	//node 5
	node_5.receiveList[0] = 2;node_5.receiveList[1] = 3;node_5.receiveList[2] = 4;
}

void
More_op::updateOverhearList(const Packet* p,int ReceiverIndex)
{
	struct hdr_cmn* ch = HDR_CMN(p);
    int senderIndex = ch->prev_hop_;
    More_neighborInfo receiverNode = getNode(ReceiverIndex);

    for(int i=0;i<10;i++)
    {
    	int index_receive = receiverNode.receiveList[i];
    	int index_forwarder = receiverNode.forwarderList[i];

    	if(index_receive == senderIndex)
    	{
    		receiverNode.overhearReceiveList[i] = 1;
    		break;
    	}

    	if(index_forwarder == senderIndex)
    	{
    		receiverNode.overhearForwardList[i] = 1;
    		break;
    	}
    }

}


int
More_op::getBackoffTime(const Packet* p,int ReceiverIndex)
{
	int backOffTime= 0;
	//printf("rece=%d\n",getReceiveListBackoffTime(p,ReceiverIndex));
	//printf("send=%d\n",getForwarderListBackoffTime(p,ReceiverIndex));
	backOffTime = getReceiveListBackoffTime(p,ReceiverIndex)
			+getForwarderListBackoffTime(p,ReceiverIndex);
    return backOffTime;
}

int
More_op::getReceiveListBackoffTime(const Packet* p,int ReceiverIndex)
{
	struct hdr_cmn* ch = HDR_CMN(p);
    int senderIndex = ch->prev_hop_;
    if(senderIndex > ReceiverIndex) return 0;
    int backOffValue = 0;
    More_neighborInfo receiverNode = getNode(ReceiverIndex);

    for(int i=0;i<10;i++)
    {
    	int index_receive = receiverNode.receiveList[i];// current node receiveList
    	if(index_receive == senderIndex)
    	{
    		// sender is belong to receive list
    		return backOffValue;
    	}
    	else if(index_receive == 100)
    	{
    		continue;
    	}
    	else //if (index_receive != senderIndex)
    	{
    		//printf("j=%d\n",i);
    		backOffValue++;
    	}
    }
    return 100;
}


int
More_op::getForwarderListBackoffTime(const Packet* p,int ReceiverIndex)
{
	struct hdr_cmn* ch = HDR_CMN(p);
    int senderIndex = ch->prev_hop_;
    if(senderIndex > ReceiverIndex) return 0;
    int backOffValue = 0;
    More_neighborInfo senderNode = getNode(senderIndex);

    for(int i=9;i>=0;i--)
    {
	   int index_forwarder = senderNode.forwarderList[i];// send forwardList;
	  // printf("index_forwarder=%d\n",index_forwarder);
	   if(index_forwarder == ReceiverIndex)
	   {
    		// sender is belong to receive list
		   return backOffValue;
	   }
	   else if(index_forwarder == 100)
	   {
		   continue;
	   }
	   else //if (index_receive != senderIndex)
	   {
		   	//printf("j=%d\n",i);
    		backOffValue++;
	   }
    }
    return backOffValue;
}

int
More_op::getScheduleBackoffTime(const Packet* p,int ReceiverIndex)
{
	struct hdr_cmn* ch = HDR_CMN(p);
    int senderIndex = ch->prev_hop_;
    if(senderIndex < ReceiverIndex) return 0;
    else
    return senderIndex-ReceiverIndex;
}

int
More_op::sendTransmissionTime(int SenderIndex)
{
	More_neighborInfo senderNode = getNode(SenderIndex);

	int backOffValue = 0;

    for(int i=9;i>=0;i--)
    {
	   int index_forwarder = senderNode.forwarderList[i];// send forwardList;

	   if(index_forwarder == 100)
	   {
		   continue;
	   } else {
    		backOffValue++;
	   }
    }

    return backOffValue;
}

More_neighborInfo
More_op::getNode(int index)
{
	if(index == 0)
		return node_0;
	else if(index == 1)
	{
		return node_1;
	}
	else if(index == 2)
	{
		return node_2;
	}
	else if(index == 3)
	{
		return node_3;
	}
	else if(index == 4)
	{
		return node_4;
	}
	else if(index == 5)
	{
		return node_5;
	}
	else if(index == 6)
	{
		return node_6;
	}
	else if(index == 7)
	{
		return node_7;
	}
	else if(index == 8)
	{
		return node_8;
	}
	else if(index == 9)
	{
		return node_9;
	}
	else if(index == 10)
	{
		return node_10;
	}
	else if(index == 11)
	{
		return node_11;
	}
	else
		return node_0;
}

int
More_op::checkstate(const Packet* p,int index)
{
    struct hdr_cmn* ch = HDR_CMN(p);

    switch (ch->ptype_)
    {
		case PT_CBR:

	    if(index == sourceIndex&& ch->prev_hop_ == 0)
	    {
	    	return 0;// source receive data packet
	    }
	    else if(index == sourceIndex&& ch->prev_hop_ > 0)
	    {
	    	return 1; // source receive downstream data ;
	    }
	    else if (index == destinationIndex)
	    {
	    	return 2;
	    }
	    else
	    {
	    	if(ch->prev_hop_ < index)
	    	{
	    		return 3; //intermediate node receive data packets
	    	}
	    	else if(ch->prev_hop_ > index)
	    	{
	    		return 4;// intermediate node receive downstream data packets
	    	}
	    	else
	    	{
	    		printf("nodes receive error packets\n");
	    	}
	    }
	    break;

	case PT_ACK:

	    if(index == sourceIndex)
	    {
	    	return 5;// source ndoe receive ack
	    }
	    else if (index == destinationIndex){
	    	printf("destination nodes receive ack packets\n");
	    }
	    else
	    {
	    	return 6;//intermediate node receive ack
	    }

	    break;

	default:
		printf("TCPFender_flow------packet type error------------------------------"
		"----------------------\n");
	    break;
    }


	return 1;
}



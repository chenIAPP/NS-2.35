/*
 * more_pkt.h
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */

#ifndef MORE_PKT_H_
#define MORE_PKT_H_




#define MORETYPE_HELLO  	0x01
#define MORETYPE_RREQ   	0x02
#define MORETYPE_RREP   	0x04
#define MORETYPE_RERR   	0x08
#define MORETYPE_RREP_ACK  	0x10
#define MORETYPE_DATA	  	0x12

#include <packet.h>

#define HDR_MORE_PKT(p) hdr_more_pkt::access(p)
#define HDR_MORE_REQUEST(p)  	((struct hdr_more_request*)hdr_more_pkt::access(p))
#define HDR_MORE_REPLY(p)	((struct hdr_more_reply*)hdr_more_pkt::access(p))
#define HDR_MORE_ERROR(p)	((struct hdr_more_error*)hdr_more_pkt::access(p))
#define HDR_MORE_RREP_ACK(p)	((struct hdr_more_rrep_ack*)hdr_more_pkt::access(p))

struct hdr_more_pkt {

	u_int8_t        more_type;

	nsaddr_t pkt_src_;  // Node which originated this packet

	u_int16_t pkt_len_; //Packet length (in bytes)

	u_int32_t newPacketIndex_; //correspond to each node,

	u_int32_t current_batch_;

	u_int32_t max_received_batch_;

	u_int32_t pkt_round_;

	u_int32_t pkt_batch_num_;

	int num_for_currentBatch;

	// For ExOR
	//u_int16_t max_rec_num;
	u_int16_t cur_wait_num;


	int num_for_eachBatch_0;
	int num_for_eachBatch_1;
	int num_for_eachBatch_2;
	int num_for_eachBatch_3;
	int num_for_eachBatch_4;
	int num_for_eachBatch_5;
	int num_for_eachBatch_6;
	int num_for_eachBatch_7;
	int num_for_eachBatch_8;
	int num_for_eachBatch_9;

	int round_Batch_0;
	int round_Batch_1;
	int round_Batch_2;
	int round_Batch_3;
	int round_Batch_4;
	int round_Batch_5;
	int round_Batch_6;
	int round_Batch_7;
	int round_Batch_8;
	int round_Batch_9;


	static int offset_;

	inline nsaddr_t& pkt_src() {return pkt_src_;}

	inline u_int16_t& pkt_len() { return pkt_len_;}

	inline u_int32_t& newPacketIndex() { return newPacketIndex_;}

	inline u_int32_t& current_batch() { return current_batch_;}

	inline u_int32_t& max_received_batch() { return max_received_batch_;}

	inline u_int32_t& pkt_round() { return pkt_round_;}

	inline u_int32_t& pkt_batch_num() { return pkt_batch_num_;}

	inline static int& offset() { return offset_;}

	inline static hdr_more_pkt * access (const Packet*p) {
		return (hdr_more_pkt*) p->access(offset_);
	}

};

struct hdr_more_request {
        u_int8_t        more_type;	// Packet Type
        u_int8_t        reserved[2];
        u_int8_t        rq_hop_count;   // Hop Count
        u_int32_t       rq_bcast_id;    // Broadcast ID

        nsaddr_t        rq_dst;         // Destination IP Address
        u_int32_t       rq_dst_seqno;   // Destination Sequence Number
        nsaddr_t        rq_src;         // Source IP Address
        u_int32_t       rq_src_seqno;   // Source Sequence Number

        double          rq_timestamp;   // when REQUEST sent;
					// used to compute route discovery latency
  inline int size() {
  int sz = 0;
  	sz = 7*sizeof(u_int32_t);
  	assert (sz >= 0);
	return sz;
  }
};

struct hdr_more_reply {
        u_int8_t        more_type;        // Packet Type

        u_int8_t		rp_batch_num;

        u_int8_t		rp_token_num;

        u_int8_t        reserved[2];
        u_int8_t        rp_hop_count;           // Hop Count
        nsaddr_t        rp_dst;                 // Destination IP Address
        u_int32_t       rp_dst_seqno;           // Destination Sequence Number
        nsaddr_t        rp_src;                 // Source IP Address
        double	        rp_lifetime;            // Lifetime

        double          rp_timestamp;           // when corresponding REQ sent;
						// used to compute route discovery latency

  inline int size() {
  int sz = 0;
  	sz = 6*sizeof(u_int32_t);
  	assert (sz >= 0);
	return sz;
  }

};


struct hdr_more_error {
        u_int8_t        more_type;                // Type
        u_int8_t        reserved[2];            // Reserved
        u_int8_t        DestCount;                 // DestCount
        // List of Unreachable destination IP addresses and sequence numbers
        nsaddr_t        unreachable_dst[100];
        u_int32_t       unreachable_dst_seqno[100];

  inline int size() {
  int sz = 0;
  	sz = (DestCount*2 + 1)*sizeof(u_int32_t);
	assert(sz);
        return sz;
  }

};

struct hdr_more_rrep_ack {
	u_int8_t	more_type;
	u_int8_t	reserved;
};

union hdr_all_more {
	hdr_more_pkt          more_data;
	hdr_more_request  more_request;
	hdr_more_reply    more_reply;
	hdr_more_error    more_error;
	hdr_more_rrep_ack more_ack;
};
#endif /* MORE_PKT_H_ */




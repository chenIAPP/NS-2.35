/*
 * more_batch.cc
 *
 *  Created on: 2014-08-25
 *      Author: winemocol
 */

#include "more_batch.h"
#include "more_rqueue.h"

More_batch::More_batch(int size)
{
	generation_size = size;
}

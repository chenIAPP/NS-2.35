/*
 * more_rtable.h
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */

#ifndef MORE_RTABLE_H_
#define MORE_RTABLE_H_


#include <trace.h>
#include "config.h"
#include "scheduler.h"
#include "queue.h"
#include <map>

typedef std::map<nsaddr_t, nsaddr_t> rtable_t;

class more_rtable {

	rtable_t rt_;

public:

	more_rtable();

	void print (Trace*);

	void clear();

	void rm_entry(nsaddr_t);

	void add_entry(nsaddr_t, nsaddr_t);

	nsaddr_t lookup(nsaddr_t);

	u_int32_t size();
};


class neighbor_rtable_ent {
public:
	neighbor_rtable_ent() { bzero(this, sizeof(neighbor_rtable_ent));}
	  nsaddr_t     			neighbor_address;     // destination

	  unsigned int         	ETX;  // distance, default value is 1
	  unsigned int			receivedHelloMessageNumber;
	  unsigned int        	seqnum;  // last sequence number we saw
	  double       			received_time; // when receive the hello message or request
	  double 				last_received_time;
	  bool					sendDetectACK;
	  double 				sendDetectACK_time;

};


class neighbor_rtable
{
public:
		neighbor_rtable();
		void AddEntry(neighbor_rtable_ent *ent);
//		int RemainingLoop();
//		void InitLoop();
//		rtable_ent *NextLoop();
//		rtable_ent *GetEntry(nsaddr_t dest);
		bool IsNewEntry(nsaddr_t senderAddress);
		void UpdateEntry(nsaddr_t senderAddress,neighbor_rtable_ent* tmp);
		neighbor_rtable_ent* GetEntryByAddress(nsaddr_t senderAddress);

		neighbor_rtable_ent		 *rtab;
		int         			maxelts;
		int         			elts;
		int         			ctr;
};


#endif /* MORE_RTABLE_H_ */


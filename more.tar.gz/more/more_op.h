/*
 * more_op.h
 *
 *  Created on: 2015-09-21
 *      Author: winemocol
 */

#ifndef MORE_OP_H_
#define MORE_OP_H_

#include "more_neighborNode.h"
#include "more_pkt.h"
class More_op
{
	public:
	More_op();

	int sourceIndex;
	int destinationIndex;

	More_neighborInfo node_0;
	More_neighborInfo node_1;
	More_neighborInfo node_2;
	More_neighborInfo node_3;
	More_neighborInfo node_4;
	More_neighborInfo node_5;
	More_neighborInfo node_6;
	More_neighborInfo node_7;
	More_neighborInfo node_8;
	More_neighborInfo node_9;
	More_neighborInfo node_10;
	More_neighborInfo node_11;

	More_neighborInfo getNode(int index);

	void setReceiveAndForwardList();

	void updateOverhearList(const Packet* p,int ReceiverIndex);

	int checkstate(const Packet* p,int index);

	int getBackoffTime(const Packet* p,int ReceiverIndex);

	int getScheduleBackoffTime(const Packet* p,int ReceiverIndex);

	int getReceiveListBackoffTime(const Packet* p,int ReceiverIndex);

	int getForwarderListBackoffTime(const Packet* p,int ReceiverIndex);

	int sendTransmissionTime(int SenderIndex);
};

#endif /* MORE_OP_H_ */

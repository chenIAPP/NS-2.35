/*
 * more_neighborNode.h
 *
 *  Created on: 2014-08-26
 *      Author: winemocol
 */

#ifndef MORE_NEIGHBORNODE_H_
#define MORE_NEIGHBORNODE_H_

//#include "more_node.h"
//#include "more_loss.h"


class More_neighborInfo
{
public:
	More_neighborInfo();

	int receiveList[10];
	int forwarderList[10];

	int overhearReceiveList[10];
	int overhearForwardList[10];

	//void setReceiveList(int receiveListArray[]);
	//void setForwardList(int forwarderListArray[]);
//	int indexOfnode;
//
//	int num_downSteamNeighbor;
//
//	int transmission_factor;
//
//	double etx_for_current_node;
//
//	double redundance_factor;
//
//	double redundance_credit;
//
//	More_loss loss_object;
//
//	More_node downsteam_nodes[20];
//
//	More_node upsteam_nodes[20];
//
//	void setIndex(int index);
//
//	void initialDefaultLossRatio(int index);
//
//	void updateDownSteamNodeInfor(int node, int lastPacket, int numFromLatest,double etx_value);
//
//	void updateUpsteamNodeInfor(int node,int latestPacket);
//
//	void updateSinglePathLossInfo(int node);
//
//	void updateLossInfor(int index);
//
//	void updateDeliverRatioOFDownStreamNodeForUpStreamNodes(int downnode, int lastPacket, int numFromLatest,int upnode);
//
//	double downSteamNodes[20];
//
//	double downSteamNodesETX[20];
//
//	int downSteamNodesIndex[20];

};

#endif /* MORE_NEIGHBORNODE_H_ */

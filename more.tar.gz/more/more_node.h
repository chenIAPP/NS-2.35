/*
 * more_node.h
 *
 *  Created on: 2014-08-25
 *      Author: winemocol
 */

#ifndef MORE_NODE_H_
#define MORE_NODE_H_

#include "more_batch.h"



class More_node
{
public:
	More_node();

	int indexOfnode;

	double default_deliver_ratio;

	double current_deliver_ratio;

// it used for sending  --- increase after sending a packet, it is equal to the current sequence number

	int the_number_of_total_packet_for_send;

// for receive

	int last_packet_sequence_number;

	int the_number_of_current_receive_packet;

	int previous_last_packet_sequence_number;

	int the_number_of_previous_receive_packet;

	double the_ETX_of_current_node;

	double default_the_ETX_of_current_node;

	//queue<More_batch> *batch_queue;

	double downsteamNodeDeliverRatio[20];

	int source_node_find_batchSize(double sourceETX,double maximunThroughput);

	void setIndex(int index);
};


#endif /* MORE_NODE_H_ */

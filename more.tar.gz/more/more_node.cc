/*
 * more_node.cc
 *
 *  Created on: 2014-08-25
 *      Author: winemocol
 */

#include "more_node.h"

More_node::More_node()
{

}

int
More_node::source_node_find_batchSize(double sourceETX,double maximunThroughput)
{
	return 10;
}

void
More_node::setIndex(int index)
{
	indexOfnode = index;
	//loss_object = new More_loss(index);
}


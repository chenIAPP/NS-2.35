/*
 * more_loss.h
 *
 *  Created on: 2014-08-25
 *      Author: winemocol
 */

#ifndef MORE_LOSS_H_
#define MORE_LOSS_H_

#include "more_node.h"

class More_loss
{
public:
	More_loss();

	int default_delivery_ratio;

	int indexOfnode;

	static const int value_threshold = 0.0;


	double update_Credit_factor(More_node upStreamNodes[20],More_node downSteamNodes[20],int index);


	double update_single_path_delivery(int lastSeq,int NumFromLast,int previousSeq, int NumFromPrevous,double current_deliver_ratio);

	double update_Redundance_factor(int numOfDownSteamNodes,double* downSteamNodes);

	double update_ETX_factor(int numOfDownSteamNodes,double* downSteamNodesETX,double* downSteamNodes);

	void setIndex(int index);
};

#endif /* MORE_LOSS_H_ */

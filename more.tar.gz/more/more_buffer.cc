/*
 * more_buffer.cc
 *
 *  Created on: 2014-11-12
 *      Author: winemocol
 */
#include "more_buffer.h"
More_buffer::More_buffer()
{

}

void
More_buffer::initizeMoreBuffer()
{
	sourceLastestACKedSequence = -1;
	sourceSendingGroupIndex = 0;
	sourceSendingValueInGroupIndex = 0;
	destinationReceiveLatestSequence = -1;
	currentGroupIndexInDestination = 0;
	codeingPacketNumber = 50;

	for(int i=0;i<100;i++)
	{
		sourceReceiveACKSequencArray[i] = -1;
	}

	for(int i=0;i<10;i++)
	{
		for(int j=0;j<codeingPacketNumber;j++)
		{
			sourceSendingQueueIndex[i][j] = 0;
		}
	}
}

void
More_buffer::initizeFlowNumber(int _indexOfCurrentNode,int _indexOfdestinationNode,int _indexOfSourceNode,int _indexOfPort)
{
	 indexOfCurrentNode =_indexOfCurrentNode;
	 indexOfdestinationNode=_indexOfdestinationNode;
	 indexOfSourceNode=_indexOfSourceNode;
	 indexOfPort=_indexOfPort;
}
more_rqueue
More_buffer::returnCurrentSendingQueueBySequence(int Sequence)
{
	for(int i =0;i<10;i++)
	{
		for(int j =0;j<codeingPacketNumber;j++)
		{
			if(sourceSendingQueueIndex[i][j] == Sequence)
			{
				if(i == 0)
					return rqueue_0;
				else if(i == 1)
				{
					return rqueue_1;
				}
				else if(i == 2)
				{
					return rqueue_2;
				}
				else if(i == 3)
				{
					return rqueue_3;
				}
				else if(i == 4)
				{
					return rqueue_4;
				}
				else if(i == 5)
				{
					return rqueue_5;
				}
				else if(i == 6)
				{
					return rqueue_6;
				}
				else if(i == 7)
				{
					return rqueue_7;
				}
				else if(i == 8)
				{
					return rqueue_8;
				}
				else if(i == 9)
				{
					return rqueue_9;
				}
				else
				{
					return rqueue_0;
					printf("return queue\n");
				}
			}
		}
	}

}

more_rqueue
More_buffer::returnCurrentSendingQueueByGroupIndex(int GroupIndex)
{
	if(GroupIndex == 0)
	{
		printf("return returnCurrentSendingQueueByGroupIndex 0\n");
		if(rqueue_0.lenghtofQueue() == codeingPacketNumber)rqueue_0.remove_all_packet();
		return rqueue_0;
	}
	else if(GroupIndex == 1)
	{
		printf("return 1\n");
		if(rqueue_1.lenghtofQueue() == codeingPacketNumber)rqueue_1.remove_all_packet();
		return rqueue_1;
	}
	else if(GroupIndex == 2)
	{
		printf("return 2\n");
		if(rqueue_2.lenghtofQueue() == codeingPacketNumber)rqueue_2.remove_all_packet();
		return rqueue_2;
	}
	else if(GroupIndex == 3)
	{
		printf("return 3\n");
		if(rqueue_3.lenghtofQueue() == codeingPacketNumber)rqueue_3.remove_all_packet();
		return rqueue_3;
	}
	else if(GroupIndex == 4)
	{
		printf("return 4\n");
		if(rqueue_4.lenghtofQueue() == codeingPacketNumber)rqueue_4.remove_all_packet();
		return rqueue_4;
	}
	else if(GroupIndex == 5)
	{
		printf("return 5\n");
		if(rqueue_5.lenghtofQueue() == codeingPacketNumber)rqueue_5.remove_all_packet();
		return rqueue_5;
	}
	else if(GroupIndex == 6)
	{
		printf("return 6\n");
		if(rqueue_6.lenghtofQueue() == codeingPacketNumber)rqueue_6.remove_all_packet();
		return rqueue_6;
	}
	else if(GroupIndex == 7)
	{
		printf("return 7\n");
		if(rqueue_7.lenghtofQueue() == codeingPacketNumber)rqueue_7.remove_all_packet();
		return rqueue_7;
	}
	else if(GroupIndex == 8)
	{
		printf("return 8\n");
		if(rqueue_8.lenghtofQueue() == codeingPacketNumber)rqueue_8.remove_all_packet();
		return rqueue_8;
	}
	else if(GroupIndex == 9)
	{
		printf("return 9\n");
		if(rqueue_9.lenghtofQueue() == codeingPacketNumber)rqueue_9.remove_all_packet();
		return rqueue_9;
	}
	else
	{
		return rqueue_0;
		printf("return queue\n");
	}
}

int
More_buffer::returnCurrentSendingGroupIndexBySequence(int Sequence)
{
	for(int i=0;i<10;i++)
	{
		for(int j=0;j<codeingPacketNumber;j++)
		{
			if(sourceSendingQueueIndex[i][j] == Sequence) return i;
		}
	}
}

void
More_buffer::increaseSeuquenceAndGroupIndexInDestiantion()
{
	printf("increaseSeuquenceAndGroupIndexInDestiantion---%d\n",currentGroupIndexInDestination);
	currentGroupIndexInDestination++;
	for(int i=currentGroupIndexInDestination;i<currentGroupIndexInDestination+9;i++)
	{
		printf("coming-------------i=%d\n",i);
		int j = i;
		if(i >= 10) j = i-10;
		more_rqueue queue = returnCurrentSendingQueueByGroupIndexInDestination(j);
		if(queue.lenghtofQueue() == codeingPacketNumber)
		{
			printf("increaseSeuquenceAndGroupIndexInDestiantion--queue.lenghtofQueue() == 10\n");
			currentGroupIndexInDestination++;
			destinationReceiveLatestSequence = destinationReceiveLatestSequence + codeingPacketNumber;
			queue.remove_all_packet();
			recoveSendingQueueByGroupIndexAndNewQueue(j,queue);
		}
		else if(queue.lenghtofQueue() < codeingPacketNumber)
		{
			printf("increaseSeuquenceAndGroupIndexInDestiantion--queue.lenghtofQueue() < 10--queue size==%d\n",queue.lenghtofQueue());
			destinationReceiveLatestSequence = destinationReceiveLatestSequence + queue.lenghtofQueue();
			break;
		}
		else
		{
			printf("increaseSeuquenceAndGroupIndexInDestiantion error\n");
		}
	}
	if(currentGroupIndexInDestination >= 10)currentGroupIndexInDestination = currentGroupIndexInDestination -10;
}
void
More_buffer::recoveSendingQueueByGroupIndexAndNewQueue(int GroupIndex,more_rqueue queue)
{
	if(GroupIndex == 0)
	{
		printf("return 0\n");
		rqueue_0 = queue;
	}
	else if(GroupIndex == 1)
	{
		printf("return 1\n");
		rqueue_1 = queue;;
	}
	else if(GroupIndex == 2)
	{
		printf("return 2\n");
		rqueue_2 = queue;
	}
	else if(GroupIndex == 3)
	{
		printf("return 3\n");
		rqueue_3 = queue;
	}
	else if(GroupIndex == 4)
	{
		printf("return 4\n");
		rqueue_4 = queue;
	}
	else if(GroupIndex == 5)
	{
		printf("return 5\n");
		rqueue_5 = queue;
	}
	else if(GroupIndex == 6)
	{
		printf("return 6\n");
		rqueue_6 = queue;
	}
	else if(GroupIndex == 7)
	{
		printf("return 7\n");
		rqueue_7 = queue;
	}
	else if(GroupIndex == 8)
	{
		printf("return 8\n");
		rqueue_8 = queue;
	}
	else if(GroupIndex == 9)
	{
		printf("return 9\n");
		rqueue_9 = queue;
	}
	else
	{
		rqueue_0 = queue;
		printf("return queue\n");
	}
}
void
More_buffer::showQueueSize()
{
	printf("queue in rqueue_0---------------%d\n",rqueue_0.lenghtofQueue());
	printf("queue in rqueue_1---------------%d\n",rqueue_1.lenghtofQueue());
	printf("queue in rqueue_2---------------%d\n",rqueue_2.lenghtofQueue());
	printf("queue in rqueue_3---------------%d\n",rqueue_3.lenghtofQueue());
	printf("queue in rqueue_4---------------%d\n",rqueue_4.lenghtofQueue());
	printf("queue in rqueue_5---------------%d\n",rqueue_5.lenghtofQueue());
	printf("queue in rqueue_6---------------%d\n",rqueue_6.lenghtofQueue());
	printf("queue in rqueue_7---------------%d\n",rqueue_7.lenghtofQueue());
	printf("queue in rqueue_8---------------%d\n",rqueue_8.lenghtofQueue());
	printf("queue in rqueue_9---------------%d\n",rqueue_9.lenghtofQueue());

}


more_rqueue
More_buffer::returnCurrentSendingQueueByGroupIndexInDestination(int GroupIndex)
{
	if(GroupIndex == 0)
	{
		printf("return returnCurrentSendingQueueByGroupIndex 0\n");

		return rqueue_0;
	}
	else if(GroupIndex == 1)
	{
		printf("return 1\n");

		return rqueue_1;
	}
	else if(GroupIndex == 2)
	{
		printf("return 2\n");

		return rqueue_2;
	}
	else if(GroupIndex == 3)
	{
		printf("return 3\n");

		return rqueue_3;
	}
	else if(GroupIndex == 4)
	{
		printf("return 4\n");

		return rqueue_4;
	}
	else if(GroupIndex == 5)
	{
		printf("return 5\n");

		return rqueue_5;
	}
	else if(GroupIndex == 6)
	{
		printf("return 6\n");

		return rqueue_6;
	}
	else if(GroupIndex == 7)
	{
		printf("return 7\n");

		return rqueue_7;
	}
	else if(GroupIndex == 8)
	{
		printf("return 8\n");

		return rqueue_8;
	}
	else if(GroupIndex == 9)
	{
		printf("return 9\n");

		return rqueue_9;
	}
	else
	{
		return rqueue_0;
		printf("return queue\n");
	}
}

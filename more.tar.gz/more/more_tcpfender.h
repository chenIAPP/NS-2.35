/*
 * more.h
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */

#ifndef MORE_H_
#define MORE_H_

#include "more_pkt.h" //数据包的头文件
#include "more_rtable.h"
#include "more_nc.h"
#include "more_rqueue.h"
#include "udp.h"
#include <agent.h> //代理基本类
#include <packet.h> //数据包类
#include <trace.h> //跟踪文件的描述类，里面定义了如何显示trace file的内容
#include <timer-handler.h> //计时器基本类，创建我们自定义的计时器
#include <random.h>
#include <classifier-port.h> //端口分类器，具体不清楚 **********
#include "scheduler.h"
#include <mobilenode.h>
#include "arp.h"
#include "ll.h"
#include "mac.h"
#include "ip.h"
#include "delay.h"
#include "more_timer.h"
#include "more_node.h"
#include "more_neighborNode.h"
#include "more_buffer.h"
#include "more_op.h"
#define CURRENT_TIME Scheduler::instance().clock()//定义一个得到当前时间的宏
#define JITTER (Random::uniform()*0.05)//返回一个0-0.5之间的随机数
#define NO_DELAY 0.0
#define HELLO_INTERVAL          1               // 1000 ms

class More;


class More : public Tap, public Agent {
    //default variable and function --begin
public:

	void tap(const Packet *p);

    nsaddr_t ra_addr_;
    more_rtable rtable_;
    int accessible_var_;//用来读取TCL代码或者脚本语言
    nsaddr_t        index;
    Trace* logtarget_;//写跟踪日志
    PortClassifier* dmux_;//把包向上传给agents,是端口分类器

    inline nsaddr_t& ra_addr(){
	    return ra_addr_;
    }

    inline int& accessible_var(){
	    return accessible_var_;
    }

    More(nsaddr_t);

    int command(int,const char*const*);

    void recv(Packet*, Handler*);


    //default variable and function --end

    //---------------------------------------------------------------------------------

    friend class WaitForReceivingNewpacketsFinishTimer;
    friend class WaitForReceivingACKpacketsFinishTimer;
    friend class WaitForHighPrioritySendingTimer;
    friend class DectinationACKWaitingTimer;
    //timer function  and variable begin

    void	WaitForReceivingNewpacketsFinishTimerHandler();
    void	WaitForReceivingACKpacketsFinishTimerHandler();
    void	WaitForHighPrioritySendingTimerHandler();
    void	DectinationACKWaitingTimerHandler();

    void resetNewPacketTimer();
    void resetHighPriorityTimer(Packet* p,int ReceiverIndex);
    void resetOverhearHighPriorityTimer(const Packet* p,int ReceiverIndex);
    void resetSendTimer();
    void resetRecevingAckTimer(Packet* p,int ReceiverIndex);
    void resetDestinationACKTimer(Packet* p);

    WaitForReceivingNewpacketsFinishTimer wrNewfTimer;
    WaitForReceivingACKpacketsFinishTimer wrAckTimer;
    WaitForHighPrioritySendingTimer wHighpsTimer;
    DectinationACKWaitingTimer destionACKTimer;


    //timer function end

    more_rqueue SR_Q;//source receive queue directly get packets from App layer.

    // more variable and function ---begin
    More_nc networkcoding;
    More_op op;

    double onePacketSendingDelay;
    double backoffpacketNum;

    int newpacketRound;
    int sendingOrWaitingIndex;

    int codeingPacketNumber;
    int totalNumberOfGroup;
    u_int8_t source_index;
    u_int8_t destination_index;
    int sourceSendPacketMAXSequence;
    int sourceReceivedMAXACKSequence;
    int sourceReceivedPacketMAXQueueIndex;

    int destinationReceivedPacketMAXSequence;
    int destinationReceivedMaxQueueIndex;

    int receiveNewPacketTimer;
    int	highPriorityNodesTimer;
    int NotSendingPacket;

    // 4 kinds of different parameters
    //int currentRoundValueInQueue[10];
    int receivedNewPacketNumberInQueue[10];
    int unAckedPackeNumberInQueue[10];

    int temporaryUnAckedPacketNumberInQueue[10];
    int temporaryUnAckedPacketNumberInFirQueue[11];
    int temporaryUnAckedPacketNumberInSecQueue[11];
    int temporaryUnAckedPacketNumberInThirQueue[11];

    int receivedPackeNumberInQueue[10];
    int requiredSendingPackeNumberInQueue[10];

    int finishedACKNumInQueue[10];
    int ACkedNumInQueue[10];

    int sendingPackeSequence[10];
    int sendinPacketRoundIndex[10];
    int packetretransmissionIndex;

    Packet* destinationLastReceivedPacket;


    more_rqueue rqueue_0;
    more_rqueue rqueue_1;
    more_rqueue rqueue_2;
    more_rqueue rqueue_3;
    more_rqueue rqueue_4;
    more_rqueue rqueue_5;
    more_rqueue rqueue_6;
    more_rqueue rqueue_7;
    more_rqueue rqueue_8;
    more_rqueue rqueue_9;

    more_rqueue squeue_0;
    more_rqueue squeue_1;
    more_rqueue squeue_2;
    more_rqueue squeue_3;
    more_rqueue squeue_4;
    more_rqueue squeue_5;
    more_rqueue squeue_6;
    more_rqueue squeue_7;
    more_rqueue squeue_8;
    more_rqueue squeue_9;

//test correct index;

    int sendingTestCorrect;
    int recevingTestCorrect;

//source
    void TCPFender_flow(Packet* p);
    void source_receive_dataPackets(Packet* p);
    void source_receive_new_dataPackets(Packet* p);
    void source_receive_retransmitted_dataPackets(Packet* p);
    void source_receive_downstream_dataPackets(Packet* p);
    void source_receive_ACKPackets(Packet* p);
    void source_checkACKInformation(Packet* p);
    void source_ACKMechanism_simpleACK(Packet* p);
    void source_ACKMechanism_duplicateACK(Packet* p);
    void source_checkDownstreamDataInformation(Packet* p);

    void source_send_dataPackets();
    void source_send_newDataPacket();
    void source_generate_ack(int sequence);

//intermediate nodes

    void intermediates_receive_dataPackets(Packet* p);
    void intermediates_receive_newdataPackets(Packet* p);
    void intermediates_receive_olddataPackets(Packet* p);
    void intermediates_receive_downstream_dataPackets(Packet* p);
    void intermediates_receive_ACKPackets(Packet*p);

    void intermediates_overhear_ACKPackets(const Packet*p);

    void intermediates_checkACKInformation(Packet* p);
    void intermediates_checkDownstreamDataInformation(Packet* p);
    void intermediates_checkDownstreamDataInnovativeInformation(Packet* p);

    void intermediates_send_dataPackets();
    void intermediate_send_newdataPackets();
    void intermediates_send_ACKPackets(Packet* p);
    void intermediates_ACKMechanism_simpleACK(Packet* p);

//destination nodes
    void destination_receive_dataPackets(Packet* p);

    void destination_send_ACKPackets(int queueIndex);
    void destination_ACKMechanism_simpleACK(int queueIndex);
    void desination_deliever_packet_toUpperLayer(Packet* p,more_rqueue rec,
	    int index,Packet* newPacket);
    void desination_upperLayer_mechanism_wholeBatch(Packet* p,more_rqueue rec,
	    int index,Packet* newPacket);
    void destination_generate_data(int sequence);

//configure packets
    Packet* source_configure_dataPackets(Packet* p);
    Packet* intermediate_configure_dataPackets(Packet* p);
    Packet* intermediate_configure_receivedPacketNum_batch(Packet* p);
    Packet* destination_configure_receivedPacketNum_batch(Packet* p);
//generate coded packets
    Packet* source_generate_codedPackets(Packet* p,int position);
    Packet* generateCodedPacketBasedOnSendingQueue(more_rqueue sen);

    void transferPacketsFromRecToSenQueue(more_rqueue rec,more_rqueue sen,int index);
    void caculateRequiredSendingNum();

    bool checkTransmitParameter();
    bool checkSendingParameter();
    void updateRoundInforForEachQueue(int sequence);
    void updateTheUnAckedPacketsInQueue(Packet* p);
    void updateTheUnAckedPacketsByIndex(int index);
    void updateRequiredSendingPacketsInQueue();
    void updateRequiredSendingPacketsInQueueByIndex(int index);

//queue function
    void sourceClearQueue(int sequence);
    void intermediateClearQueue(int index,int roundValue);
    void destinationClearQueue(int index);
    void clearQueueByIndex(int index);

    more_rqueue getCurrentSendingQueueIndex(int index);
    more_rqueue getCurrentSendingQueueBySequence(int sequence);
    more_rqueue getCurrentReceiveQueueIndex(int index);
    more_rqueue getCurrentReceiveQueueBySequence(int sequence);

    void saveReceivingQueueInLocalByQueueIndex(int index,more_rqueue queue);
    void saveReceivingQueueInLocalByQueueSequence(int sequence,more_rqueue queue);
    void saveSendingQueueInLocalByQueueIndex(int index,more_rqueue queue);

    void resetTemperorayQueue();
    void copyTemporaryQueue();

//testing function
    void printPacketContent(Packet* packetObj);

    // more variable and function ---end

    // traditional TCP variable and function ---begin

    void traditionalTCP_flow(Packet* p);

    void traditionalSendPacket(Packet* p);

    void traditionalReceiveACK(Packet* p);

    // traditional TCP variable and function ---end
protected:
    Mac *mac_;
};

#endif /* MORE_H_ */

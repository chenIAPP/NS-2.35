//last_hop_ shows current intended forwarder
#include "delay.h"
#include "connector.h"
#include "packet.h"
#include "random.h"
#include "mobilenode.h"

// #define DEBUG 99

#include "arp.h"
#include "ll.h"
#include "mac.h"
#include "mac-timers.h"
#include "mac-802_11.h"
#include "cmu-trace.h"

// Added by Sushmita to support event tracing
#include "agent.h"
#include "basetrace.h"
#include "ErrorModel80211.h"

//Somayeh
#include <iostream>
#include <fstream>
#include <string>
//Somayeh:end
/* our backoff timer doesn't count down in idle times during a
 * frame-exchange sequence as the mac tx state isn't idle; genreally
 * these idle times are less than DIFS and won't contribute to
 * counting down the backoff period, but this could be a real
 * problem if the frame exchange ends up in a timeout! in that case,
 * i.e. if a timeout happens we've not been counting down for the
 * duration of the timeout, and in fact begin counting down only
 * DIFS after the timeout!! we lose the timeout interval - which
 * will is not the REAL case! also, the backoff timer could be NULL
 * and we could have a pending transmission which we could have
 * sent! one could argue this is an implementation artifact which
 * doesn't violate the spec.. and the timeout interval is expected
 * to be less than DIFS .. which means its not a lot of time we
 * lose.. anyway if everyone hears everyone the only reason a ack will
 * be delayed will be due to a collision => the medium won't really be
 * idle for a DIFS for this to really matter!!
 */

bool			disable_oppfwd_;
bool			disable_intendedHop_;  //somayeh
bool 			use_ACK; //Somayeh
bool			sendNACKNative=false; //somayeh
bool 			findEligible=true;//somayeh
//Somayeh: temporary array: itsNextHop[0][i] -> dest=0, inten.fwd=i- itsNextHop[1][i] -> dest=4
//int itsNextHop[2][8]={-1,0,1,2,3,0,5,6,1,2,3,4,-1,6,7,4};
//int itsNextHop[4][10]={-1,0,1,2,3,0,0,6,7,8,1,2,3,4,-1,6,7,8,4,4,5,5,1,2,3,-1,5,6,7,8,1,2,3,9,9,6,7,8,9,-1};
//int itsNextHop[2][15]={-1,0,1,2,3,0,0,6,7,8,0,0,11,12,13,1,2,3,4,-1,6,7,8,4,4,11,12,13,4,4};
//debug:Somayeh
ofstream myfile;
//debug-end

inline void
Mac802_11::checkBackoffTimer()
{
	if(is_idle() && mhBackoff_.paused()) {
		double dtime;
		if ( !(pp_sched_->isCodingDisabled()) )
			dtime = phymib_.getAIFS(curr_tc_);
		else
			dtime = phymib_.getDIFS();
			
		mhBackoff_.resume(dtime);
	}
	if(! is_idle() && mhBackoff_.busy() && ! mhBackoff_.paused())
		mhBackoff_.pause();
}

inline void
Mac802_11::transmit(Packet *p, double timeout)
{

	//Somayeh:debug
	if (!iscoded_)
	{
	hdr_cmn* ch1 = HDR_CMN(p);
	if (ch1->uid_==81)
	{
		double now = Scheduler::instance().clock();
		int x=index_;
		struct hdr_mac802_11 *dhs = HDR_MAC802_11(p);
		if (ETHER_ADDR(dhs->dh_ra)!=-1)
			x=ETHER_ADDR(dhs->dh_ra);

	}
	}
	else
	{
		struct hdr_mac802_11_encoded* edh1 = HDR_MAC802_11_ENCODED(p);
		for (int i=0;i<codingCount_;i++)
			if (edh1->pkt_id[i]==81)
			{
				int x=index_;
				double now = Scheduler::instance().clock();
			}
	}
	//Somayeh

	tx_active_ = 1;
	
	if (EOTtarget_) {
		assert (eotPacket_ == NULL);
		eotPacket_ = p->copy();
	}

	/*
	 * If I'm transmitting without doing CS, such as when
	 * sending an ACK, any incoming packet will be "missed"
	 * and hence, must be discarded.
	 */
	if(rx_state_ != MAC_IDLE) {
		struct hdr_mac802_11 *dh = HDR_MAC802_11(p);		
		assert(dh->dh_fc.fc_type == MAC_Type_Control);
		assert(dh->dh_fc.fc_subtype == MAC_Subtype_ACK);
		assert(pktRx_);
		struct hdr_cmn *ch = HDR_CMN(pktRx_);
		ch->error() = 1;        /* force packet discard */
	}

	/*
	 * pass the packet on the "interface" which will in turn
	 * place the packet on the channel.
	 *
	 * NOTE: a handler is passed along so that the Network
	 *       Interface can distinguish between incoming and
	 *       outgoing packets.
	 */
	downtarget_->recv(p->copy(), this);	
	
	
	
	mhSend_.start(timeout);
	//somayeh:debug
		//double now = Scheduler::instance().clock();
		/*if (!iscoded_)
		{
			if (ch1->uid_==12427)
				int x=3;
			hdr_ip *iph = HDR_IP(p);
			int mySrc = Address::instance().get_nodeaddr(iph->saddr());
			if (mySrc==index_)
			{
				myfile.open ("InjectedPackets.txt",std::ios_base::app);
				myfile << "Packet#"<<ch1->uid_<<" sent by node#"<<index_<<"\n";
				myfile.close();
			}
		}*/
		//somayeh:end
	mhIF_.start(txtime(p));
}
inline void
Mac802_11::setRxState(MacState newState)
{
	rx_state_ = newState;
	checkBackoffTimer();
}

inline void
Mac802_11::setTxState(MacState newState)
{
	tx_state_ = newState;
	checkBackoffTimer();
}


/* ======================================================================
   TCL Hooks for the simulator
   ====================================================================== */
static class Mac802_11Class : public TclClass {
public:
	Mac802_11Class() : TclClass("Mac/802_11") {}
	TclObject* create(int, const char*const*) {
	return (new Mac802_11());

}
} class_mac802_11;


/* ======================================================================
   Mac  and Phy MIB Class Functions
   ====================================================================== */

PHY_MIB::PHY_MIB(Mac802_11 *parent)
{
	/*
	 * Bind the phy mib objects.  Note that these will be bound
	 * to Mac/802_11 variables
	 */

	// overheard native tc = 0
	parent->bind("CWMin_TC0", &(CWMin[0]));
	parent->bind("CWMax_TC0", &(CWMax[0]));
	parent->bind("AIFSN_TC0", &(AIFSN[0]));
	parent->bind("PF_TC0", &(PF[0]));  

	// intended native tc = 1	
	parent->bind("CWMin_TC1", &(CWMin[1]));
	parent->bind("CWMax_TC1", &(CWMax[1]));	
	parent->bind("AIFSN_TC1", &(AIFSN[1]));
	parent->bind("PF_TC1", &(PF[1]));

	// 2-pkt coding
	parent->bind("CWMin_TC2", &(CWMin[2]));
	parent->bind("CWMax_TC2", &(CWMax[2]));
	parent->bind("AIFSN_TC2", &(AIFSN[2]));
	parent->bind("PF_TC2", &(PF[2]));
	// 3-pkt		
	parent->bind("CWMin_TC3", &(CWMin[3]));
	parent->bind("CWMax_TC3", &(CWMax[3]));
	parent->bind("AIFSN_TC3", &(AIFSN[3]));
	parent->bind("PF_TC3", &(PF[3]));
	// 3-pkt		
	parent->bind("CWMin_TC3", &(CWMin[3]));
	parent->bind("CWMax_TC3", &(CWMax[3]));
	parent->bind("AIFSN_TC3", &(AIFSN[3]));
	parent->bind("PF_TC3", &(PF[3]));
	// 4-pkt		
	parent->bind("CWMin_TC4", &(CWMin[4]));
	parent->bind("CWMax_TC4", &(CWMax[4]));
	parent->bind("AIFSN_TC4", &(AIFSN[4]));
	parent->bind("PF_TC4", &(PF[4]));
	// 5-pkt		
	parent->bind("CWMin_TC5", &(CWMin[5]));
	parent->bind("CWMax_TC5", &(CWMax[5]));
	parent->bind("AIFSN_TC5", &(AIFSN[5]));
	parent->bind("PF_TC5", &(PF[5]));
	// 6-pkt		
	parent->bind("CWMin_TC6", &(CWMin[6]));
	parent->bind("CWMax_TC6", &(CWMax[6]));
	parent->bind("AIFSN_TC6", &(AIFSN[6]));
	parent->bind("PF_TC6", &(PF[6]));
	// 7-pkt		
	parent->bind("CWMin_TC7", &(CWMin[7]));
	parent->bind("CWMax_TC7", &(CWMax[7]));
	parent->bind("AIFSN_TC7", &(AIFSN[7]));
	parent->bind("PF_TC7", &(PF[7]));
	// 8-pkt		
	parent->bind("CWMin_TC8", &(CWMin[8]));
	parent->bind("CWMax_TC8", &(CWMax[8]));
	parent->bind("AIFSN_TC8", &(AIFSN[8]));
	parent->bind("PF_TC8", &(PF[8]));
	// original 802.11		
	parent->bind("CWMin_ORIG", &(CWMin[9]));
	parent->bind("CWMax_ORIG", &(CWMax[9]));
	parent->bind("AIFSN_ORIG", &(AIFSN[9]));
	parent->bind("PF_ORIG", &(PF[9]));


	parent->bind("SlotTime_", &SlotTime);
	parent->bind("SIFS_", &SIFSTime);
	parent->bind("PreambleLength_", &PreambleLength);
	parent->bind("PLCPHeaderLength_", &PLCPHeaderLength);
	parent->bind_bw("PLCPDataRate_", &PLCPDataRate);

        if(!ErrorModel80211::isShortPreamble_) {
        	parent->bind("PreambleLength_", &PreambleLength);
                parent->bind("PreambleDataRate_", &PreambleDataRate);
                parent->bind("PLCPHeaderLength_", &PLCPHeaderLength);
	        parent->bind_bw("PLCPDataRate_", &PLCPDataRate);
        }
        else {
                parent->bind("ShortPreambleLength_", &PreambleLength);
                parent->bind("PreambleDataRate_", &PreambleDataRate);
                parent->bind("PLCPHeaderLength_", &PLCPHeaderLength);
	        parent->bind_bw("ShortPLCPDataRate_", &PLCPDataRate);
        }
}

MAC_MIB::MAC_MIB(Mac802_11 *parent)
{
	/*
	 * Bind the phy mib objects.  Note that these will be bound
	 * to Mac/802_11 variables
	 */
	
	parent->bind("RTSThreshold_", &RTSThreshold);
	parent->bind("ShortRetryLimit_", &ShortRetryLimit);
	parent->bind("LongRetryLimit_", &LongRetryLimit);
}

/* ======================================================================
   Mac Class Functions
   ====================================================================== */
Mac802_11::Mac802_11() :
	Mac(), phymib_(this), macmib_(this), mhIF_(this), mhNav_(this), 
	mhRecv_(this), mhSend_(this), 
	mhDefer_(this), mhBackoff_(this), mhScan_(this), coding_buffer_(MAX_BUFF_SIZE)
,ACKWaiting_(this)
{
	pktHelp_=0;  //Somayeh
	
	nav_ = 0.0;
	tx_state_ = rx_state_ = MAC_IDLE;
	tx_active_ = 0;
	eotPacket_ = NULL;
	pktRTS_ = 0;
	pktCTRL_ = 0;		
	//cw_ = phymib_.getCWMin();
	ssrc_ = slrc_ = 0;
	// Added by Sushmita
        et_ = new EventTrace();
	
	sta_seqno_ = 1;
	cache_ = 0;
	cache_node_count_ = 0;
	
	// chk if basic/data rates are set
	// otherwise use bandwidth_ as default;
	
	Tcl& tcl = Tcl::instance();
	tcl.evalf("Mac/802_11 set basicRate_");
	if (strcmp(tcl.result(), "0") != 0) 
		bind_bw("basicRate_", &basicRate_);
	else
		basicRate_ = bandwidth_;

	tcl.evalf("Mac/802_11 set dataRate_");
	if (strcmp(tcl.result(), "0") != 0) 
		bind_bw("dataRate_", &dataRate_);
	else
		dataRate_ = bandwidth_;

        EOTtarget_ = 0;
       	bss_id_ = IBSS_ID;
	//printf("bssid in constructor %d\n",bss_id_);
	
	bind("scan_int_", &scan_int_);
    bind("scan_len_", &scan_len_);
    bind("smooth_scan_", &smooth_scan_);
	
    scan_cnt_ = 0;
        
    if (scan_int_ > 0)
          mhScan_.start(scan_int_);
          
    coding_buffer_.pkt_map_ = &(uid_pkt_Cbuffer_);
    coding_buffer_.setDropFront();
    disable_oppfwd_ = false;
    disable_intendedHop_=false; //somayeh
    use_ACK=true; //Somayeh
    
//    cw_orig_ = phymib_.getCWMin(); //set AP cw to some special value;
//    bind("code_cw_", &code_cw_); //set coding cw to some special value;
	enable_meshgw_ = -1;

    txm_stats_.intend_coded = 0;
    txm_stats_.unintend_coded = 0;
    txm_stats_.unintend_native = 0;
    txm_stats_.intend_native = 0;
    
    bind("link_ber_", &link_ber_);
}


int
Mac802_11::command(int argc, const char*const* argv)
{
	if (argc == 3) {
		if (strcmp(argv[1], "eot-target") == 0) {
			EOTtarget_ = (NsObject*) TclObject::lookup(argv[2]);
			if (EOTtarget_ == 0)
				return TCL_ERROR;
			return TCL_OK;
		} else if (strcmp(argv[1], "bss_id") == 0) {
			bss_id_ = atoi(argv[2]);
			return TCL_OK;
		} else if (strcmp(argv[1], "log-target") == 0) { 
			logtarget_ = (NsObject*) TclObject::lookup(argv[2]);
			if(logtarget_ == 0)
				return TCL_ERROR;
			return TCL_OK;
		} else if(strcmp(argv[1], "nodes") == 0) {
			if(cache_) return TCL_ERROR;
			cache_node_count_ = atoi(argv[2]);
			cache_ = new Host[cache_node_count_ + 1];
			assert(cache_);
			bzero(cache_, sizeof(Host) * (cache_node_count_+1 ));
			return TCL_OK;
		} else if(strcmp(argv[1], "eventtrace") == 0) {
			// command added to support event tracing by Sushmita
                        et_ = (EventTrace *)TclObject::lookup(argv[2]);
                        return (TCL_OK);
        } else if (strcmp(argv[1], "load-trace") == 0) {
                        if (strcmp(argv[2], "") == 0) { return(TCL_OK); }
                        int mode;
                        const char* id = argv[2];
                        Tcl& tcl = Tcl::instance();
                        ltr_ch = Tcl_GetChannel(tcl.interp(), (char*)id, &mode);
                        return(TCL_OK);
		} else if(strcmp(argv[1], "arptable") == 0) {
          arptable_ = (ARPTable*)TclObject::lookup(argv[2]);
          assert(arptable_);
          return TCL_OK;
      	} else if(strcmp(argv[1], "set-cw-orig") == 0) {
      		enable_meshgw_ = atoi(argv[2]);
      		return TCL_OK;
		}
	}   else if (argc == 2) { 
		if(strcmp(argv[1], "debug-qlen-chk") == 0) {
   			int count = 0;
      		for (Packet *tmp = coding_buffer_.head(); tmp; tmp = tmp->next_)
      				count ++;
      		printf("\n MAC:%d -- MAC\n", index_);
      		printf("Buffer   Count: %d	 Length: %d\n", count, coding_buffer_.length());
      		printf("Map_size: %d\n", uid_pkt_Cbuffer_.size());
			return TCL_OK;
		}
		if(strcmp(argv[1], "debug-q-content") == 0) {
      		int count = 0;
   			printf("\n MAC:%d  --Buffering_content  \n", index_);      		
      		for (Packet *tmp = coding_buffer_.head(); tmp; tmp = tmp->next_) {
      			count ++;
      			struct hdr_cmn *ch_p = HDR_CMN(tmp);
      			printf("#%03d uid-%d pcond-%d prev-%d next-%d 2hn-%d\n", 
      					count, ch_p->uid(), ch_p->pcondition, ch_p->prev_fwd_mac, ch_p->next_hop_, ch_p->two_hop_away_ip);
      		}
			return TCL_OK;
		}

		if(strcmp(argv[1], "disable-oppfwd") == 0) {
			disable_oppfwd_ = true;
			return TCL_OK;
		}
		if(strcmp(argv[1], "disable-intend") == 0) {
					disable_intendedHop_ = true;
					return TCL_OK;
				}
		if(strcmp(argv[1], "print-txm-count") == 0) {
      		printf("\n NODE:%d -- txm-count\n", index_);
      		printf("802.11- %d  ExOR- %d  COPE- %d  BEND- %d\n", 
      				txm_stats_.intend_native, txm_stats_.unintend_native, 
      				txm_stats_.intend_coded, txm_stats_.unintend_coded);
			return TCL_OK;
		}
	}
	return Mac::command(argc, argv);
}

// Added by Sushmita to support event tracing
void Mac802_11::trace_event(char *eventtype, Packet *p) 
{
        if (et_ == NULL) return;
        char *wrk = et_->buffer();
        char *nwrk = et_->nbuffer();
	
        hdr_ip *iph = hdr_ip::access(p);
        //char *src_nodeaddr =
	//       Address::instance().print_nodeaddr(iph->saddr());
        //char *dst_nodeaddr =
        //      Address::instance().print_nodeaddr(iph->daddr());
	
        struct hdr_mac802_11* dh = HDR_MAC802_11(p);
	
        //struct hdr_cmn *ch = HDR_CMN(p);
	
	if(wrk != 0) {
		sprintf(wrk, "E -t "TIME_FORMAT" %s %2x ",
			et_->round(Scheduler::instance().clock()),
                        eventtype,
                        //ETHER_ADDR(dh->dh_sa)
                        ETHER_ADDR(dh->dh_ta)
                        );
        }
        if(nwrk != 0) {
                sprintf(nwrk, "E -t "TIME_FORMAT" %s %2x ",
                        et_->round(Scheduler::instance().clock()),
                        eventtype,
                        //ETHER_ADDR(dh->dh_sa)
                        ETHER_ADDR(dh->dh_ta)
                        );
        }
        et_->dump();
}

/* ======================================================================
   Debugging Routines
   ====================================================================== */
void
Mac802_11::trace_pkt(Packet *p) 
{
	struct hdr_cmn *ch = HDR_CMN(p);
	struct hdr_mac802_11* dh = HDR_MAC802_11(p);
	u_int16_t *t = (u_int16_t*) &dh->dh_fc;

	fprintf(stderr, "\t[ %2x %2x %2x %2x ] %x %s %d\n",
		*t, dh->dh_duration,
		 ETHER_ADDR(dh->dh_ra), ETHER_ADDR(dh->dh_ta),
		index_, packet_info.name(ch->ptype()), ch->size());
}

void
Mac802_11::dump(char *fname)
{
	fprintf(stderr,
		"\n%s --- (INDEX: %d, time: %2.9f)\n",
		fname, index_, Scheduler::instance().clock());

	fprintf(stderr,
		"\ttx_state_: %x, rx_state_: %x, nav: %2.9f, idle: %d\n",
		tx_state_, rx_state_, nav_, is_idle());

	fprintf(stderr,
		"\tpktTx_: %x, pktRx_: %x, pktRTS_: %x, pktCTRL_: %x, callback: %x\n",
		(int) pktTx_, (int) pktRx_, (int) pktRTS_,
		(int) pktCTRL_, (int) callback_);

	fprintf(stderr,
		"\tDefer: %d, Backoff: %d (%d), Recv: %d, Timer: %d Nav: %d\n",
		mhDefer_.busy(), mhBackoff_.busy(), mhBackoff_.paused(),
		mhRecv_.busy(), mhSend_.busy(), mhNav_.busy());
	fprintf(stderr,
		"\tBackoff Expire: %f\n",
		mhBackoff_.expire());
}


/* ======================================================================
   Packet Headers Routines
   ====================================================================== */
inline int
Mac802_11::hdr_dst(char* hdr, int dst )
{
	struct hdr_mac802_11 *dh = (struct hdr_mac802_11*) hdr;
	
       if (dst > -2) {
               if ((bss_id() == IBSS_ID) || (addr() == bss_id())) {
                       /* if I'm AP (2nd condition above!), the dh_3a
                        * is already set by the MAC whilst fwding; if
                        * locally originated pkt, it might make sense
                        * to set the dh_3a to myself here! don't know
                        * how to distinguish between the two here - and
                        * the info is not critical to the dst station
                        * anyway!
                        */
                       STORE4BYTE(&dst, (dh->dh_ra));
               } else {
                       /* in BSS mode, the AP forwards everything;
                        * therefore, the real dest goes in the 3rd
                        * address, and the AP address goes in the
                        * destination address
                        */
                       STORE4BYTE(&bss_id_, (dh->dh_ra));
                       STORE4BYTE(&dst, (dh->dh_3a));
               }
       }


       return (u_int32_t)ETHER_ADDR(dh->dh_ra);
}

inline int 
Mac802_11::hdr_src(char* hdr, int src )
{
	struct hdr_mac802_11 *dh = (struct hdr_mac802_11*) hdr;
        if(src > -2)
               STORE4BYTE(&src, (dh->dh_ta));
        return ETHER_ADDR(dh->dh_ta);
}

inline int 
Mac802_11::hdr_type(char* hdr, u_int16_t type)
{
	struct hdr_mac802_11 *dh = (struct hdr_mac802_11*) hdr;
	if(type)
		STORE2BYTE(&type,(dh->dh_body));
	return GET2BYTE(dh->dh_body);
}


/* ======================================================================
   Misc Routines
   ====================================================================== */
inline int
Mac802_11::is_idle()
{
	if(rx_state_ != MAC_IDLE)
		return 0;
	if(tx_state_ != MAC_IDLE)
		return 0;
	if(nav_ > Scheduler::instance().clock())
		return 0;
	
	return 1;
}

void
Mac802_11::discard(Packet *p, const char* why)
{
	hdr_mac802_11* mh = HDR_MAC802_11(p);
	hdr_cmn *ch = HDR_CMN(p);

	/* if the rcvd pkt contains errors, a real MAC layer couldn't
	   necessarily read any data from it, so we just toss it now */
	if(ch->error() != 0) {
		Packet::free(p);
		return;
	}

	switch(mh->dh_fc.fc_type) {
	case MAC_Type_Management:
		drop(p, why);
		return;
	case MAC_Type_Control:
		switch(mh->dh_fc.fc_subtype) {
		case MAC_Subtype_RTS:
			 if((u_int32_t)ETHER_ADDR(mh->dh_ta) ==  (u_int32_t)index_) {
				drop(p, why);
				return;
			}
			/* fall through - if necessary */
		case MAC_Subtype_CTS:
		case MAC_Subtype_ACK:
			if((u_int32_t)ETHER_ADDR(mh->dh_ra) == (u_int32_t)index_) {
				drop(p, why);
				return;
			}
			break;
		default:
			fprintf(stderr, "invalid MAC Control subtype\n");
			exit(1);
		}
		break;
	case MAC_Type_Data:
		switch(mh->dh_fc.fc_subtype) {
		case MAC_Subtype_Data: 
			if((u_int32_t)ETHER_ADDR(mh->dh_ra) == \
                           (u_int32_t)index_ ||
                          (u_int32_t)ETHER_ADDR(mh->dh_ta) == \
                           (u_int32_t)index_ ||
                          (u_int32_t)ETHER_ADDR(mh->dh_ra) == MAC_BROADCAST) {
                                drop(p,why);
                                return;
			}
			break;
		case MAC_Subtype_CData:
			drop(p, why);
			return;
		default:
			fprintf(stderr, "invalid MAC Data subtype\n");
			exit(1);
		}
		break;
	default:
		fprintf(stderr, "invalid MAC type (%x)\n", mh->dh_fc.fc_type);
		trace_pkt(p);
		exit(1);
	}
	Packet::free(p);
}

void
Mac802_11::capture(Packet *p)
{
	/*
	 * Update the NAV so that this does not screw
	 * up carrier sense.
	 */	
	set_nav(usec(phymib_.getEIFS() + txtime(p)));
	Packet::free(p);
}

void
Mac802_11::collision(Packet *p)
{
	switch(rx_state_) {
	case MAC_RECV:
		setRxState(MAC_COLL);
		/* fall through */
	case MAC_COLL:
		assert(pktRx_);
		assert(mhRecv_.busy());
		/*
		 *  Since a collision has occurred, figure out
		 *  which packet that caused the collision will
		 *  "last" the longest.  Make this packet,
		 *  pktRx_ and reset the Recv Timer if necessary.
		 */
		if(txtime(p) > mhRecv_.expire()) {
			mhRecv_.stop();
			discard(pktRx_, DROP_MAC_COLLISION);
			pktRx_ = p;
			mhRecv_.start(txtime(pktRx_));
		}
		else {
			discard(p, DROP_MAC_COLLISION);
		}
		break;
	default:
		assert(0);
	}
}

void
Mac802_11::tx_resume()
{
	double rTime;
	assert(mhSend_.busy() == 0);
	assert(mhDefer_.busy() == 0);

	if(pktCTRL_) {
		/*
		 *  Need to send a CTS or ACK.
		 */
		//mhDefer_.start(phymib_.getSIFS());
		mhDefer_.start(ack_defer_);
	} else if(pktRTS_) {
		if (mhBackoff_.busy() == 0) {
			rTime = (Random::random() % cw_) * phymib_.getSlotTime();
			mhDefer_.start( phymib_.getDIFS() + rTime);
//			mhBackoff_.start(cw_, is_idle(), phymib_.getDIFS());
//bugfix UKA transmission			
		}
	} else if(pktTx_) {
		if (mhBackoff_.busy() == 0) {
			hdr_cmn *ch = HDR_CMN(pktTx_);
			struct hdr_mac802_11 *mh = HDR_MAC802_11(pktTx_);
			
			if ((u_int32_t) ch->size() < macmib_.getRTSThreshold()
			    || (u_int32_t) ETHER_ADDR(mh->dh_ra) == MAC_BROADCAST) {
				rTime = (Random::random() % cw_)
					* phymib_.getSlotTime();
					
				double dtime;
				if ( !(pp_sched_->isCodingDisabled()) )
					dtime = phymib_.getAIFS(curr_tc_);
				else
					dtime = phymib_.getDIFS();
			
				mhDefer_.start(dtime + rTime);
// 				mhDefer_.start(dtime);
// 				mhBackoff_.start(cw_, is_idle(), phymib_.getDIFS());
// bugfix UKA transmission 				
 				
            } 
            else {
				mhDefer_.start(phymib_.getSIFS());
            }
		}
	} else if(callback_) {
		Handler *h = callback_;
		callback_ = 0;
		h->handle((Event*) 0);
	}
	setTxState(MAC_IDLE);
}

void
Mac802_11::rx_resume()
{
	assert(pktRx_ == 0);
	assert(mhRecv_.busy() == 0);
	setRxState(MAC_IDLE);
}


/* ======================================================================
   Timer Handler Routines
   ====================================================================== */
void
Mac802_11::backoffHandler()
{
	if(pktCTRL_) {
		assert(mhSend_.busy() || mhDefer_.busy());
		return;
	}

	if(check_pktRTS() == 0)
		return;

	if(check_pktTx() == 0)
		return;
}

void
Mac802_11::deferHandler()
{
	assert(pktCTRL_ || pktRTS_ || pktTx_);

	if(check_pktCTRL() == 0)
		return;
	assert(mhBackoff_.busy() == 0);
	if(check_pktRTS() == 0)
		return;
	if(check_pktTx() == 0)
		return;
}

void
Mac802_11::navHandler()
{

	if(is_idle() && mhBackoff_.paused()) {		
		double dtime;
		if ( !(pp_sched_->isCodingDisabled()) )
			dtime = phymib_.getAIFS(curr_tc_);
		else
			dtime = phymib_.getDIFS();
			
		mhBackoff_.resume(dtime);
	}
}

void
Mac802_11::recvHandler()
{
	recv_timer();
}

void
Mac802_11::sendHandler()
{
	send_timer();
}

//Somayeh
void
Mac802_11::ACKHandler()
{
	ACK_timer();
}
//Somayeh:End

void
Mac802_11::txHandler()
{
	if (EOTtarget_) {
		assert(eotPacket_);
		EOTtarget_->recv(eotPacket_, (Handler *) 0);
		eotPacket_ = NULL;
	}
	tx_active_ = 0;
}


/* ======================================================================
   The "real" Timer Handler Routines
   ====================================================================== */
void
Mac802_11::send_timer()
{
	//somayeh:debug
	struct hdr_cmn* ch11;
	if (pktTx_)
		ch11= HDR_CMN(pktTx_);
	//somayeh:end
	switch(tx_state_) {
	/*
	 * Sent a RTS, but did not receive a CTS.
	 */
	case MAC_RTS:
		RetransmitRTS();
		break;
	/*
	 * Sent a CTS, but did not receive a DATA packet.
	 */
	case MAC_CTS:
		assert(pktCTRL_);
		Packet::free(pktCTRL_); 
		pktCTRL_ = 0;
		break;
	/*
	 * Sent DATA, but did not receive an ACK packet.
	 */
	case MAC_SEND:
		if (iscoded_) {
			//Somayeh:debug
			for (int i=0; i<codingCount_; i++)
			{
				if (codingPair_[i])
				{
					hdr_cmn* ch1 = HDR_CMN(codingPair_[i]);
					if (ch1->uid_==81)
					{
						double now = Scheduler::instance().clock();
						int x=index_;
						struct hdr_mac802_11 *dhs = HDR_MAC802_11(codingPair_[i]);
						if (ETHER_ADDR(dhs->dh_ra)!=-1)
							x=ETHER_ADDR(dhs->dh_ra);
					}
				}

			}
			//Somayeh
			bool noResponse = true;
			for (int i=0; i<codingCount_; i++) {
				if (ack_status_list_[i] != NOREPLY) {
					noResponse = false;
					break;
				}
			}
			if (noResponse) { // a sign of collision.
				RetransmitDATA();
			} else { //some replied either ack or nack
				discard(pktTx_, "partly_(N)ACKED"); //originally in bottom
				pktTx_ = 0;
				//Somayeh
				if (disable_intendedHop_){
					for (int i=0; i<codingCount_; i++)
					{
						if (ack_status_list_[i] == NACKED){
							if (!sendNACKNative)
								pp_sched_->queue_and_searchPartner(codingPair_[i],false);
							else
							{
								int xxx=index_;
								struct hdr_mac802_11 *dhs = HDR_MAC802_11(codingPair_[i]);
								sendDATA(codingPair_[i]);
								//send(codingPair_[i],(Handler*) 0);
								RetransmitDATA();
								/*//NACKQUncoded
								 * struct hdr_cmn *ch_p = HDR_CMN(codingPair_[i]);
								if (ch_p->pcondition!=PCOND_OVERHEARD)
									ch_p->pcondition=PCOND_INTENDED_UNCODABLE;
								pp_sched_->queue_and_searchPartner(codingPair_[i],false);*/
							}
							//pp_sched_->queue_and_searchPartner(codingPair_[i],false);
							codingPair_[i] = 0;
						}
						//Somayeh next change: do something for NoREPLY as well
						else if (ack_status_list_[i] == NOREPLY){
							pp_sched_->queue_and_searchPartner(codingPair_[i],true);
							codingPair_[i] = 0;
						}

					}
				}
				/*else
					for (int i=0; i<codingCount_; i++)
						{
							if (ack_status_list_[i] == NOREPLY){
								pp_sched_->queue_and_searchPartner(codingPair_[i],true);
								codingPair_[i] = 0;
							}

						}*/
				//Somayeh:End
				//discard(pktTx_, "partly_(N)ACKED"); //add to the top
				//pktTx_ = 0;
			}
					
			break; // break from the outter switch
	    }
		//somayeh:debug
		if (ch11->uid_==81)
		{
			double now = Scheduler::instance().clock();
			int x1=index_;
			struct hdr_mac802_11 *dhs1 = HDR_MAC802_11(pktTx_);
			if (ETHER_ADDR(dhs1->dh_ra)!=-1)
				x1=ETHER_ADDR(dhs1->dh_ra);
		}
		//somayeh:end
	    RetransmitDATA();
	    break;
	/*
	 * Sent an ACK, and now ready to resume transmission.
	 */
	case MAC_ACK:
		assert(pktCTRL_);
		Packet::free(pktCTRL_); 
		pktCTRL_ = 0;
		break;
	case MAC_IDLE:
		break;
	default:
		assert(0);
	}
	tx_resume();
}

//Somayeh
void
Mac802_11::ACK_timer()
{
	//Someh:Debug
	int xx=index_;
	//Somayeh:ENDDebug
	if (disable_intendedHop_)
		if (pktHelp_)
		{
			struct hdr_cmn *ch = HDR_CMN(pktHelp_);
			//Somayeh:debug
					if (ch->uid_==81)
					{
						int x1=index_;
						struct hdr_mac802_11 *dhs = HDR_MAC802_11(pktHelp_);
						if (ETHER_ADDR(dhs->dh_ra)!=-1)
							x1=ETHER_ADDR(dhs->dh_ra);
					}
			//Somayeh:end
			sendACK(ch->uid(), 0);
			ack_defer_ = phymib_.getSIFS();
			if(mhSend_.busy() == 0)
				tx_resume();

			if ((use_ACK)&&(pp_sched_->IsThereAnyValidACK(ch->uid_,ch->two_hop_away_ip)))
			{
				drop(pktHelp_, "Already exist in downstream");
				pktHelp_=0;
				return;
			}

			//debug:Somayeh
			//double now = Scheduler::instance().clock();
			//myfile.open ("example1.txt",std::ios_base::app);
			//myfile << "Packet#"<<ch->uid_<<" transmitted by (not intended) node#"<<index_<<" intendedFWD="<<ch->next_hop_<<" time="<<now<<"\n";
			//myfile.close();
			//debug:end
			uptarget_->recv(pktHelp_, (Handler*) 0);
			pktHelp_=0;
		}
}
//Somayeh:End
/* ======================================================================
   Outgoing Packet Routines
   ====================================================================== */
int
Mac802_11::check_pktCTRL()
{
	struct hdr_mac802_11 *mh;
	double timeout;

	if(pktCTRL_ == 0)
		return -1;
	if(tx_state_ == MAC_CTS || tx_state_ == MAC_ACK)
		return -1;

	mh = HDR_MAC802_11(pktCTRL_);
							  
	switch(mh->dh_fc.fc_subtype) {
	/*
	 *  If the medium is not IDLE, don't send the CTS.
	 */
	case MAC_Subtype_CTS:
		if(!is_idle()) {
			discard(pktCTRL_, DROP_MAC_BUSY); pktCTRL_ = 0;
			return 0;
		}
		setTxState(MAC_CTS);
		/*
		 * timeout:  cts + data tx time calculated by
		 *           adding cts tx time to the cts duration
		 *           minus ack tx time -- this timeout is
		 *           a guess since it is unspecified
		 *           (note: mh->dh_duration == cf->cf_duration)
		 */		
		 timeout = txtime(phymib_.getCTSlen(), basicRate_)
                        + DSSS_MaxPropagationDelay                      // XXX
                        + sec(mh->dh_duration)
                        + DSSS_MaxPropagationDelay                      // XXX
                       - phymib_.getSIFS()
                       - txtime(phymib_.getACKlen(), basicRate_);
		break;
		/*
		 * IEEE 802.11 specs, section 9.2.8
		 * Acknowledments are sent after an SIFS, without regard to
		 * the busy/idle state of the medium.
		 */
	case MAC_Subtype_ACK:		
		setTxState(MAC_ACK);
		timeout = txtime(phymib_.getACKlen(), basicRate_);
		break;
	default:
		fprintf(stderr, "check_pktCTRL:Invalid MAC Control subtype\n");
		exit(1);
	}
	transmit(pktCTRL_, timeout);
	return 0;
}

int
Mac802_11::check_pktRTS()
{
	struct hdr_mac802_11 *mh;
	double timeout;

	assert(mhBackoff_.busy() == 0);

	if(pktRTS_ == 0)
 		return -1;
	mh = HDR_MAC802_11(pktRTS_);

 	switch(mh->dh_fc.fc_subtype) {
	case MAC_Subtype_RTS:
		if(! is_idle()) {
			inc_cw(0);
			mhBackoff_.start(cw_, is_idle());
			return 0;
		}
		setTxState(MAC_RTS);
		timeout = txtime(phymib_.getRTSlen(), basicRate_)
			+ DSSS_MaxPropagationDelay                      // XXX
			+ phymib_.getSIFS()
			+ txtime(phymib_.getCTSlen(), basicRate_)
			+ DSSS_MaxPropagationDelay;
		break;
	default:
		fprintf(stderr, "check_pktRTS:Invalid MAC Control subtype\n");
		exit(1);
	}
	transmit(pktRTS_, timeout);
  

	return 0;
}

int
Mac802_11::check_pktTx()
{
	//somayeh:debug
	int x=index_;
	//somayeh:end
	struct hdr_mac802_11 *mh;
	double timeout;
	
	assert(mhBackoff_.busy() == 0);

	if(pktTx_ == 0)
		return -1;

	mh = HDR_MAC802_11(pktTx_);

	switch(mh->dh_fc.fc_subtype) {
	case MAC_Subtype_Data : case MAC_Subtype_CData:
		if(! is_idle()) {
			sendRTS(ETHER_ADDR(mh->dh_ra));
//			inc_cw(curr_tc_);
//bugfix UKA: transmission
			mhBackoff_.start(cw_, is_idle());
			return 0;
		}
		setTxState(MAC_SEND);
		if((u_int32_t)ETHER_ADDR(mh->dh_ra) != MAC_BROADCAST)
			if (iscoded_)
			{
				//Somayeh
				if (!disable_intendedHop_)
                        timeout = txtime(pktTx_)
                                + DSSS_MaxPropagationDelay              // XXX
                               + phymib_.getSIFS() * codingCount_
                               + txtime(phymib_.getACKlen(), basicRate_) * codingCount_
                               + DSSS_MaxPropagationDelay * codingCount_;             // XXX
				else //if (disable_intendedHop_)
				{
					struct hdr_mac802_11_encoded *dh = HDR_MAC802_11_ENCODED(pktTx_);
					int helping_neighbors=0;
					neighbor_tbl_t::iterator p;
					for (p=arptable_->my_neighbors_.neighbor_tbl_.begin();p!=arptable_->my_neighbors_.neighbor_tbl_.end();++p)
					{
						if (p->first!=index_)
						{
							bool found=false;
				 			for (int j=0;j<codingCount_;j++)
				 				if (p->first==ETHER_ADDR(dh->dh_ra[j]))
				 				{
				 					found=true;
				 					break;
				 				}
				 			if (!found)
				 				helping_neighbors++;
						}
					}
			 		helping_neighbors+=codingCount_;
					timeout = txtime(pktTx_)
					+ DSSS_MaxPropagationDelay              // XXX
					+ phymib_.getSIFS() * (helping_neighbors+1)
					+ txtime(phymib_.getACKlen(), basicRate_) * helping_neighbors
					+ DSSS_MaxPropagationDelay * helping_neighbors;
					//+ DSSS_MaxPropagationDelay * (helping_neighbors-codingCount_);             // XXX
				}
			}
			else //if it is native
                  timeout = txtime(pktTx_)
                  + DSSS_MaxPropagationDelay              // XXX
                  + phymib_.getSIFS()
                  + txtime(phymib_.getACKlen(), basicRate_)
                  + DSSS_MaxPropagationDelay;             // XXX
		else//if it is broadcast
			timeout = txtime(pktTx_);
			
		if (mh->dh_fc.fc_subtype == MAC_Subtype_CData) { // i.e. iscoded_
			resetAck_status();
		}
		break;
	default:
		fprintf(stderr, "check_pktTx:Invalid MAC Control subtype\n");
		exit(1);
	}
	transmit(pktTx_, timeout);
	return 0;
}
/*
 * Low-level transmit functions that actually place the packet onto
 * the channel.
 */
 
 void Mac802_11::resetAck_status() {
 	assert(iscoded_);
 	for (int i=0; i<codingCount_; i++)
 		ack_status_list_[i] = NOREPLY;
 }
 
 bool Mac802_11::isAnyResponse() {
 	assert(iscoded_);
 	for (int i=0; i<codingCount_; i++)
 		if (ack_status_list_[i] != NOREPLY) return true;
 	
 	return false;
 }
 
void
Mac802_11::sendRTS(int dst)
{
	/*
	 *  If the size of the packet is larger than the
	 *  RTSThreshold, then perform the RTS/CTS exchange.
	 */
	if( (u_int32_t) HDR_CMN(pktTx_)->size() < macmib_.getRTSThreshold() ||
            (u_int32_t) dst == MAC_BROADCAST) {
//		Packet::free(p);
		return;
	}


	Packet *p = Packet::alloc();
	hdr_cmn* ch = HDR_CMN(p);
	struct rts_frame *rf = (struct rts_frame*)p->access(hdr_mac::offset_);
	
	assert(pktTx_);
	assert(pktRTS_ == 0);


	ch->uid() = 0;
	ch->ptype() = PT_MAC;
	ch->size() = phymib_.getRTSlen();
	ch->iface() = -2;
	ch->error() = 0;

	bzero(rf, MAC_HDR_LEN);

	rf->rf_fc.fc_protocol_version = MAC_ProtocolVersion;
 	rf->rf_fc.fc_type	= MAC_Type_Control;
 	rf->rf_fc.fc_subtype	= MAC_Subtype_RTS;
 	rf->rf_fc.fc_to_ds	= 0;
 	rf->rf_fc.fc_from_ds	= 0;
 	rf->rf_fc.fc_more_frag	= 0;
 	rf->rf_fc.fc_retry	= 0;
 	rf->rf_fc.fc_pwr_mgt	= 0;
 	rf->rf_fc.fc_NACK	= 0;
 	rf->rf_fc.fc_wep	= 0;
 	rf->rf_fc.fc_order	= 0;

	//rf->rf_duration = RTS_DURATION(pktTx_);
	STORE4BYTE(&dst, (rf->rf_ra));
	
	/* store rts tx time */
 	ch->txtime() = txtime(ch->size(), basicRate_);
	
	STORE4BYTE(&index_, (rf->rf_ta));

	/* calculate rts duration field */	
	rf->rf_duration = usec(phymib_.getSIFS()
			       + txtime(phymib_.getCTSlen(), basicRate_)
			       + phymib_.getSIFS()
                               + txtime(pktTx_)
			       + phymib_.getSIFS()
			       + txtime(phymib_.getACKlen(), basicRate_));
	pktRTS_ = p;
}

void
Mac802_11::sendCTS(int dst, double rts_duration)
{
	Packet *p = Packet::alloc();
	hdr_cmn* ch = HDR_CMN(p);
	struct cts_frame *cf = (struct cts_frame*)p->access(hdr_mac::offset_);

	assert(pktCTRL_ == 0);

	ch->uid() = 0;
	ch->ptype() = PT_MAC;
	ch->size() = phymib_.getCTSlen();


	ch->iface() = -2;
	ch->error() = 0;
	//ch->direction() = hdr_cmn::DOWN;
	bzero(cf, MAC_HDR_LEN);

	cf->cf_fc.fc_protocol_version = MAC_ProtocolVersion;
	cf->cf_fc.fc_type	= MAC_Type_Control;
	cf->cf_fc.fc_subtype	= MAC_Subtype_CTS;
 	cf->cf_fc.fc_to_ds	= 0;
 	cf->cf_fc.fc_from_ds	= 0;
 	cf->cf_fc.fc_more_frag	= 0;
 	cf->cf_fc.fc_retry	= 0;
 	cf->cf_fc.fc_pwr_mgt	= 0;
 	cf->cf_fc.fc_NACK	= 0;
 	cf->cf_fc.fc_wep	= 0;
 	cf->cf_fc.fc_order	= 0;
	
	//cf->cf_duration = CTS_DURATION(rts_duration);
	STORE4BYTE(&dst, (cf->cf_ra));
	
	/* store cts tx time */
	ch->txtime() = txtime(ch->size(), basicRate_);
	
	/* calculate cts duration */
	cf->cf_duration = usec(sec(rts_duration)
                              - phymib_.getSIFS()
                              - txtime(phymib_.getCTSlen(), basicRate_));


	
	pktCTRL_ = p;
	
}

void
Mac802_11::sendACK(int uid, int nack)
{
	//Somayeh:debug
			if (uid==81)
			{
				double now = Scheduler::instance().clock();
				int x=index_;
			}
	//Somayeh
	Packet *p = Packet::alloc();
	hdr_cmn* ch = HDR_CMN(p);
	struct ack_frame *af = (struct ack_frame*)p->access(hdr_mac::offset_);

	assert(pktCTRL_ == 0);

	ch->uid() = 0;
	ch->ptype() = PT_MAC;
	// CHANGE WRT Mike's code
	ch->size() = phymib_.getACKlen();
	ch->iface() = -2;
	ch->error() = 0;
	
	bzero(af, MAC_HDR_LEN);

	af->af_fc.fc_protocol_version = MAC_ProtocolVersion;
 	af->af_fc.fc_type	= MAC_Type_Control;
 	af->af_fc.fc_subtype	= MAC_Subtype_ACK;
 	af->af_fc.fc_to_ds	= 0;
 	af->af_fc.fc_from_ds	= 0;
 	af->af_fc.fc_more_frag	= 0;
 	af->af_fc.fc_retry	= 0;
 	af->af_fc.fc_pwr_mgt	= 0;
 	
 	if (nack == 0)
 		af->af_fc.fc_NACK	= 0;
 	else
 		af->af_fc.fc_NACK	= 1
 		;
 	af->af_fc.fc_wep	= 0;
 	af->af_fc.fc_order	= 0;

	//af->af_duration = ACK_DURATION();
	STORE4BYTE(&index_, (af->af_sa));
	af->pkt_id = uid;

	/* store ack tx time */
 	ch->txtime() = txtime(ch->size(), basicRate_);
	
	/* calculate ack duration */
 	af->af_duration = 0;	
	
	pktCTRL_ = p;
}

Packet *
Mac802_11::sendCDATA() {

	//Somayeh:debug
	for (int ii=0;ii<codingCount_;ii++)
	{
		if (codingPair_[ii])
		{
			hdr_cmn* ch1 = HDR_CMN(codingPair_[ii]);
			if (ch1->uid_==81)
			{
				int x=index_;
				struct hdr_mac802_11 *dhs = HDR_MAC802_11(codingPair_[ii]);
				if (ETHER_ADDR(dhs->dh_ra)!=-1)
					x=ETHER_ADDR(dhs->dh_ra);
			}
		}
	}
	//Somayeh

	Packet *pc = Packet::alloc();
	hdr_cmn* ch_pc = HDR_CMN(pc);
	struct hdr_mac802_11_encoded *dh = HDR_MAC802_11_ENCODED(pc);
	
	ch_pc->uid() = 0;
	ch_pc->ptype() = PT_MAC;
	ch_pc->iface() = -2;
	ch_pc->error() = 0;

	bzero(dh, MAC_HDR_LEN);
	/*
	 * Update the MAC header
	 */
	 
	dh->dh_fc.fc_protocol_version = MAC_ProtocolVersion;
	dh->dh_fc.fc_type       = MAC_Type_Data;
	dh->dh_fc.fc_subtype    = MAC_Subtype_CData;
	
	dh->dh_fc.fc_to_ds      = 0;
	dh->dh_fc.fc_from_ds    = 0;
	dh->dh_fc.fc_more_frag  = 0;
	dh->dh_fc.fc_retry      = 0;
	dh->dh_fc.fc_pwr_mgt    = 0;
	dh->dh_fc.fc_NACK  = 0;
	dh->dh_fc.fc_wep        = 0;
	dh->dh_fc.fc_order      = 0;
	
	dh->dh_clen = codingCount_;
	
	//somayeh
	for (int i=0;i<MAX_NODES;i++)
		dh->eligible_list[i]=0;
	//somayeh

	struct hdr_cmn* chi;
	struct hdr_mac802_11 *dhi;
	int maxSize = 0;
	for (int i=0; i<codingCount_; i++) {
		chi = HDR_CMN(codingPair_[i]);
		dhi = HDR_MAC802_11(codingPair_[i]);
		assert((chi->size()) >= 300);
		if (chi->size() > maxSize) maxSize = chi->size();
		memcpy(dh->dh_ra[i], dhi->dh_ra, ETHER_ADDR_LEN);
		dh->pkt_id[i] = chi->uid();
	}

	memcpy(dh->dh_ta, dhi->dh_ta, ETHER_ADDR_LEN); 
	dh->dh_scontrol = dhi->dh_scontrol;
	
	// coded packet size is mac802_11_encoded header len + data len;
	pc->XOR_mhack(&codingPair_[0], codingCount_);
	ch_pc->size() = phymib_.getHdrLen11_encoded() - 
		(ETHER_ADDR_LEN + sizeof(int)) * (MAX_CODING_LEN - codingCount_) + maxSize; 

	/* store data tx time */
 	ch_pc->txtime() = txtime(ch_pc->size(), dataRate_);

// 	if((u_int32_t)ETHER_ADDR(dh->dh_ra) != MAC_BROADCAST) 
// It can't be broadcast

 	//Somayeh: the sender should wait for all neighbors in order list
 	/* Somayeh: for now we are using typical address, but if we want to change it to
 	 * some predefined values, we should be careful in this part that we are comparing
 	 * these values with address of intended forwarders
 	 */
	//Somayeh
	if (disable_intendedHop_)
	{
		int helping_neighbors=0;
		neighbor_tbl_t::iterator p;
		int ii=0;
		for (p=arptable_->my_neighbors_.neighbor_tbl_.begin();p!=arptable_->my_neighbors_.neighbor_tbl_.end();++p)
		{
			if (p->first!=index_)
			{
				bool found=false;
	 			for (int j=0;j<codingCount_;j++)
	 				if (p->first==ETHER_ADDR(dh->dh_ra[j]))
	 				{
	 					found=true;
	 					break;
	 				}
	 			if (!found)
	 			{
	 				if (!findEligible)
	 					helping_neighbors++;
	 				else
	 				{
	 					//check if this neighbor is the neighbor of one of IFs and its next hop
	 					neighbor_ent * ngb_int_fwd = arptable_->my_neighbors_.lookup_neighbor(p->first);
	 					assert(ngb_int_fwd);
	 					bool amEligible=false;
	 					for (int j=0;j<codingCount_;j++)
	 		 			{
	 		 				ftable_ent *np;
	 		 				np = ngb_int_fwd->lookup_dest(ETHER_ADDR(dh->dh_ra[j]));
							assert(np);
							assert(np->hop);
							if ((np!=NULL)&&(np->hop==ETHER_ADDR(dh->dh_ra[j]))) //it is neighbor of this IF
							{
								neighbor_ent * ngb_int_fwd1 = arptable_->my_neighbors_.lookup_neighbor(ETHER_ADDR(dh->dh_ra[j]));
		 		 				assert(ngb_int_fwd1);
		 		 				//final dest
		 						hdr_ip *iph = HDR_IP(codingPair_[j]);
		 						int mydst = Address::instance().get_nodeaddr(iph->daddr());
		 		 				ftable_ent *np1;
		 		 				np1 = ngb_int_fwd1->lookup_dest(mydst);
								assert(np1);
								assert(np1->hop);
								int intendedNextHop=-1;
								if (np1!=NULL)
								{
									intendedNextHop=np1->hop;
									//is it a neighbor of next hop too?
									np=0;
									np = ngb_int_fwd->lookup_dest(intendedNextHop);
									assert(np);
									assert(np->hop);
									if ((np!=NULL)&&(np->hop==intendedNextHop))
									{
										amEligible=true;
										break;
									}
								}
							}
	 		 			}
	 					if (amEligible)
	 					{
	 						dh->eligible_list[p->first]=1;
	 						helping_neighbors++;
	 					}
	 				}
	 			}
			}
		}
 		helping_neighbors+=codingCount_;
 		dh->dh_duration = helping_neighbors * usec(txtime(phymib_.getACKlen(), basicRate_)
 						       				       + phymib_.getSIFS())+phymib_.getSIFS();
 	}
 	else
 		dh->dh_duration = codingCount_ * usec(txtime(phymib_.getACKlen(), basicRate_)
				       + phymib_.getSIFS()); // waiting for 2 Acks
	//Somayeh End
	pktTx_ = pc;
	
//	rst_code_cw(); // set cw size of coded packet to 32/2;
	curr_tc_ = codingCount_;
	rst_cw(curr_tc_);
	
	//ack_status_ = ACK_STAT_NONE_ACKED;
	for (int i=0; i<codingCount_; i++)
		ack_status_list_[i] = NOREPLY;
	
	ch_pc->pcondition = PCOND_ENCODED;
	
	//debug jz
//	if (index_ == 7 && dh->pkt_id[0] == 7579 && dh->pkt_id[1] == 5520) {
//		printf(" here");
//	}
	
	return pc;
}

void
Mac802_11::sendDATA(Packet *p)
{
	hdr_cmn* ch = HDR_CMN(p);
	struct hdr_mac802_11* dh = HDR_MAC802_11(p);

	//Somayeh:debug
	hdr_ip *iph1 = HDR_IP(p);
	int mydst1 = Address::instance().get_nodeaddr(iph1->daddr());
	if (ch->uid_==81)
	{
		int x=index_;
		if (ETHER_ADDR(dh->dh_ra)!=-1)
			x=ETHER_ADDR(dh->dh_ra);
	}
	//Somayeh

	ch->direction() = hdr_cmn::DOWN;
	
	//assert(pktTx_ == 0); // when called for unsuccessful coded txm 
	iscoded_ = false; // reset iscoded_ for retransmitting packet left from last failed coded txm.

	//debug jz
//	if (pp_sched_->Qcodable_.length() > 0) {
//		int xxx = pp_sched_->Qcodable_.length();
//	}

	/*
	 * Update the MAC header
	 */
	ch->size() += phymib_.getHdrLen11();

	dh->dh_fc.fc_protocol_version = MAC_ProtocolVersion;
	dh->dh_fc.fc_type       = MAC_Type_Data;
	dh->dh_fc.fc_subtype    = MAC_Subtype_Data;
	
	dh->dh_fc.fc_to_ds      = 0;
	dh->dh_fc.fc_from_ds    = 0;
	dh->dh_fc.fc_more_frag  = 0;
	dh->dh_fc.fc_retry      = 0;
	dh->dh_fc.fc_pwr_mgt    = 0;
	dh->dh_fc.fc_NACK  = 0;
	dh->dh_fc.fc_wep        = 0;
	dh->dh_fc.fc_order      = 0;

	/* store data tx time */
 	ch->txtime() = txtime(ch->size(), dataRate_);

	if((u_int32_t)ETHER_ADDR(dh->dh_ra) != MAC_BROADCAST) {
		/* store data tx time for unicast packets */
		ch->txtime() = txtime(ch->size(), dataRate_);
		
		dh->dh_duration = usec(txtime(phymib_.getACKlen(), basicRate_)
				       + phymib_.getSIFS());
		
		if  (ch->pcondition == PCOND_OVERHEARD) // ||
//			 (ch->pcondition == PCOND_INTENDED_CODABLE) ||
//			 (ch->pcondition == PCOND_INTENDED_UNCODABLE) ) 
		{

			 	dh->two_hp_ip = RESERVED_END_IP;
			 	curr_tc_ = 0;

		} else if (ch->pcondition == PCOND_ORIG) {
			dh->two_hp_ip = ch->two_hop_away_ip;
			curr_tc_ = 9;
		}
		//Somayeh
		else if (ch->pcondition == PCOND_OVERHEARDANDDECODED)
		{
			if (disable_intendedHop_)
			{
				//find second next hop for dst[i]
				//later I should change DSDV and read forwarding table of dst[i] to find its next hop
				hdr_ip *iph = HDR_IP(p);
				int mydst = Address::instance().get_nodeaddr(iph->daddr());
				int intendedNextHop = ch->two_hop_away_ip;
				int intendedSecondHop=-1;
				if (mydst!=intendedNextHop)
				{
					neighbor_ent * ngb_int_fwd = arptable_->my_neighbors_.lookup_neighbor(intendedNextHop);
					assert(ngb_int_fwd);
					ftable_ent *np;
					np = ngb_int_fwd->lookup_dest(mydst);
					assert(np);
					if (np!=NULL)
					{
						intendedSecondHop=np->hop;
						dh->two_hp_ip=intendedSecondHop;
					}
					else
						dh->two_hp_ip = RESERVED_END_IP;
					/*if (mydst==0)
						intendedSecondHop=itsNextHop[0][intendedNextHop];
					else if (mydst==4)
						intendedSecondHop=itsNextHop[1][intendedNextHop];
					else if (mydst==5)
						intendedSecondHop=itsNextHop[2][intendedNextHop];
					else if (mydst==9)
						intendedSecondHop=itsNextHop[3][intendedNextHop];*/
					//ch->two_hop_away_ip=intendedSecondHop;
				}
				else
					dh->two_hp_ip = RESERVED_END_IP;
				curr_tc_ = 9; //??!!??I treat it the same as the original packet
				}
			}
		//Somayeh:End
		else {
			dh->two_hp_ip = ch->two_hop_away_ip;
			curr_tc_ = 1;
		}
		
		if ( !(pp_sched_->isCodingDisabled()) )
			curr_tc_ = 9;
		
//		if (dh->two_hp_ip != RESERVED_END_IP) {
			buffering(p->copy()); //should buffer a copy of p, not just p since p could be freed later when it is acked!!
			//rst_creq_cw();
		if ( (enable_meshgw_ != -1) ) {
			curr_tc_ = enable_meshgw_;
		}


	} else {
		/* store data tx time for broadcast packets (see 9.6) */
		ch->txtime() = txtime(ch->size(), basicRate_);
		dh->dh_duration = 0;
		curr_tc_ = 9;
	}
	
	rst_cw(curr_tc_);
	
	//debug jz
//	double now = Scheduler::instance().clock();
//	printf("send-time %f	node %d	cw %d\n", now, index_, get_cw());
	//debug jz
	
	pktTx_ = p;
}

/* ======================================================================
   Retransmission Routines
   ====================================================================== */
void
Mac802_11::RetransmitRTS()
{
	assert(pktTx_);
	assert(pktRTS_);
	assert(mhBackoff_.busy() == 0);
	macmib_.RTSFailureCount++;


	ssrc_ += 1;			// STA Short Retry Count
		
	if(ssrc_ >= macmib_.getShortRetryLimit()) {
		discard(pktRTS_, DROP_MAC_RETRY_COUNT_EXCEEDED); pktRTS_ = 0;
		/* tell the callback the send operation failed 
		   before discarding the packet */
		hdr_cmn *ch = HDR_CMN(pktTx_);
		if (ch->xmit_failure_) {
                        /*
                         *  Need to remove the MAC header so that 
                         *  re-cycled packets don't keep getting
                         *  bigger.
                         */
			ch->size() -= phymib_.getHdrLen11();
                        ch->xmit_reason_ = XMIT_REASON_RTS;
                        ch->xmit_failure_(pktTx_->copy(),
                                          ch->xmit_failure_data_);
                }
		discard(pktTx_, DROP_MAC_RETRY_COUNT_EXCEEDED); 
		pktTx_ = 0;
		ssrc_ = 0;
		rst_cw(0);
	} else {
		struct rts_frame *rf;
		rf = (struct rts_frame*)pktRTS_->access(hdr_mac::offset_);
		rf->rf_fc.fc_retry = 1;

		inc_cw(0);
		mhBackoff_.start(cw_, is_idle());
	}
}

void
Mac802_11::RetransmitDATA()
{
	struct hdr_cmn *ch;
	struct hdr_mac802_11 *mh;
	u_int32_t *rcount, thresh;
	assert(mhBackoff_.busy() == 0);

	assert(pktTx_);
	assert(pktRTS_ == 0);

	ch = HDR_CMN(pktTx_);
	mh = HDR_MAC802_11(pktTx_);
	//Somayeh:debug
	if (ch->uid_==81)
		int x=index_;
	//Somayeh:end

	if (( ch->pcondition == PCOND_OVERHEARD )/*Somayeh||(ch->pcondition == PCOND_OVERHEARDANDDECODED)/*Somayeh*/)
		curr_tc_ = 0;
	else if ( ch->pcondition == PCOND_ENCODED )
		curr_tc_ = codingCount_;
	else if (( ch->pcondition == PCOND_ORIG )/*Somayeh*/||(ch->pcondition == PCOND_OVERHEARDANDDECODED)/*Somayeh*/) //??!!??I treat it the same as the native packet
		curr_tc_ = 9;
	else
		curr_tc_ = 1;
	
	if ( !(pp_sched_->isCodingDisabled()) )
		curr_tc_ = 9;
	/*
	 *  Broadcast packets don't get ACKed and therefore
	 *  are never retransmitted.
	 */
	if((u_int32_t)ETHER_ADDR(mh->dh_ra) == MAC_BROADCAST) {
		Packet::free(pktTx_); 
		pktTx_ = 0;

		/*
		 * Backoff at end of TX.
		 */
		rst_cw(0);
		mhBackoff_.start(cw_, is_idle());

		return;
	}

	macmib_.ACKFailureCount++;

	if((u_int32_t) ch->size() <= macmib_.getRTSThreshold()) {
                rcount = &ssrc_;
               thresh = macmib_.getShortRetryLimit();
        } else {
                rcount = &slrc_;
               thresh = macmib_.getLongRetryLimit();
        }

	(*rcount)++;

	if(*rcount >= thresh) {
		/* IEEE Spec section 9.2.3.5 says this should be greater than
		   or equal */
		macmib_.FailedCount++;
		/* tell the callback the send operation failed 
		   before discarding the packet */
		hdr_cmn *ch = HDR_CMN(pktTx_);
		if (ch->xmit_failure_) {
                        ch->size() -= phymib_.getHdrLen11();
			ch->xmit_reason_ = XMIT_REASON_ACK;
                        ch->xmit_failure_(pktTx_->copy(),
                                          ch->xmit_failure_data_);
                }

		discard(pktTx_, DROP_MAC_RETRY_COUNT_EXCEEDED); 
		pktTx_ = 0;
		*rcount = 0;
		rst_cw(0);
	}
	else {
		struct hdr_mac802_11 *dh;
		dh = HDR_MAC802_11(pktTx_);
		dh->dh_fc.fc_retry = 1;


		sendRTS(ETHER_ADDR(mh->dh_ra));
		inc_cw(curr_tc_);
		mhBackoff_.start(cw_, is_idle());
	}
	
	//debug jz
//	double now = Scheduler::instance().clock();
//	printf("resend-time %f	node %d	cw %d\n", now, index_, get_cw());
	//debug jz
	
}

/* ======================================================================
   Incoming Packet Routines
   ====================================================================== */
void
Mac802_11::send(Packet *p, Handler *h)
{
	//Somayeh:debug
	hdr_cmn* ch1 = HDR_CMN(p);
	if (!iscoded_)
	{
	if (ch1->uid_==81)
	{
		int x=index_;
		struct hdr_mac802_11 *dhs = HDR_MAC802_11(p);
		if (ETHER_ADDR(dhs->dh_ra)!=-1)
			x=ETHER_ADDR(dhs->dh_ra);
		double now = Scheduler::instance().clock();
	}
	}
	else
	{
		struct hdr_mac802_11_encoded* edh1 = HDR_MAC802_11_ENCODED(p);
		for (int i=0;i<codingCount_;i++)
			if (edh1->pkt_id[i]==81)
			{
				int x=index_;
				double now = Scheduler::instance().clock();
			}
	}
	//Somayeh

	double rTime;
	struct hdr_mac802_11* dh = HDR_MAC802_11(p);
	struct hdr_mac802_11_encoded* edh = HDR_MAC802_11_ENCODED(p);

	//Somayeh:debug
		//if (ETHER_ADDR(dh->dh_ra)!=-1)
		//	int x=ETHER_ADDR(dh->dh_ra);
		//hdr_cmn* ch = HDR_CMN(p);
		//int current=index_;
		//hdr_ip *iph1 = HDR_IP(p);
		//int mydst = Address::instance().get_nodeaddr(iph1->daddr());
		//Somayeh

	EnergyModel *em = netif_->node()->energy_model();
	if (em && em->sleep()) {
		em->set_node_sleep(0);
		em->set_node_state(EnergyModel::INROUTE);
	}
	
	callback_ = h;
//	sendDATA(p);
	sendRTS(ETHER_ADDR(dh->dh_ra));

	/*
	 * Assign the data packet a sequence number.
	 */
	if (iscoded_)
		edh->dh_scontrol = sta_seqno_++;
	else
		dh->dh_scontrol = sta_seqno_++;

	/*
	 *  If the medium is IDLE, we must wait for a DIFS
	 *  Space before transmitting.
	 */
	if(mhBackoff_.busy() == 0) {
		if(is_idle()) {
			if (mhDefer_.busy() == 0) {
				/*
				 * If we are already deferring, there is no
				 * need to reset the Defer timer.
				 */
				rTime = (Random::random() % cw_)
					* (phymib_.getSlotTime());
	
				double dtime;
				if ( !disable_oppfwd_ )
					dtime = phymib_.getAIFS(curr_tc_);
				else
					dtime = phymib_.getDIFS();
							
				mhDefer_.start(dtime + rTime);
//				mhDefer_.start(dtime);
//bugfix UKA: transmission
			}
		} else {
			/*
			 * If the medium is NOT IDLE, then we start
			 * the backoff timer.
			 */
			mhBackoff_.start(cw_, is_idle());
		}
	}
}

void
Mac802_11::recv(Packet *p, Handler *h)
{
	struct hdr_cmn *hdr = HDR_CMN(p);

	//Somayeh:debug
	if (!iscoded_)
	{
	if (hdr->uid_==81)
	{
		int x=index_;
		struct hdr_mac802_11 *dhs = HDR_MAC802_11(p);
		if (ETHER_ADDR(dhs->dh_ra)!=-1)
			x=ETHER_ADDR(dhs->dh_ra);
	}
	}
	else
	{
		struct hdr_mac802_11_encoded* edh1 = HDR_MAC802_11_ENCODED(p);
		for (int i=0;i<codingCount_;i++)
			if (edh1->pkt_id[i]==81)
			{
				int x=index_;
				double now = Scheduler::instance().clock();
			}
	}
	//Somayeh


	/*
	 * Sanity Check
	 */
	assert(initialized());

//	int uidd = hdr_cmn::access(p)->uid();
//	double now = Scheduler::instance().clock();
//	if (uidd == 812 && index_ == 12) {
//		printf(" ssss");
//	}//debug jz

	/*
	 *  Handle outgoing packets.
	 */
	 
	if(hdr->direction() == hdr_cmn::DOWN) {
		if (index_==3)
			int xxx=0;
		if (iscoded_)
			p = sendCDATA(); // generate a new coded frame from the packet pair and add mac header;
		else { 
			// native
 			//u_int32_t Mac_addr = (u_int32_t)ETHER_ADDR(dh->dh_ra);
//			struct hdr_mac802_11 *eh = HDR_MAC802_11(p);
		
//			if (eh->dh_fc.fc_type != MAC_Type_Data) // means this is new not the left one
				sendDATA(p); // add mac header for it
		}
		send(p, h);
        return;
    }
    

	/*
	 *  Handle incoming packets.
	 *
	 *  We just received the 1st bit of a packet on the network
	 *  interface.
	 *
	 */

	/*
	 *  If the interface is currently in transmit mode, then
	 *  it probably won't even see this packet.  However, the
	 *  "air" around me is BUSY so I need to let the packet
	 *  proceed.  Just set the error flag in the common header
	 *  to that the packet gets thrown away.
	 */
	if(tx_active_ && hdr->error() == 0) {
		hdr->error() = 1;
	}

	if(rx_state_ == MAC_IDLE) {
		setRxState(MAC_RECV);
		pktRx_ = p;
		/*
		 * Schedule the reception of this packet, in
		 * txtime seconds.
		 */
		mhRecv_.start(txtime(p));
	} else {
		/*
		 *  If the power of the incoming packet is smaller than the
		 *  power of the packet currently being received by at least
                 *  the capture threshold, then we ignore the new packet.
		 */
		if(pktRx_->txinfo_.RxPr / p->txinfo_.RxPr >= p->txinfo_.CPThresh) { // It is NOT decibel
			pktRx_->txinfo_.InterferencePr += p->txinfo_.RxPr;
			capture(p);
		} else {
			collision(p);
		}
	}
}

void
Mac802_11::recv_timer()
{
	int x=index_;
	u_int32_t src; 
	hdr_cmn *ch = HDR_CMN(pktRx_);
	hdr_mac802_11 *mh = HDR_MAC802_11(pktRx_);
	
	u_int8_t  type = mh->dh_fc.fc_type;
	u_int8_t  subtype = mh->dh_fc.fc_subtype;
	
	u_int32_t dst;
	if (subtype == MAC_Subtype_ACK) {
		dst = ETHER_ADDR(((ack_frame *) mh)->af_sa); // for ACK, dst is the sender of this ACK
//		if (index_ == 2 && ((ack_frame *) mh)->pkt_id == 22339 ) { //debug jz
//			double now = Scheduler::instance().clock(); // debug jz
//		}
	}
	else if (subtype == MAC_Subtype_CData)
		dst = 9999; // there is list of dst for coded packet
	else
		dst = ETHER_ADDR(mh->dh_ra);

	assert(pktRx_);
	assert(rx_state_ == MAC_RECV || rx_state_ == MAC_COLL);
	
        /*
         *  If the interface is in TRANSMIT mode when this packet
         *  "arrives", then I would never have seen it and should
         *  do a silent discard without adjusting the NAV.
         */
        if(tx_active_) {
                Packet::free(pktRx_);
                pktRx_ = 0;
                goto done;
        }

	/*
	 * Handle collisions.
	 */
	if(rx_state_ == MAC_COLL) {
		discard(pktRx_, DROP_MAC_COLLISION);	
		pktRx_ = 0;	
		set_nav(usec(phymib_.getEIFS()));
		goto done;
	}

	int snr;
	double fer,tmp_random;

	switch(type) {
	case MAC_Type_Management:
		fer = ErrorModel80211::frameErrorRate(EM80211_DATA,pktRx_->txinfo_.RxPr,pktRx_->txinfo_.InterferencePr,basicRate_,ch->size_, &snr);
		break;

	case MAC_Type_Control:
		switch(subtype) {
		case MAC_Subtype_RTS:
			fer = ErrorModel80211::frameErrorRate(EM80211_RTS,pktRx_->txinfo_.RxPr,pktRx_->txinfo_.InterferencePr,basicRate_,ch->size_, &snr);
			break;
		case MAC_Subtype_CTS:
			fer = ErrorModel80211::frameErrorRate(EM80211_CTS,pktRx_->txinfo_.RxPr,pktRx_->txinfo_.InterferencePr,basicRate_,ch->size_, &snr);
			break;
		case MAC_Subtype_ACK:
			fer = ErrorModel80211::frameErrorRate(EM80211_ACK,pktRx_->txinfo_.RxPr,pktRx_->txinfo_.InterferencePr,basicRate_,ch->size_, &snr);
			break;
		default:
			fer = ErrorModel80211::frameErrorRate(EM80211_DATA,pktRx_->txinfo_.RxPr,pktRx_->txinfo_.InterferencePr,basicRate_,ch->size_, &snr);
		}
		break;

	case MAC_Type_Data:
		fer = ErrorModel80211::frameErrorRate(EM80211_DATA,pktRx_->txinfo_.RxPr,pktRx_->txinfo_.InterferencePr,dataRate_,ch->size_, &snr);
		break;

	default:
		fer = ErrorModel80211::frameErrorRate(EM80211_DATA,pktRx_->txinfo_.RxPr,pktRx_->txinfo_.InterferencePr,dataRate_,ch->size_, &snr);
		break;
	}

	if ( link_ber_ != -1 ) // set it to -1 to disable this.
		fer = ErrorModel80211::frameErrorRate(link_ber_, ch->size());

	tmp_random = Random::uniform(0,1);
	if(tmp_random < fer) {
		//fprintf(stderr, 
		//printf("%f | STA %d | received frame (type %d) discarded due to high BER: rate %.0f, snr %d, fer %f\n",
        //                        NOW, addr(), type, dataRate_, snr, fer);
		ch->error() = 1;
	}


	/*
	 * Check to see if this packet was received with enough
	 * bit errors that the current level of FEC still could not
	 * fix all of the problems - ie; after FEC, the checksum still
	 * failed.
	 */
	if( ch->error() ) {
		Packet::free(pktRx_);
		pktRx_ = 0;
		set_nav(usec(phymib_.getEIFS()));
		goto done;
	}

	/*
	 * IEEE 802.11 specs, section 9.2.5.6
	 *	- update the NAV (Network Allocation Vector)
	 */
	if(dst != (u_int32_t)index_ && subtype != MAC_Subtype_ACK) { // for ack, check it is for me or not.
											// if it is not for me, then set nav (in recvACK)
		set_nav(mh->dh_duration);
	}

        /* tap out - */
        if (tap_ && type == MAC_Type_Data &&
            MAC_Subtype_Data == subtype ) 
		tap_->tap(pktRx_);
	/*
	 * Adaptive Fidelity Algorithm Support - neighborhood infomation 
	 * collection
	 *
	 * Hacking: Before filter the packet, log the neighbor node
	 * I can hear the packet, the src is my neighbor
	 */
	 

//	assert(arptable_);
    //if (!disable_intendedHop_)
    //{
    	if (subtype == MAC_Subtype_Data) {
    		src = ETHER_ADDR(mh->dh_ta);
    		arptable_->my_neighbors_.add_neighbor(src, 1);
    	}  else if (subtype == MAC_Subtype_ACK) {
    		src = ETHER_ADDR(((ack_frame *)mh)->af_sa); // The ACK's dh_ta is fcs which is always 0.
    		arptable_->my_neighbors_.add_neighbor(src, 1);
    	}  else if (subtype == MAC_Subtype_CData) {
    		src = ETHER_ADDR(((hdr_mac802_11_encoded *)mh)->dh_ta);
    		arptable_->my_neighbors_.add_neighbor(src, 1);
    	}
    //}
//	if (netif_->node()->energy_model() && 
//	    netif_->node()->energy_model()->adaptivefidelity()) {
//		netif_->node()->energy_model()->add_neighbor(src);
//	}
			
	/*
	 * Address Filtering
	 */
	 
	if (type == MAC_Type_Data && subtype == MAC_Subtype_CData) { // if it is coded, there are >2 dst addresses
		recvCodedDATA(pktRx_);
		goto done;
	} 
	if(dst != (u_int32_t)index_ && dst != MAC_BROADCAST) {
		if (type == MAC_Type_Control && subtype == MAC_Subtype_ACK) {
				recvACK(pktRx_); // since RA in ACK is replaced with SA, ACK needs to be handled here
		} else if (type == MAC_Type_Data) {
				recvOverheardDATA(pktRx_); // handling overheard native DATA; i.e. DATA frames not addressed to me
		} else
			discard(pktRx_, "---");
			pktRx_ = 0;
		goto done;
	}

	switch(type) {

	case MAC_Type_Management:
		discard(pktRx_, DROP_MAC_PACKET_ERROR);
		pktRx_ = 0;
		goto done;
	case MAC_Type_Control:
		switch(subtype) {
		case MAC_Subtype_RTS:
			recvRTS(pktRx_);
			break;
		case MAC_Subtype_CTS:
			recvCTS(pktRx_);
			break;
		case MAC_Subtype_ACK:
			assert(0);		// verify that it will be executed at all; remove these later;
			recvACK(pktRx_); // since RA in ACK is replace with SA, it will never go here;
			break;
		default:
			fprintf(stderr,"recvTimer1:Invalid MAC Control Subtype %x\n",
				subtype);
			exit(1);
		}
		break;
	case MAC_Type_Data:
		switch(subtype) {
		case MAC_Subtype_Data:
			recvDATA(pktRx_);
			break;
		default:
			fprintf(stderr, "recv_timer2:Invalid MAC Data Subtype %x\n",
				subtype);
			exit(1);
		}
		break;
	default:
		fprintf(stderr, "recv_timer3:Invalid MAC Type %x\n", subtype);
		exit(1);
	}
 done:
	pktRx_ = 0;
	rx_resume();
}


void
Mac802_11::recvRTS(Packet *p)
{
	struct rts_frame *rf = (struct rts_frame*)p->access(hdr_mac::offset_);

	if(tx_state_ != MAC_IDLE) {
		discard(p, DROP_MAC_BUSY);
		return;
	}

	/*
	 *  If I'm responding to someone else, discard this RTS.
	 */
	if(pktCTRL_) {
		discard(p, DROP_MAC_BUSY);
		return;
	}

	sendCTS(ETHER_ADDR(rf->rf_ta), rf->rf_duration);

	/*
	 *  Stop deferring - will be reset in tx_resume().
	 */
	if(mhDefer_.busy()) mhDefer_.stop();

	tx_resume();

	mac_log(p);
}

/*
 * txtime()	- pluck the precomputed tx time from the packet header
 */
double
Mac802_11::txtime(Packet *p)
{
	struct hdr_cmn *ch = HDR_CMN(p);
	double t = ch->txtime();
	if (t < 0.0) {
		drop(p, "XXX");
 		exit(1);
	}
	return t;
}

 
/*
 * txtime()	- calculate tx time for packet of size "psz" bytes 
 *		  at rate "drt" bps
 */
double
Mac802_11::txtime(double psz, double drt)
{
	//double dsz = psz - phymib_.getPLCPhdrLen();
        //int plcp_hdr = phymib_.getPLCPhdrLen() << 3;	

	double dsz = psz - ((phymib_.getPreambleLength() >> 3) +
                            (phymib_.getPLCPhdrLen() >> 3));
        int preamble_len = phymib_.getPreambleLength();
        int plcp_len = phymib_.getPLCPhdrLen();

	int datalen = (int)dsz << 3;
//	double t = (((double)plcp_hdr)/phymib_.getPLCPDataRate())
//                                      + (((double)datalen)/drt);
//	return(t);

	double t = (double)preamble_len/phymib_.getPreambleDataRate() +
                   (double)plcp_len/phymib_.getPLCPDataRate() +
                   (double)datalen/drt;
        /* fprintf(stderr, "%f preamble %d @ %f + PLCP %d @ %f, "
                        "data %d @ %f --> txtime %f\n",
                        NOW, preamble_len, phymib_.getPreambleDataRate(),
                        plcp_len, phymib_.getPLCPDataRate(),
                        datalen, drt, t); */
        // end of RealChannelPropagation ----------------------------
        return(t);
}




void
Mac802_11::recvCTS(Packet *p)
{
	if(tx_state_ != MAC_RTS) {
		discard(p, DROP_MAC_INVALID_STATE);
		return;
	}

	assert(pktRTS_);
	Packet::free(pktRTS_); pktRTS_ = 0;

	assert(pktTx_);	
	mhSend_.stop();

	/*
	 * The successful reception of this CTS packet implies
	 * that our RTS was successful. 
	 * According to the IEEE spec 9.2.5.3, you must 
	 * reset the ssrc_, but not the congestion window.
	 */
	ssrc_ = 0;
	tx_resume();

	mac_log(p);
}

void
Mac802_11::recvCodedDATA(Packet *p) {
	hdr_mac802_11_encoded *cmh = HDR_MAC802_11_ENCODED(p);
	u_char clen = cmh->dh_clen;
	u_int32_t dst[MAX_CODING_LEN];
	int pid[MAX_CODING_LEN];
	
	u_int32_t src = ETHER_ADDR(cmh->dh_ta);
	Packet * myp = 0;
	
	int my_pos = -1;
	
	assert(clen > 0 && clen <= MAX_CODING_LEN);
	for (int i=0; i<clen; i++) {
		dst[i] = ETHER_ADDR(cmh->dh_ra[i]);
		assert (dst[i] != MAC_BROADCAST);
		if (dst[i] == index_) my_pos = i;
		pid[i] = cmh->pkt_id[i];

		//Somayeh:debug
		if (pid[i]==81)
		{
			int x=index_;
			x=3;
		}
		//Somayeh

	}
	


	if (my_pos == -1) { // my addr is not in the list, it is not for me.
		if ( (pktTx_ != 0) ) {
			struct hdr_cmn * txch = HDR_CMN(pktTx_); 
			for (int i=0; i<clen; i++) {
				if ( (dst[i] == txch->two_hop_away_ip && cmh->pkt_id[i] == txch->uid()) )
				{// although not sent to me, but forwarded for me.
					assert(!mhSend_.busy());
					currTxm_postProcess(); // free pktTx_ and reset the cw, ssrc, timers..., and retrieve next pkt from Q
				}
			}
		} 
		// not sure if above code is useful or not
		if (index_==1&&dst[0]==3)
			int xxx=0;
		//Somayeh
		if (disable_intendedHop_)
		{
			if ((ACKWaiting_.busy()==0)&&(!findEligible)) //if I am not waiting for an ACK
			{
				bool canHelp=false;
				for (int i=0; i<clen; i++)
				{
					if (arptable_->my_neighbors_.lookup_neighbor(dst[i]))
					{
						//I am not intended forwarder but I can help if I can decode
						Packet * helpedp = 0;
						helpedp = decode_mhack(p, pid, clen, i);
						//Can I really decode and help?
						if (helpedp)
						{
							//find next hop for dst[i]
							hdr_ip *iph = HDR_IP(helpedp);
							int mydst = Address::instance().get_nodeaddr(iph->daddr());
							int intendedNextHop=-1;
							if (dst[i]!=mydst)
							{
								neighbor_ent * ngb_int_fwd = arptable_->my_neighbors_.lookup_neighbor(dst[i]);
								//Somayeh:Debug
								//myfile.open ("neighbors.txt",std::ios_base::app);
								//myfile << "current_node="<<index_<<" dst="<<mydst<<" intended="<<dst[i];
								assert(ngb_int_fwd);

								//myfile <<"  OK";
								ftable_ent *np;
								np = ngb_int_fwd->lookup_dest(mydst);
								assert(np);

								//myfile << " nextHop="<<np->hop<<"\n";

								assert(np->hop);
								if (np!=NULL)
									intendedNextHop=np->hop;
								//myfile.close();
								//Somayeh:DEnd
							}
							//check whether it is your neighbor
							if (arptable_->my_neighbors_.lookup_neighbor(intendedNextHop))
							{
								canHelp=true;
								//save specification of coded packet!
								pktHelp_=helpedp;
								struct hdr_cmn *cph = HDR_CMN(pktHelp_);
								cph->num_forwards() += 1;
								cph->prev_fwd_mac = src;
								//cph->last_hop_=dst[i];
								cph->two_hop_away_ip = intendedNextHop;//??????
								//cph->pcondition = PCOND_DECODED;
								cph->pcondition = PCOND_OVERHEARDANDDECODED;
								//hdr_mac802_11_encoded *eph = HDR_MAC802_11_ENCODED(pktHelp_);
								struct hdr_mac802_11 *ph = HDR_MAC802_11(pktHelp_);

								int myIndex=0;
								order_list.clear();
								for (int jj=0;jj<clen;jj++)
									order_list.push_back(dst[i]);
								neighbor_ent * ngb_int_fwd = arptable_->my_neighbors_.lookup_neighbor(src);
								neighbor_tbl_t::iterator p;
								for (p=ngb_int_fwd->next_neighbors->neighbor_tbl_.begin();p!=ngb_int_fwd->next_neighbors->neighbor_tbl_.end();++p)
								{
									bool found=false;
									for (int jj=0;jj<clen;jj++)
										if (dst[jj]==p->first)
										{
											found=true;
											break;
										}
									if ((!found)&&(p->first<index_))
									{
										order_list.push_back(p->first);
										myIndex++;
									}
								}
								//it should wait for a while
								/*we should consider all those intended fwds which send their ACKs back to back
								 * before our intended fwd and are not listed in order-list before us
								*/

								/*double myBackoff= (myIndex+1) * (phymib_.getSIFS() + txtime(phymib_.getACKlen(), basicRate_));
								myBackoff+=phymib_.getSIFS();*/

								double myBackoff= phymib_.getSIFS()
									+DSSS_MaxPropagationDelay
									+(myIndex) * (phymib_.getSIFS() + txtime(phymib_.getACKlen(), basicRate_)+DSSS_MaxPropagationDelay)
									+(clen)*(phymib_.getSIFS() + txtime(phymib_.getACKlen(), basicRate_));

								ACKWaiting_.start(myBackoff);
								//debug:Somayeh
								//double now = Scheduler::instance().clock();
								//myfile.open ("example1.txt",std::ios_base::app);
								//myfile << "Packet#"<<cph->uid_<<" encoded in node#"<<index_<<" intend_fwd="<<dst[i]<<" prev_fwd="<<src<<" next_fwd="<<intendedNextHop<<" dest="<<mydst<<" time="<<now<<"\n";
								//myfile.close();
								//debug:end
								//Somayeh:debug
								if (cph->uid_==81)
								{
									int x=index_;
									if (ETHER_ADDR(ph->dh_ra)!=-1)
										x=ETHER_ADDR(ph->dh_ra);
								}
								//Somayeh
								break;
							}
						}
					}
				}
				//if (!canHelp)
					discard(p, "CDATA_OVHRD");
			}
			else if ((ACKWaiting_.busy()==0)&&(findEligible)) //if I am not waiting for an ACK
			{
				if (cmh->eligible_list[index_]==1)// if this node is an eligible non-intended forwarder
				{
					bool canHelp=false;
					for (int i=0; i<clen; i++)
					{
						if (arptable_->my_neighbors_.lookup_neighbor(dst[i]))
						{
							//I am not intended forwarder but I can help if I can decode
							Packet * helpedp = 0;
							helpedp = decode_mhack(p, pid, clen, i);
							//Can I really decode and help?
							if (helpedp)
							{
								//find next hop for dst[i]
								hdr_ip *iph = HDR_IP(helpedp);
								int mydst = Address::instance().get_nodeaddr(iph->daddr());
								int intendedNextHop=-1;
								if (dst[i]!=mydst)
								{
									neighbor_ent * ngb_int_fwd = arptable_->my_neighbors_.lookup_neighbor(dst[i]);
									//Somayeh:Debug
									//myfile.open ("neighbors.txt",std::ios_base::app);
									//myfile << "current_node="<<index_<<" dst="<<mydst<<" intended="<<dst[i];
									assert(ngb_int_fwd);

									//myfile <<"  OK";
									ftable_ent *np;
									np = ngb_int_fwd->lookup_dest(mydst);
									assert(np);

									//myfile << " nextHop="<<np->hop<<"\n";

									assert(np->hop);
									if (np!=NULL)
										intendedNextHop=np->hop;
									//myfile.close();
									//Somayeh:DEnd
								}
								//check whether it is your neighbor
								if (arptable_->my_neighbors_.lookup_neighbor(intendedNextHop))
								{
									canHelp=true;
									//save specification of coded packet!
									pktHelp_=helpedp;
									struct hdr_cmn *cph = HDR_CMN(pktHelp_);
									cph->num_forwards() += 1;
									cph->prev_fwd_mac = src;
									//cph->last_hop_=dst[i];
									cph->two_hop_away_ip = intendedNextHop;//??????
									//cph->pcondition = PCOND_DECODED;
									cph->pcondition = PCOND_OVERHEARDANDDECODED;
									//hdr_mac802_11_encoded *eph = HDR_MAC802_11_ENCODED(pktHelp_);
									struct hdr_mac802_11 *ph = HDR_MAC802_11(pktHelp_);

									int myIndex=0;
									order_list.clear();
									for (int jj=0;jj<clen;jj++)
										order_list.push_back(dst[i]);

									for (int jj=0;jj<MAX_NODES;jj++)
										if (cmh->eligible_list[jj]==1)
										{
											order_list.push_back(jj);
											if (jj<index_)
												myIndex++;
										}
									//it should wait for a while
									/*we should consider all those intended fwds which send their ACKs back to back
									 * before our intended fwd and are not listed in order-list before us
									*/

									/*double myBackoff= (myIndex+1) * (phymib_.getSIFS() + txtime(phymib_.getACKlen(), basicRate_));
									myBackoff+=phymib_.getSIFS();*/

									double myBackoff= phymib_.getSIFS()
										+DSSS_MaxPropagationDelay
										+(myIndex) * (phymib_.getSIFS() + txtime(phymib_.getACKlen(), basicRate_)+DSSS_MaxPropagationDelay)
										+(clen)*(phymib_.getSIFS() + txtime(phymib_.getACKlen(), basicRate_));

									ACKWaiting_.start(myBackoff);
									//debug:Somayeh
									//double now = Scheduler::instance().clock();
									//myfile.open ("example1.txt",std::ios_base::app);
									//myfile << "Packet#"<<cph->uid_<<" encoded in node#"<<index_<<" intend_fwd="<<dst[i]<<" prev_fwd="<<src<<" next_fwd="<<intendedNextHop<<" dest="<<mydst<<" time="<<now<<"\n";
									//myfile.close();
									//debug:end
									//Somayeh:debug
									if (cph->uid_==81)
									{
										int x=index_;
										if (ETHER_ADDR(ph->dh_ra)!=-1)
											x=ETHER_ADDR(ph->dh_ra);
									}
									//Somayeh
									break;
								}
							}
						}
					}
					//if (!canHelp)
						discard(p, "CDATA_OVHRD");
				}
			}
		}
		else
			discard(p, "CDATA_OVHRD");
		//Somayeh: shouldn't it be only for discard case?
		return;

	} else // yes  it is for me. I need to decode the native packet for me.
		myp = decode_mhack(p, pid, clen, my_pos);
	
	if (!myp) {
//		printf("CoFail-%f on N%d - myP-%d src-%d Myuid-%d CodeLen-%d\n",
//			Scheduler::instance().clock(), index_, my_pos, src, cmh->pkt_id[my_pos], clen);
		discard(p, "CoFail");

		sendACK(pid[my_pos], 1); // NACK
		ack_defer_ = phymib_.getSIFS() + my_pos * (phymib_.getSIFS() + hdr_cmn::access(pktCTRL_)->txtime());
		if(mhSend_.busy() == 0)
			tx_resume();
	    else { // bugfix UKA
               // the station is waiting for a timeout. Stop waiting and 
               // schedule a retransmit (done by sendHandler). tx_resume 
               // to send the ACK is called from within sendHandler!
            mhSend_.stop();
            sendHandler();
        }
				
		return; 
	} 

	struct hdr_cmn *ch = HDR_CMN(myp);			
	ch->num_forwards() += 1;
	ch->prev_fwd_mac = src;
	//ch->last_hop_=index_;
//	ch->intended_mac = index_;
//	ch->two_hop_away_ip = dh->two_hp_ip;
	ch->pcondition = PCOND_DECODED; 

//	if(pktCTRL_) {
//		discard(p, DROP_MAC_BUSY);
//		return;
//	}

	//somayeh:debug
				int current=index_;
				struct hdr_mac802_11 *cmh1 = HDR_MAC802_11(myp);
				hdr_ip *iph1 = HDR_IP(myp);
				int mydst = Address::instance().get_nodeaddr(iph1->daddr());
				if (ch->uid_==81)
				{
					int x=index_;
					if (ETHER_ADDR(cmh1->dh_ra)!=-1)
						x=ETHER_ADDR(cmh1->dh_ra);
				}
				//somayeh

	//Somayeh
		if ((use_ACK)&&(disable_intendedHop_))
		{
			//find next hop
			hdr_ip *iph = HDR_IP(myp);
			int mydst1 = Address::instance().get_nodeaddr(iph->daddr());
			int intendedNextHop=-1;

			/*if (mydst1==0)
				intendedNextHop=itsNextHop[0][index_];
			else if (mydst1==4)
				intendedNextHop=itsNextHop[1][index_];
			else if (mydst1==5)
				intendedNextHop=itsNextHop[2][index_];
			else if (mydst1==9)
				intendedNextHop=itsNextHop[3][index_];*/
			if (mydst1!=index_)
			{
				neighbor_ent * ngb_int_fwd = arptable_->my_neighbors_.lookup_neighbor(index_);
				assert(ngb_int_fwd);
				ftable_ent *np;
				np = ngb_int_fwd->lookup_dest(mydst1);
				assert(np);
				intendedNextHop=np->hop;
				if (pp_sched_->IsThereAnyValidACK(ch->uid_,intendedNextHop))
				{
					sendACK(ch->uid(), 0);
					ack_defer_ = phymib_.getSIFS() + my_pos * (phymib_.getSIFS() + hdr_cmn::access(pktCTRL_)->txtime());
					if(mhSend_.busy() == 0)
						tx_resume();
					drop(myp, "Already exist in downstream");
					return;
				}
			}

		}
		//Somayeh:end


	sendACK(ch->uid(), 0);
	ack_defer_ = phymib_.getSIFS() + my_pos * (phymib_.getSIFS() + hdr_cmn::access(pktCTRL_)->txtime());
	if(mhSend_.busy() == 0)
		tx_resume();
	
	//debug:Somayeh
	//myfile.open ("example1.txt",std::ios_base::app);
	//myfile << "Packet#"<<ch->uid_<<" encoded and transmitted by intended-fwd node#"<<index_<<" prev_fwd="<<src<<" dest="<<mydst<<"\n";
	//myfile.close();
	//debug:end
	uptarget_->recv(myp, (Handler*) 0);
	
	if ( (pktTx_ != 0) ) {
	struct hdr_cmn * txch = HDR_CMN(pktTx_); 
	for (int i=0; i<clen; i++) {
		if ( (dst[i] == txch->two_hop_away_ip && cmh->pkt_id[i] == txch->uid()) ) {
		// although not sent to me, but forwarded for me.
			assert(!mhSend_.busy());
			currTxm_postProcess(); // free pktTx_ and reset the cw, ssrc, timers..., and retrieve next pkt from Q
			}
		}
	} 
	discard(p, "RCVED_MY_CODED");
	
}

Packet *
Mac802_11::decode_mhack(Packet *p_coded, int *pid, u_char clen, int my_pos) {
	Packet *my_p = NULL, *partner_p;
	u_char *walk = p_coded->accessdata();
	int total_partnerLen = 0;
	int prev_partnerLen = 0;
		
	for (int i=0; i<clen; i++) {
		if (i == my_pos) {
			prev_partnerLen = total_partnerLen;
		} else {
			int partner_uid = pid[i];
			uid_pkt_tbl_t::iterator mp = uid_pkt_Cbuffer_.find(partner_uid);
			if (mp == uid_pkt_Cbuffer_.end())
				return NULL;
			else {
				partner_p = mp->second;
				total_partnerLen += partner_p->hdrlen_;
			}
		}
	}
		
	my_p = Packet::alloc();
	hdr_cmn* ch = HDR_CMN(my_p);

	int my_len = p_coded->datalen() - total_partnerLen;
	memcpy(my_p->bits(), walk + prev_partnerLen, my_len);
	ch->direction() = hdr_cmn::UP;	
//	coding_buffer_.remove(partner_p, partner_p->prev_);  // do we need it?
	
	return my_p;	
}


Packet * 
Mac802_11::decode_hack(Packet *p_coded, int partner_uid, int partner_position) {
	//search buffer for p1.uid; don't have to de-buffer p1;
	//Packet *p_rcvd = allocpkt ();
	//u_char walk = p->accessdata();
	// appdata.length - p1->hdr_len = p0->hdr_len

	Packet *my_p = NULL, *partner_p;
	uid_pkt_tbl_t::iterator mp = uid_pkt_Cbuffer_.find(partner_uid);
	if (mp == uid_pkt_Cbuffer_.end())
		return NULL;
	else
		partner_p = mp->second;
		
	my_p = Packet::alloc();
	hdr_cmn* ch = HDR_CMN(my_p);
	u_char *walk = p_coded->accessdata();

	int my_len = p_coded->datalen() - partner_p->hdrlen_;
	if (partner_position == 0)
		walk += partner_p->hdrlen_;
	memcpy(my_p->bits(), walk, my_len);
	ch->direction() = hdr_cmn::UP;	
//	coding_buffer_.remove(partner_p, partner_p->prev_);  // do we need it?
	
	return my_p;
} 

void
Mac802_11::recvOverheardDATA(Packet *p) {  // native overheard DATA
	hdr_cmn *ch = HDR_CMN(p);
	hdr_mac802_11 *dh = HDR_MAC802_11(p);

    //somayeh:debug
	if (ch->uid_==81)
	{
		int x=index_;
		if (ETHER_ADDR(dh->dh_ra)!=-1)
			x=ETHER_ADDR(dh->dh_ra);
	}
	//somayeh


//	If (ch->size() < CODING_SIZE_THRHLD) {
//		discard(p, "SMALL_OVERHEARD");
//		return;
//	}
	assert((ch->size() >= CODING_SIZE_THRHLD) || (dh->two_hp_ip == RESERVED_END_IP));
//seems not necessary. ARP is discarded since it will be checked as RESERVED_IP later;


//------------------- check queable on MAC & IP layer, but check bufferable on MAC layer
//--- why both layers check queable? -- Doing it on MAC is for performance, filtering some nonqueable packets

// ----- Two kinds of packets need buffering ---
// 1. received from upper layer but 2hp not reserved: originating for coding and forwarding for coding
// 2. overheard packets when 2hp is not reserved and 2hp is not my neighbor (coped with here)

// for 2, it may waste some buffer space. The exact restriction will be: 
// overheard when 2hp is also 2 hop away from me. (Change it later if necessary)
	
	if (dh->two_hp_ip != RESERVED_END_IP) {
		if (arptable_->my_neighbors_.lookup_neighbor(dh->two_hp_ip)) {
			//Somayeh
			if ((use_ACK)&&(disable_intendedHop_))
			{
				//hdr_ip *iph1 = HDR_IP(p);
				//int mydst = Address::instance().get_nodeaddr(iph1->daddr());
				//if (mydst!=index_)
				if (pp_sched_->IsThereAnyValidACK(ch->uid_,dh->two_hp_ip))
				{
					drop(p, "Already exist in downstream");
					return;
				}
				/*if (pp_sched_->removeAcked(ch->uid_, ETHER_ADDR(dh->dh_ta)))
				{
					drop(p, "Already exist in downstream");
					return;
				}*/
			}
			//Somayeh:end
			ch->prev_fwd_mac = ETHER_ADDR(dh->dh_ta);
//			ch->intended_mac = ETHER_ADDR(dh->dh_ra); // for future ack remove
			ch->two_hop_away_ip = dh->two_hp_ip;
			ch->pcondition = PCOND_OVERHEARD; //overheard
			if ( (!disable_oppfwd_ ) && !(pp_sched_->activeMacDrop_overheard(ch->prev_fwd_mac)) ) {
				//somayeh
				//if (disable_intendedHop_)
					ch->last_hop_ =ETHER_ADDR(dh-> dh_ra);
				//Somayeh:end
				uptarget_->recv(p, (Handler*) 0);
				buffering(p->copy());
			}
			else
				buffering(p);
		} else {
			// find or else add and enque
			buffering(p); //overheard, just buffering p, no need to copy.
		}
	} else {
		//if ( (tx_state_ == MAC_SEND) && 
		if ( (pktTx_ != 0) &&
			 (hdr_cmn::access(pktTx_)->two_hop_away_ip == ETHER_ADDR(dh->dh_ra)) &&
			 (hdr_cmn::access(pktTx_)->uid() == hdr_cmn::access(p)->uid()) ) {
			assert(!mhSend_.busy());
			currTxm_postProcess(); // free pktTx_ and reset the cw, ssrc, timers..., and retrieve next pkt from Q
		} 
		//discard(p, "NonQable");
		buffering(p);
	}
}

void Mac802_11::buffering(Packet *p) {
	struct hdr_cmn *ch = HDR_CMN(p);
	uid_pkt_tbl_t::iterator mp = uid_pkt_Cbuffer_.find(ch->uid());
	
	if (mp == uid_pkt_Cbuffer_.end()) {
		coding_buffer_.enque(p);
		//uid_pkt_Cbuffer_[ch->uid()] = p;  -- done in enque;
	} else {
		Packet *old = mp->second;
		coding_buffer_.remove(old, old->prev_);
		coding_buffer_.enque(p);
		//drop(p, "buffered");
	}
}

void
Mac802_11::recvDATA(Packet *p) // receive intended packet or broadcasting packet
{
	struct hdr_mac802_11 *dh = HDR_MAC802_11(p);
	u_int32_t dst, src, size;
	struct hdr_cmn *ch = HDR_CMN(p);

	dst = ETHER_ADDR(dh->dh_ra);
	src = ETHER_ADDR(dh->dh_ta);
	size = ch->size();

	//somayeh:debug
		if (ch->uid_==81)
		{
			int x=index_;
			if (ETHER_ADDR(dh->dh_ra)!=-1)
				x=ETHER_ADDR(dh->dh_ra);
		}
		//somayeh
	//Somayeh
	if ((use_ACK)&&(disable_intendedHop_)&&(dst != MAC_BROADCAST)&&(dh->two_hp_ip != RESERVED_END_IP))
	{
		if (dst == index_);
		{
			hdr_ip *iph1 = HDR_IP(p);
			int mydst = Address::instance().get_nodeaddr(iph1->daddr());
			if (mydst!=index_)
			if (pp_sched_->IsThereAnyValidACK(ch->uid_,dh->two_hp_ip))
			{
				sendACK(ch->uid(),0);
				ack_defer_ = phymib_.getSIFS();
				if(mhSend_.busy() == 0 && mhDefer_.busy() == 0)
					tx_resume();
				drop(p, "Already exist in downstream");
				return;
			}
		}
	}
	//Somayeh:end


	/*
	 * Adjust the MAC packet size - ie; strip
	 * off the mac header
	 */
	ch->size() -= phymib_.getHdrLen11();
	ch->num_forwards() += 1;

	/*
	 *  If we sent a CTS, clean up...
	 */

	if (dst != MAC_BROADCAST) {
		assert(dst == index_);
		//ch->last_hop_=index_;
		ch->prev_fwd_mac = src;
//		ch->intended_mac = dst;
		ch->two_hop_away_ip = dh->two_hp_ip;
		ch->pcondition = PCOND_INTENDED; 

		if(size >= macmib_.getRTSThreshold()) {
			if (tx_state_ == MAC_CTS) {
				assert(pktCTRL_);
				Packet::free(pktCTRL_); pktCTRL_ = 0;
				mhSend_.stop();
				/*
				 * Our CTS got through.
				 */
			} else {
				discard(p, DROP_MAC_BUSY);
				return;
			}
			ack_defer_ = phymib_.getSIFS();
			sendACK(ch->uid(),0);
			ack_defer_ = phymib_.getSIFS();
			tx_resume();
		} else {
			/*
			 *  We did not send a CTS and there's no
			 *  room to buffer an ACK.
			 */
			if(pktCTRL_) {
				discard(p, DROP_MAC_BUSY);
				return;
			}
//			if ( !(pp_sched_->activeMacDrop(ch->prev_fwd_mac)) ) {
				ack_defer_ = phymib_.getSIFS();
				sendACK(ch->uid(),0);
				ack_defer_ = phymib_.getSIFS();
				if(mhSend_.busy() == 0 && mhDefer_.busy() == 0)
					tx_resume();
//			} else {
//				drop(p);
//				if(mhSend_.busy() == 0 && mhDefer_.busy() == 0)
//					tx_resume();
//				return;
//			}
		}
		buffering(p->copy());
	}

	uptarget_->recv(p, (Handler*) 0);
	//somayeh
	//if (disable_intendedHop_)
	//	ch->last_hop_ =ETHER_ADDR(dh-> dh_ra);
	//Somayeh:end
//	/* ============================================================
//	   Make/update an entry in our sequence number cache.
//	   ============================================================ */
//
//	/* Changed by Debojyoti Dutta. This upper loop of if{}else was 
//	   suggested by Joerg Diederich <dieder@ibr.cs.tu-bs.de>. 
//	   Changed on 19th Oct'2000 */
//
//     if(dst != MAC_BROADCAST) {
//                if (src < (u_int32_t) cache_node_count_) {
//                        Host *h = &cache_[src];
//
//                        if(h->seqno && h->seqno == dh->dh_scontrol) {
//                                discard(p, DROP_MAC_DUPLICATE);
//                                return;
//                        }
//                        h->seqno = dh->dh_scontrol;
//                } else {
//			static int count = 0;
//			if (++count <= 10) {
//				printf ("MAC_802_11: accessing MAC cache_ array out of range (src %u, dst %u, size %d)!\n", src, dst, cache_node_count_);
//				if (count == 10)
//					printf ("[suppressing additional MAC cache_ warnings]\n");
//			};
//		};
//	}
//
//	/*
//	 *  Pass the packet up to the link-layer.
//	 *  XXX - we could schedule an event to account
//	 *  for this processing delay.
//	 */
//	
//	/* in BSS mode, if a station receives a packet via
//	 * the AP, and higher layers are interested in looking
//	 * at the src address, we might need to put it at
//	 * the right place - lest the higher layers end up
//	 * believing the AP address to be the src addr! a quick
//	 * grep didn't turn up any higher layers interested in
//	 * the src addr though!
//	 * anyway, here if I'm the AP and the destination
//	 * address (in dh_3a) isn't me, then we have to fwd
//	 * the packet; we pick the real destination and set
//	 * set it up for the LL; we save the real src into
//	 * the dh_3a field for the 'interested in the info'
//	 * receiver; we finally push the packet towards the
//	 * LL to be added back to my queue - accomplish this
//	 * by reversing the direction!*/
//
//	if ((bss_id() == addr()) && ((u_int32_t)ETHER_ADDR(dh->dh_ra)!= MAC_BROADCAST)&& ((u_int32_t)ETHER_ADDR(dh->dh_3a) != addr())) {
//		struct hdr_cmn *ch = HDR_CMN(p);
//		u_int32_t dst = ETHER_ADDR(dh->dh_3a);
//		u_int32_t src = ETHER_ADDR(dh->dh_ta);
//		/* if it is a broadcast pkt then send a copy up
//		 * my stack also
//		 */
//		if (dst == MAC_BROADCAST) {
//			uptarget_->recv(p->copy(), (Handler*) 0);
//		}
//
//		ch->next_hop() = dst;
//		STORE4BYTE(&src, (dh->dh_3a));
//		ch->addr_type() = NS_AF_ILINK;
//		ch->direction() = hdr_cmn::DOWN;
//	}
//	buffering(p->copy());
//	uptarget_->recv(p, (Handler*) 0);
}

void
Mac802_11::recvACK(Packet *p)
{	
	struct ack_frame *af = (struct ack_frame*)p->access(hdr_mac::offset_);
	bool isMyAck = false;
	int src = ETHER_ADDR(af->af_sa);
	int nexthop; 
	int pos;
	pcon_t pcond;	
	ack_const ack_t;
	
	if (af->af_fc.fc_NACK == 1)
		ack_t = NACKED;
	else
		ack_t = ACKED;
		
    //somayeh:debug
	if (af->pkt_id==81)
	{
		double now = Scheduler::instance().clock();
		int x=index_;
	}
	//somayeh

//	double now = Scheduler::instance().clock(); // debug jz

	//Somayeh
	if ((disable_intendedHop_)&&(ack_t == ACKED))
		pp_sched_->StoreACKs(af->pkt_id,src);

	int myX=0;
	if (disable_intendedHop_)
	{
		if (ACKWaiting_.busy())
		{
			if (ack_t == ACKED)
			{
				 myX=hdr_cmn::access(pktHelp_)->uid();
				if (af->pkt_id == hdr_cmn::access(pktHelp_)->uid())
				{
					//debug:Somayeh
					//double now = Scheduler::instance().clock();
					//myfile.open ("example.txt",std::ios_base::app);
					//myfile << "Packet#"<<af->pkt_id<<" ACK is heard by (not intended_fwd) node#"<<index_<<" sender="<<src<<"\n";
					//myfile.close();
					//debug:end
					//check whether this ACK is from one of higher priority nodes
					std::list<int>::iterator it;
					for (it=order_list.begin();it!=order_list.end();++it)
						if ((*it)==src)
						{
							ACKWaiting_.stop();
							pktHelp_=0;
							order_list.clear();
							break;
						}
				}
			}
		}
	}
	//Somayeh: End

	//if (tx_state_ == MAC_SEND) 
	if ( mhSend_.busy()) { // I transmitted and there is an ACK, it must be mine since no hidden with 2.2 CS
		if (iscoded_) {
			struct hdr_mac802_11_encoded *dh = HDR_MAC802_11_ENCODED(pktTx_);
			for (int i=0; i<dh->dh_clen; i++) {
				if (af->pkt_id == dh->pkt_id[i]) {
					isMyAck = true;
					//ack_status_list_[i] = ack_t; //changed by somayeh like below
					if ((!disable_intendedHop_)||(ack_status_list_[i]!=ACKED))
						ack_status_list_[i] = ack_t;
					pos = i;
					/*Somayeh*/if ((!disable_intendedHop_)||(codingPair_[i]))
					{
						pcond = hdr_cmn::access(codingPair_[i])->pcondition;
						if (ack_t == ACKED) {
							Packet::free(codingPair_[i]);
							codingPair_[i] = 0;
						} else { //NACKED
							//Somayeh
							if (!disable_intendedHop_)
							{
								pp_sched_->queue_and_searchPartner(codingPair_[i],false);
								codingPair_[i] = 0;
							}
						}
					}
					break;
				}
			}
			//assert(isMyAck);
			if ( (!isMyAck) && (ack_t == ACKED) ) { // how could it happen??? Find it out!!
				char info[20];
                if (pp_sched_->removeAcked(af->pkt_id, src))
                   sprintf(info, "OHD-ACK-RMV-%d", af->pkt_id);
                else
                   sprintf(info, "OHD-ACK-%d", af->pkt_id);

                 drop(p, info);
                 return;
			}

			if ((pcond == PCOND_OVERHEARD)/*somayeh*/||(pcond == PCOND_OVERHEARDANDDECODED)/*somayeh*/)
				txm_stats_.unintend_coded ++;
			else
				txm_stats_.intend_coded ++;
			
			int numNacked = 0;	
			//somayeh
			if (!disable_intendedHop_)
			{
				for (int i=0; i<dh->dh_clen; i++) {
					if	(ack_status_list_[i] == NOREPLY)
						return;
					else if (ack_status_list_[i] == NACKED) {
						numNacked++;
					}
				}
			}
			else //if disable_intendedHop_
			{
				for (int i=0; i<dh->dh_clen; i++) {
					if	((ack_status_list_[i] == NOREPLY) || (ack_status_list_[i] == NACKED)) {
						return;
					}
				}
			}
			// up to here, they are all replied, either acked or nacked

			char err_inf[20];
			if (numNacked == 0) 
				sprintf(err_inf, "ALL_ACKED");
			else
				sprintf(err_inf, "%d_NACKED", numNacked);
			if (ack_t == ACKED)		//this if is added by somayeh
				pp_sched_->removeAcked(af->pkt_id, src); // do we need it? Some qulicated packet in Q?
			
			drop(p, "ALL_REPLIED");
			discard(pktTx_,err_inf);
			pktTx_ = 0;
			iscoded_ = false;
			// all successful, go finish			
		} else { // native transmission is replied
			assert(ack_t == ACKED); 
			if (af->pkt_id != hdr_cmn::access(pktTx_)->uid()) {
			//	printf("N%d: ack-%d pktTx-%d\n", index_, af->pkt_id, hdr_cmn::access(pktTx_)->uid());
				char info[20];
				if (pp_sched_->removeAcked(af->pkt_id, src))
					sprintf(info, "OHD-ACK-RMV-%d", af->pkt_id);
				else
					sprintf(info, "OHD-ACK-%d", af->pkt_id);
				drop(p, info);
				return;	
			}
			pcon_t pcond = hdr_cmn::access(pktTx_)->pcondition;
			if ((pcond == PCOND_OVERHEARD)/*somayeh*/||(pcond == PCOND_OVERHEARDANDDECODED)/*somayeh*/)
				txm_stats_.unintend_native ++;
			else if (pcond == PCOND_INTENDED_CODABLE || pcond == PCOND_INTENDED_UNCODABLE)
				txm_stats_.intend_native ++;

			discard(pktTx_,"NATIVE_ACKED");
			pktTx_ = 0;
			mac_log(p);
		}
		mhSend_.stop(); // got all replied
	} else { // sender_timer is not busy
		set_nav(af->af_duration); // if ack is not for me, set the nav.
		if (ack_t == NACKED) {
			drop(p, "OVHRD_NACK");
			return;
		}
		if (!pktTx_) { // no packet in MAC for txm
			char info[20];
			if (pp_sched_->removeAcked(af->pkt_id, src))
				sprintf(info, "OHD-ACK-RMV-%d", af->pkt_id);
			else
				sprintf(info, "OHD-ACK-%d", af->pkt_id);
			drop(p, info);
			return;
			
		} else { // I have native or coded packets in the MAC, but I am backing off or defering
			if (iscoded_) {
				struct hdr_mac802_11_encoded *dh = HDR_MAC802_11_ENCODED(pktTx_);
				int pos_ack = -1;
				for (int i=0; i<dh->dh_clen; i++) {			
					if ( (af->pkt_id == dh->pkt_id[i]) && ( ETHER_ADDR(dh->dh_ra[i]) == src) ) {
						Packet::free(codingPair_[i]);
						codingPair_[i] = 0;
						iscoded_ = false;
						pos_ack = i;
						break;
					}
				}	
				if (!iscoded_) {
					for (int i=0; i<dh->dh_clen; i++) {
						if (i != pos_ack) {
							pp_sched_->queue_and_searchPartner(codingPair_[i],false);
							codingPair_[i] = 0;
						}
					}
					discard(pktTx_, "ACKED_&_Qback");
					drop(p, "ACKED_&_Qback");
					// go finish
				} else {
					char info[20];
					if (pp_sched_->removeAcked(af->pkt_id, src))
						sprintf(info, "OHD-ACK-RMV-%d", af->pkt_id);
					else
						sprintf(info, "OHD-ACK-%d", af->pkt_id);
					drop(p, info);
					return;	
				}
			} else { // native packet in MAC
				if ( (af->pkt_id == hdr_cmn::access(pktTx_)->uid()) && 
					 (ETHER_ADDR(HDR_MAC802_11(pktTx_)->dh_ra) == src) ) { // src of ACK
					// go finish
					// discard pktTx_; discard ack; finish to be resumed (stop defer; restart backoff)
				} else { // packets don't match
					char info[20];
					if (pp_sched_->removeAcked(af->pkt_id, src))
						sprintf(info, "OHD-ACK-RMV-%d", af->pkt_id);
					else
						sprintf(info, "OHD-ACK-%d", af->pkt_id);
					drop(p, info);
					return;	
				}
			}
		}
	}
	
//finish:		
	currTxm_postProcess();
//	mac_log(p);
}

void
Mac802_11::currTxm_postProcess() { // common subroutine for successfully stop current txm
						// when ACK received or hearing others help forwarding
//	if((u_int32_t) HDR_CMN(pktTx_)->size() <= macmib_.getRTSThreshold())
//		ssrc_ = 0;
//	else
//		slrc_ = 0;
	ssrc_ = 0; slrc_ = 0;
		
	rst_cw(0);
	if (pktTx_) {
		Packet::free(pktTx_); 
		pktTx_ = 0;
	}

	if (pktCTRL_) return;  // do NOT stop defer when ACK is waiting to be transmitted
	
	if (mhDefer_.busy() != 0)
		mhDefer_.stop();

	/*
	 * Backoff before sending again.
	 */
	//assert(mhBackoff_.busy() == 0);
	if (mhBackoff_.busy() != 0)
		mhBackoff_.stop();
	mhBackoff_.start(cw_, is_idle());
	tx_resume();					
}

void
Mac802_11::loadtrace(char* fmt, ...)
{
	char buffer[256];
	va_list ap;
	va_start(ap, fmt);
	vsprintf(buffer, fmt, ap);
	(void)Tcl_Write(ltr_ch, buffer, strlen(buffer));
	va_end(ap);
}

void
Mac802_11::scanHandler()
{
//	scan_state_[0] += 1 - is_idle();
	scan_state_[0] += mhBackoff_.busy();
//	if (pktTx_ != 0)
//		scan_state_[0] += 1;
		
	scan_cnt_++;
	if (scan_cnt_ == scan_len_) {
		
		scan_state_[0] /= scan_len_;
		if (smooth_scan_) {
			scan_state_[0] = (scan_state_[0] + 0.8 * scan_state_[1] + 0.5 * scan_state_[2] + 0.2 * scan_state_[3]) / 2.5;
			for (int i = 0; i < 3; scan_state_[++i] = scan_state_[i - 1]);
		}
		//macLoad_ = (int) (100 * scan_state_[0]);
		macLoad_ = scan_state_[0];
		
		if (ltr_ch != NULL) {
			double x, y, z;
			((MobileNode*) netif_->node())->getLoc(&x, &y, &z);
			loadtrace("ML %f _%d_ (%.2f/%.2f) %.4f \n",
				  Scheduler::instance().clock(), addr(), x, y, scan_state_[0]);
		}
		
		scan_cnt_ = 0;
		scan_state_[0] = 0;
	}
	
	mhScan_.start(scan_int_);
}

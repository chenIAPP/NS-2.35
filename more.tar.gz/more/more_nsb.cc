/*
 * more_nsb.cc
 *
 *  Created on: 2015-09-21
 *      Author: winemocol
 */

#include "more_nsb.h"

More_NSB::More_NSB()
{

}

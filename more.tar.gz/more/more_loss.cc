/*
 * more_loss.cc
 *
 *  Created on: 2014-08-25
 *      Author: winemocol
 */
#include "more_loss.h"


More_loss::More_loss()
{


}

void
More_loss::setIndex(int index)
{
	indexOfnode = index;
}

double
More_loss::update_Redundance_factor(int numOfDownSteamNodes,double* downSteamNodes)
{

	double lossValue = 1;
	for(int i=0;i<numOfDownSteamNodes;i++)
	{
		printf("downSteamNodes[i]==%f=======i--%d====\n",downSteamNodes[i],i);
		lossValue = lossValue*(1-downSteamNodes[i]);
	}

	if(lossValue == 1)return 0;
	return 1/(1-lossValue);
}

double
More_loss::update_Credit_factor(More_node upStreamNodes[20],More_node downSteamNodes[20],int index)
{
	//upstrean for receving num of packets
	double Forword__L = 0;

	int totalReceivedPacket = 0;

	for(int i=0;i<20;i++)
	{
		int receivePackets = upStreamNodes[i].the_number_of_current_receive_packet;
		if(receivePackets == 0) continue;
		printf("current node index ==%d receive packets from %d\n",index,i);

		totalReceivedPacket = totalReceivedPacket + receivePackets;

		double downstreamNodeDontrecievepacket = 1;

		for(int j=0;j<20;j++)
		{
			if(upStreamNodes[i].downsteamNodeDeliverRatio[j] !=0)
			{
				printf("upStreamNodes------%d-----%f\n",i,upStreamNodes[i].downsteamNodeDeliverRatio[j]);
				downstreamNodeDontrecievepacket = downstreamNodeDontrecievepacket*(1-upStreamNodes[i].downsteamNodeDeliverRatio[j]);
			}
		}
		//printf("ssss-----%f\n",Forword__L);
		Forword__L = Forword__L +receivePackets*downstreamNodeDontrecievepacket;
	}

	//downstream receive nodes
	//double transmissionNumber_Z;

	double lossValue = 1;

	for(int i=0;i<20;i++)
	{
		if(downSteamNodes[i].current_deliver_ratio !=0)
		{
			printf("downSteamNodes[%d].current_deliver_ratio-----------%f\n",i,downSteamNodes[i].current_deliver_ratio);
			printf("current receive==%d\n",downSteamNodes[i].the_number_of_current_receive_packet);
			printf("previous receive==%d\n",downSteamNodes[i].the_number_of_previous_receive_packet);
			printf("last sequence==%d\n",downSteamNodes[i].last_packet_sequence_number);
			printf("previous sequence==%d\n",downSteamNodes[i].previous_last_packet_sequence_number);

			//printf("downSteamNodes-----------%f\n",lossValue);
			lossValue = lossValue*(1-downSteamNodes[i].current_deliver_ratio);
			//printf("lossValue-----------%f\n",lossValue);
		}
	}
	double credit;

	if(lossValue != 1)
	{
		printf("Forword__L==%f\n",Forword__L);

		printf("(1-lossValue)==%f\n",(1-lossValue));
		if(index == 0)
		{
			credit = 1/(1-lossValue);
		}
		else
		{
			credit = Forword__L/(1-lossValue);
		}

		printf("credit==%f\n",credit);
	}
	else
	{
		printf("credit = Forword__L\n");
		credit = Forword__L;
	}

	if(totalReceivedPacket ==0) {
		printf("totalReceivedPacket = 0 in node==%d\n",index);
		totalReceivedPacket =1;
	}
	printf("totalReceivedPacket ===%d\n",totalReceivedPacket);
	printf("credit/(double)totalReceivedPacket ===%f\n",credit/(double)totalReceivedPacket);
	return credit/(double)totalReceivedPacket;
}


double
More_loss::update_ETX_factor(int numOfDownSteamNodes,double* downSteamNodesETX,double* downSteamNodes)
{
	double lossValue = 1;

	for(int i=0;i<numOfDownSteamNodes;i++)
	{
		lossValue = lossValue*(1-downSteamNodes[i]);
	}

	double EAX = 0;

	for(int i =0; i<numOfDownSteamNodes;i++)
	{

		double innerLossValue = 1;
		for(int j=0;j<numOfDownSteamNodes && j !=i;j++)
		{
			innerLossValue = innerLossValue*(1-downSteamNodes[j]);
		}
		EAX = EAX + downSteamNodesETX[i]*downSteamNodes[i];

	}

	if(lossValue == 1)return 100;
	return (1+EAX)/(1-lossValue);
}


double
More_loss::update_single_path_delivery(int lastSeq,int NumFromLast,int previousSeq, int NumFromPrevous,double current_deliver_ratio)
{

	if(lastSeq-previousSeq > 0){

		//double currentDeliverRatio = value_threshold*current_deliver_ratio +(1-value_threshold)*((double)(NumFromLast-NumFromPrevous)/(double)(lastSeq-previousSeq));
		double currentDeliverRatio = value_threshold*current_deliver_ratio +(1-value_threshold)*((double)(NumFromLast)/(double)(lastSeq));

		return currentDeliverRatio;

	}

	return current_deliver_ratio;
}

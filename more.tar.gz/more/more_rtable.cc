/*
 * more_rtable.cc
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */
#include "more_rtable.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "ip.h"
#include <iostream>
more_rtable::more_rtable()
{

}

void
more_rtable::print(Trace* out)
{
	sprintf(out->pt_->buffer(),"P\tdest\tnect");

	out->pt_->dump();

	for(rtable_t::iterator it = rt_.begin(); it != rt_.end(); it++)
	{
		sprintf(out->pt_->buffer(),"P\t%d\t%d",(*it).first, (*it).second);

		out->pt_->dump();
	}
}

void
more_rtable::clear()
{
	rt_.clear();
}


void
more_rtable::rm_entry(nsaddr_t dest)
{
	rt_.erase(dest);
}

void
more_rtable::add_entry(nsaddr_t dest, nsaddr_t next)
{
	rt_[dest] = next;
}

nsaddr_t
more_rtable::lookup(nsaddr_t dest)
{
	rtable_t::iterator it = rt_.find(dest);

	if(it == rt_.end())
		return IP_BROADCAST;
	else
		return (*it).second;
}

u_int32_t
more_rtable::size()
{
	return rt_.size();
}
//================================================================================================================================

neighbor_rtable::neighbor_rtable() {
  // Let's start with a ten element maxelts.
  elts = 0;
  maxelts = 100;
  rtab = new neighbor_rtable_ent[maxelts];
}



void
neighbor_rtable::AddEntry(neighbor_rtable_ent *ent)
{
  if (elts == maxelts) {
	  neighbor_rtable_ent *tmp = rtab;
	  maxelts *= 2;
	  rtab = new neighbor_rtable_ent[maxelts];
	  bcopy(tmp, rtab, elts*sizeof(neighbor_rtable_ent));
	  delete tmp;
  }
  bcopy(ent, &rtab[elts], sizeof(neighbor_rtable_ent));
  elts++;

  return;
}


bool
neighbor_rtable::IsNewEntry(nsaddr_t senderAddress)
{
	//std::cout << "========IsNewEntry=============================11============="<< elts<<std::endl;
  for(int i=0;i<elts; i++)
  {
	  neighbor_rtable_ent * tmp = &rtab[i];
	//  std::cout << "========for condition=============================11============="<< tmp->neighbor_address<<"===senderAddress==="<< senderAddress<<std::endl;
	  if(tmp->neighbor_address == senderAddress)
	  {

		 // std::cout << "========IsNewEntry==========jin lai le===================11============="<< tmp->neighbor_address<<std::endl;

		  return false;
	  }
  }
  return true;
}

void
neighbor_rtable::UpdateEntry(nsaddr_t senderAddress,neighbor_rtable_ent* ent)
{
	//std::cout << "========UpdateEntry==========jin lai le===================11============="<< ent->neighbor_address<<std::endl;
  for(int i=0;i<elts; i++)
  {
	  neighbor_rtable_ent * tmp = &rtab[i];

	  if(tmp->neighbor_address == senderAddress)
	  {
		  tmp->neighbor_address = ent->neighbor_address;
		  tmp->ETX = ent->ETX;
		  tmp->receivedHelloMessageNumber = ent->receivedHelloMessageNumber;
		  tmp->seqnum = ent->seqnum;
		  tmp->received_time = ent->received_time;
		  tmp->last_received_time = ent->last_received_time;
		  tmp->sendDetectACK = ent->sendDetectACK;
		  tmp->sendDetectACK_time = ent->sendDetectACK_time;
	  }
  }
}

neighbor_rtable_ent* CopyNeighbor_rtable_ent (neighbor_rtable_ent* ent)
{
	neighbor_rtable_ent* returnEnt = new neighbor_rtable_ent();
	returnEnt->neighbor_address = ent->neighbor_address;
	returnEnt->ETX = ent->ETX;
	returnEnt->receivedHelloMessageNumber = ent->receivedHelloMessageNumber;
	returnEnt->seqnum = ent->seqnum;
	returnEnt->received_time = ent->received_time;
	returnEnt->last_received_time = ent->last_received_time;
	returnEnt->sendDetectACK = ent->sendDetectACK;
	returnEnt->sendDetectACK_time = ent->sendDetectACK_time;

	return returnEnt;
}

neighbor_rtable_ent*
neighbor_rtable::GetEntryByAddress(nsaddr_t senderAddress)
{
	//std::cout << "========GetEntryByAddress==========jin lai le===================11============="<<senderAddress<<std::endl;
  for(int i=0;i<elts; i++)
  {
	  neighbor_rtable_ent* tmp = &rtab[i];
	 // std::cout << "========GetEntryByAddress===============11============="<< tmp->neighbor_address<<std::endl;
	  if(tmp->neighbor_address == senderAddress)
	  {
		//  std::cout << "========GetEntryByAddress===============22============="<<std::endl;
		  neighbor_rtable_ent* returnEnt = CopyNeighbor_rtable_ent(tmp);
		  return returnEnt;
	  }

  }
  return 0;
}





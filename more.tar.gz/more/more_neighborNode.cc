/*
 * more_neighborNode.cc
 *
 *  Created on: 2014-08-26
 *      Author: winemocol
 */

#include "more_neighborNode.h"

More_neighborInfo::More_neighborInfo()
{
	for(int i=0;i<10;i++)
	{
		receiveList[i] = 100;
		forwarderList[i] = 100;
		overhearReceiveList[i] = 100;
		overhearForwardList[i] = 100;
	}
}


void
More_neighborInfo::setReceiveList(int receiveListArray[])
{
	for(int i=0;i<10;i++)
	{
		receiveList[i] = receiveListArray[i];
	}
}

void
More_neighborInfo::setForwardList(int forwarderListArray[])
{
	for(int i=0;i<10;i++)
	{
		forwarderList[i] = forwarderListArray[i];
	}
}

//More_neighborInfo::More_neighborInfo()
//{
//	transmission_factor = 0;
//	redundance_factor = 0;
//	num_downSteamNeighbor = 0;
//}
//
//void
//More_neighborInfo::setIndex(int index)
//{
//	indexOfnode = index;
//}
//
//void
//More_neighborInfo::updateLossInfor(int index)
//{
//	//printf("updateLossInfor--in\n");
//
////	double downSteamNodes[20];
////
////	double downSteamNodesETX[20];
////
////	int downSteamNodesIndex[20];
//	//printf("current node === %d\n",index);
//	if(num_downSteamNeighbor == 0)
//	{
//		for(int i =0; i<20;i++)
//		{
//			if(downsteam_nodes[i].default_deliver_ratio !=0)
//			{
//				downSteamNodes[num_downSteamNeighbor] = downsteam_nodes[i].default_deliver_ratio;
//				downSteamNodesETX[num_downSteamNeighbor] = downsteam_nodes[i].default_the_ETX_of_current_node;
//				downSteamNodesIndex[num_downSteamNeighbor] = i;
//
//				downsteam_nodes[i].current_deliver_ratio = downsteam_nodes[i].default_deliver_ratio;
//				downsteam_nodes[i].the_ETX_of_current_node = downsteam_nodes[i].default_the_ETX_of_current_node;
//
////				printf("downSteamNodes===%f\n",downsteam_nodes[i].default_deliver_ratio);
////				printf("downSteamNodesETX===%f\n",downsteam_nodes[i].default_the_ETX_of_current_node);
////				printf("downSteamNodesIndex===%d\n",i);
////				printf("downsteam_nodes[i==%d].current_deliver_ratio===%f\n",i,downsteam_nodes[i].default_deliver_ratio);
////				printf("num_downSteamNeighbor===%d\n",num_downSteamNeighbor);
//
//				num_downSteamNeighbor++;
//			}
//		}
//		for(int i =0; i<num_downSteamNeighbor;i++)
//		{
//			printf("num_downSteamNeighbor --%d---%d\n",i,downSteamNodesIndex[i]);
//		}
//		printf("if==---------index---%d===================neighbor=%d\n",indexOfnode,num_downSteamNeighbor);
//	}
////	else{
////		printf("else -----%d-----------------%d\n",num_downSteamNeighbor,indexOfnode);
////		for(int i =0; i<num_downSteamNeighbor;i++)
////		{
////			printf("num_downSteamNeighbor --%d---%f\n",downSteamNodesIndex[i],downSteamNodes[i]);
////		}
//		for(int i =0; i<num_downSteamNeighbor;i++)
//		{
//			printf("index value--------%d\n",downSteamNodesIndex[i]);
//
//			printf("sequence =============%d\n",downsteam_nodes[downSteamNodesIndex[i]].last_packet_sequence_number);
//
//			printf("number =============%d\n",downsteam_nodes[downSteamNodesIndex[i]].the_number_of_current_receive_packet);
//
//			updateSinglePathLossInfo(downSteamNodesIndex[i]);
//
//			//downSteamNodes[i] = downsteam_nodes[downSteamNodesIndex[i]].current_deliver_ratio;
//
//			//downSteamNodesETX[i] = downsteam_nodes[i].the_ETX_of_current_node;
//		}
//		//printf("else end\n");
//	//}
//
////	for(int i=0;i<20;i++)
////	{
////		int receivePackets = upsteam_nodes[i].the_number_of_current_receive_packet;
////
////		printf("OUT -receivePackets-----------%d\n",receivePackets);
////	}
//	redundance_credit = loss_object.update_Credit_factor(upsteam_nodes,downsteam_nodes,index);
//	//redundance_factor = loss_object.update_Redundance_factor(num_downSteamNeighbor,downSteamNodes);
//	//etx_for_current_node = loss_object.update_ETX_factor(num_downSteamNeighbor,downSteamNodesETX,downSteamNodes);
//}
//
//void
//More_neighborInfo::updateDownSteamNodeInfor(int node, int lastPacket, int numFromLatest,double etx_value)
//{
//	printf("updateDownSteamNodeInfor -from node  %d--lastSequence--%d-total number---%d\n",node,lastPacket,numFromLatest);
//	if(downsteam_nodes[node].last_packet_sequence_number < lastPacket)
//	{
//		downsteam_nodes[node].last_packet_sequence_number = lastPacket;
//	}
//	if(downsteam_nodes[node].the_number_of_current_receive_packet < numFromLatest)
//	{
//		downsteam_nodes[node].the_number_of_current_receive_packet = numFromLatest;
//	}
//	downsteam_nodes[node].the_ETX_of_current_node = etx_value;
//}
//
//void
//More_neighborInfo::updateSinglePathLossInfo(int node)
//{
////	printf("000---------------%f\n",downsteam_nodes[node].current_deliver_ratio);
//	if(downsteam_nodes[node].current_deliver_ratio == 0)
//		downsteam_nodes[node].current_deliver_ratio = downsteam_nodes[node].default_deliver_ratio;
//	printf("000------current_deliver_ratio---------%f\n",downsteam_nodes[node].current_deliver_ratio);
//	printf("111------last_packet_sequence_number---------%d\n",downsteam_nodes[node].last_packet_sequence_number);
//	printf("111------the_number_of_current_receive_packet---------%d\n",downsteam_nodes[node].the_number_of_current_receive_packet);
//	printf("111------previous_last_packet_sequence_number---------%d\n",downsteam_nodes[node].previous_last_packet_sequence_number);
//	printf("111------the_number_of_previous_receive_packet---------%d\n",downsteam_nodes[node].the_number_of_previous_receive_packet);
//
//	downsteam_nodes[node].current_deliver_ratio = loss_object.update_single_path_delivery(downsteam_nodes[node].last_packet_sequence_number,downsteam_nodes[node].the_number_of_current_receive_packet,downsteam_nodes[node].previous_last_packet_sequence_number,downsteam_nodes[node].the_number_of_previous_receive_packet,downsteam_nodes[node].current_deliver_ratio);
//	printf("111----current_deliver_ratio-----------%f\n",downsteam_nodes[node].current_deliver_ratio);
//
//	downsteam_nodes[node].previous_last_packet_sequence_number = downsteam_nodes[node].last_packet_sequence_number;
//	downsteam_nodes[node].the_number_of_previous_receive_packet = downsteam_nodes[node].the_number_of_current_receive_packet;
//
//}
//
//void
//More_neighborInfo::updateUpsteamNodeInfor(int node,int latestPacket)
//{
//	//printf("updateUpsteamNodeInfor----for node---%d----sequence number----%d\n",node,latestPacket);
//	//printf("previous recevied sequence-----%d\n",upsteam_nodes[node].last_packet_sequence_number);
//	if(upsteam_nodes[node].last_packet_sequence_number < latestPacket)
//	{
//		//printf("upsteam_nodes[node].last_packet_sequence_number = %d\n",upsteam_nodes[node].last_packet_sequence_number);
//		//printf("upsteam_nodes[node].last_packet_sequence_number = %d\n",latestPacket);
//		upsteam_nodes[node].last_packet_sequence_number = latestPacket;
//	}
//	printf("recevied sequence-----%d\n",upsteam_nodes[node].last_packet_sequence_number);
//	upsteam_nodes[node].the_number_of_current_receive_packet++;
//	printf("upsteam_nodes[node].the_number_of_current_receive_packet = %d\n",upsteam_nodes[node].the_number_of_current_receive_packet);
//
//
//}
//
//
//void
//More_neighborInfo::updateDeliverRatioOFDownStreamNodeForUpStreamNodes(int downnode, int lastPacket, int numFromLatest,int upnode)
//{
//
//	upsteam_nodes[upnode].downsteamNodeDeliverRatio[downnode] = (double)numFromLatest/(double)(lastPacket+1);
//	printf("updateDeliver---%d\n",upnode);
//	printf("updateDeliver---%d\n",downnode);
//	printf("updateDeliver---%f\n",(double)numFromLatest/(double)(lastPacket+1));
//
//	printf("updateDeliverRatioOFDownStreamNodeForUpStreamNodes---%f\n",upsteam_nodes[upnode].downsteamNodeDeliverRatio[downnode]);
//}
//
//void
//More_neighborInfo::initialDefaultLossRatio(int index)
//{
//	//printf("coming\n");
//	for(int i=0;i<20;i++)
//		{
//			downsteam_nodes[i].setIndex(i);
//			downsteam_nodes[i].default_deliver_ratio = 0;
//			downsteam_nodes[i].the_number_of_current_receive_packet = 0;
//			downsteam_nodes[i].last_packet_sequence_number = 0;
//
//			upsteam_nodes[i].setIndex(i);
//			upsteam_nodes[i].default_deliver_ratio = 0;
//			upsteam_nodes[i].the_number_of_current_receive_packet = 0;
//			upsteam_nodes[i].last_packet_sequence_number = 0;
//
//			downSteamNodes[i]=0.0;
//			downSteamNodesIndex[i]=0;
//			//printf("downSteamNodes===%f\n",downsteam_nodes[i].default_deliver_ratio);
//			//printf("downSteamNodesNUM===%d\n",downsteam_nodes[i].the_number_of_current_receive_packet);
//
//		}
//
//		if(index == 0)
//		{
//			downsteam_nodes[1].default_deliver_ratio = 0.6;//0.3;
//			downsteam_nodes[2].default_deliver_ratio = 0.3;//0.6;
//			downsteam_nodes[3].default_deliver_ratio = 0.7;
//		}
//		else if (index ==1)
//		{
//			downsteam_nodes[2].default_deliver_ratio = 1;
//			downsteam_nodes[4].default_deliver_ratio = 0.1;
//
//			upsteam_nodes[0].default_deliver_ratio = 0.6;//0.3;
//		}
//		else if (index ==2)
//		{
//			downsteam_nodes[4].default_deliver_ratio = 0.3;
//			downsteam_nodes[5].default_deliver_ratio = 0.3;
//
//			upsteam_nodes[0].default_deliver_ratio = 0.3;//0.6;
//			upsteam_nodes[1].default_deliver_ratio = 1;
//		}
//		else if (index ==3)
//		{
//			downsteam_nodes[4].default_deliver_ratio = 0.8;
//			downsteam_nodes[5].default_deliver_ratio = 0.3;
//
//			upsteam_nodes[0].default_deliver_ratio = 0.7;
//		}
//		else if (index ==4)
//		{
//			downsteam_nodes[5].default_deliver_ratio = 0.8;
//			downsteam_nodes[6].default_deliver_ratio = 0.3;
//			downsteam_nodes[7].default_deliver_ratio = 0.1;
//
//			upsteam_nodes[3].default_deliver_ratio = 0.8;
//			upsteam_nodes[2].default_deliver_ratio = 0.3;
//			upsteam_nodes[1].default_deliver_ratio = 0.1;
//		}
//		else if (index ==5)
//		{
//			downsteam_nodes[6].default_deliver_ratio = 0.3;
//			downsteam_nodes[7].default_deliver_ratio = 0.4;
//
//			upsteam_nodes[3].default_deliver_ratio = 0.3;
//			upsteam_nodes[2].default_deliver_ratio = 0.3;
//			upsteam_nodes[4].default_deliver_ratio = 0.8;
//		}
//		else if (index ==6)
//		{
//			downsteam_nodes[7].default_deliver_ratio = 0.8;
//			downsteam_nodes[8].default_deliver_ratio = 0.9;
//			downsteam_nodes[9].default_deliver_ratio = 1;
//			downsteam_nodes[11].default_deliver_ratio = 0.7;
//
//			upsteam_nodes[4].default_deliver_ratio = 0.3;
//			upsteam_nodes[5].default_deliver_ratio = 0.3;
//		}
//		else if (index ==7)
//		{
//			downsteam_nodes[8].default_deliver_ratio = 1;
//			downsteam_nodes[10].default_deliver_ratio = 0.2;
//			downsteam_nodes[11].default_deliver_ratio = 0.8;
//
//			upsteam_nodes[4].default_deliver_ratio = 0.1;
//			upsteam_nodes[5].default_deliver_ratio = 0.4;
//			upsteam_nodes[6].default_deliver_ratio = 0.8;
//		}
//		else if (index ==8)
//		{
//			downsteam_nodes[9].default_deliver_ratio = 0.9;
//			downsteam_nodes[11].default_deliver_ratio = 1;
//			etx_for_current_node = 1;
//
//			upsteam_nodes[6].default_deliver_ratio = 0.9;
//			upsteam_nodes[7].default_deliver_ratio = 1;
//		}
//		else if (index ==9)
//		{
//			downsteam_nodes[11].default_deliver_ratio = 1;
//
//			etx_for_current_node = 1;
//
//			upsteam_nodes[6].default_deliver_ratio = 1;
//			upsteam_nodes[8].default_deliver_ratio = 0.9;
//		}
//		else if (index ==10)
//		{
//			upsteam_nodes[7].default_deliver_ratio = 0.2;
//		}
//		else if (index ==11)
//		{
//			upsteam_nodes[6].default_deliver_ratio = 0.7;
//			upsteam_nodes[7].default_deliver_ratio = 0.8;
//			upsteam_nodes[8].default_deliver_ratio = 1;
//			upsteam_nodes[9].default_deliver_ratio = 1;
//		}
//}

/*
 * more.cc
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */
#include "more.h"
#include "more_loss.h"
#include "more_pkt.h"
#include <packet.h>
#include <random.h>
#include <cmu-trace.h>
#include <iostream>
#include <stdio.h>
#include <sys/time.h>
#include <random.h>
#define CURRENT_TIME    Scheduler::instance().clock()
int hdr_more_pkt::offset_;

static class MoreHeaderClass : public PacketHeaderClass {
public:

	MoreHeaderClass():PacketHeaderClass("PacketHeader/More",sizeof(hdr_all_more))
	{
		bind_offset(&hdr_more_pkt::offset_);
	}
}class_rtProtoMore_hdr;

static class MoreClass : public TclClass{

public:

	MoreClass():TclClass("Agent/More"){}

	TclObject* create(int argc, const char*const* argv){
		assert(argc ==5);
		return (new More((nsaddr_t) Address ::instance().str2addr(argv[4])));
	}

}class_rtProtoMore;

int
More::command(int argc, const char*const *argv)
{

	if(argc ==2 )
	{
	    if(strcasecmp(argv[1],"start") == 0)
	    {
		return TCL_OK;
	    }
	}
	else if (strcasecmp(argv[1],"print_rtable") == 0)
	{
	    if(logtarget_ != 0)
	    {
		sprintf(logtarget_->pt_->buffer(), "P %f _%d_ Routing Table", CURRENT_TIME, ra_addr());

		logtarget_->pt_->dump();

		rtable_.print(logtarget_);
	    }
	    else{

                    fprintf(stdout, "%f _%d_ If you want to print this routing table "

                    "you must create a trace file in your tcl script", CURRENT_TIME, ra_addr());

		}

	    return TCL_OK;
	}
	else if (argc ==3)
	{
		//Obtatins corresponding dumx to carry packets to upper layers
		if(strcmp(argv[1], "port-dmux") == 0){
            dmux_ = (PortClassifier*)TclObject::lookup(argv[2]);

                  if (dmux_ == 0) {

                      fprintf(stderr, "%s: %s lookup of %s failed\n", __FILE__, argv[1], argv[2]);
                      return TCL_ERROR;
                  }

                  return TCL_OK;
		}

        // Obtains corresponding tracer

        else if (strcmp(argv[1], "log-target") == 0 || strcmp(argv[1], "tracetarget") == 0) {

               logtarget_ = (Trace*)TclObject::lookup(argv[2]);
               if (logtarget_ == 0)return TCL_ERROR;
               return TCL_OK;

        }

        else if(strcmp(argv[1], "drop-target") == 0) {
        int stat = SR_Q.command(argc,argv);
        if (stat != TCL_OK) return stat;
        return Agent::command(argc, argv);
        }

        else if (strcmp(argv[1], "install-tap") == 0) {
        	mac_ = (Mac*)TclObject::lookup(argv[2]);
        	if (mac_ == 0) return TCL_ERROR;
        	mac_->installTap(this);
        	return TCL_OK;
        }
	}
    // Pass the command to the base class

    return Agent::command(argc, argv);
}

void
More::tap(const Packet *p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);



	if(ch->ptype_ == 5 && ch->prev_hop_ > index && ch->next_hop_ != index)
	{
		printf("index==%d---",index);
		printf("type==%d---",ch->ptype_);
		printf("address=dis=%d---",ih->daddr());
		printf("address=sour=%d---",ih->saddr());
		printf("do something here\n");

		printf("do something here 2\n");
		//intermediates_overhear_ACKPackets(p);
		//resetOverhearHighPriorityTimer(p,index);
	}

	//fprintf(stdout,"Node in Promiscuous Mode");
}

More::More(nsaddr_t id) : Agent(PT_MORE),rqueue_0(),rqueue_1(),
			rqueue_2(),rqueue_3(),rqueue_4(),rqueue_5(),rqueue_6(),
			rqueue_7(),rqueue_8(),rqueue_9(),squeue_0(),squeue_1(),
			squeue_2(),squeue_3(),squeue_4(),squeue_5(),squeue_6(),
			squeue_7(),squeue_8(),squeue_9(),
			wrNewfTimer(this),wrAckTimer(this),wHighpsTimer(this),
			destionACKTimer(this){

	bind_bool("accessible_var_",&accessible_var_);

    onePacketSendingDelay = 0.0095;
    backoffpacketNum = 5;
    totalSendingPacketNum = 0;

	ra_addr_= id;
	index = id;
	//ExOR required -- begin
	codeingPacketNumber = 100;
	totalNumberOfGroup = 10;
	batchIndex = 0;
	totalNumberOfCBRPacket = 0;
	senderSendingIndex = 0;
	op.sourceIndex = 0;
	op.destinationIndex = 19;
	newBatchIndex = 0;
	destinationReceivedPacketNum = 0;
	sendingPacketNumberInEachNode = 0;

	downstreamInnovativeNum = 0;
	totalReceivedPacket = 0;
	//ExOR required -- end
}

void
More::recv(Packet* p, Handler*h)
{
	ExOR(p);
}





void
More::ExOR(Packet* p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);
	hdr_tcp *tcph = hdr_tcp::access(p);
	ns_addr_t desti = ih->dst_;
	ns_addr_t source= ih->src_;

    if (ih->saddr() == ra_addr()) {
	// If there exists a loop, must drop the packet
       if (ch->num_forwards() > 0)
       {
    	   drop(p, DROP_RTR_ROUTE_LOOP);
    	   return;
       }
    // else if this is a packet I am originating, must add IP header
       else if (ch->num_forwards() == 0)
       {
    	   ch->size() += IP_HDR_LEN;
       }
    }

    printf("TCPFender_flow---------------   ----------   ---------- "
    		" ----------  ------------  ---------  ------------  ---------\n");
    printf("a node receive packets with uid=%d, index=%d, destination port=%d,source port=%d,"
	    "\n",ch->uid_,index,desti.port_,source.port_);
    printf("TCP packet----sequence-%d---packet type-%d--------from %d------------uid=%d--"
	    "------------\n",tcph->seqno(),ch->ptype_,ch->prev_hop_,ch->uid_);

    int state = op.checkstate(p,index);

   printf("state = %d\n",state);
    switch (state)
    {
    	case 0:
    		source_receive_dataPackets(p);
    		break;
    	case 1:
    		source_receive_downstream_dataPackets(p);
    		break;
    	case 2:
    		destination_receive_dataPackets(p);
    		break;
    	case 3:
    		intermediates_receive_dataPackets(p);
    		break;
    	case 4:
    		intermediates_receive_downstream_dataPackets(p);
    		break;
    	case 5:
    		source_receive_ACKPackets(p);
    		break;
    	case 6:
    		intermediates_receive_ACKPackets(p);
    		break;
    }
}

void
More::source_receive_dataPackets(Packet* p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	//printf("the type of packet == %d\n",ch->ptype_);
	if(senderSendingIndex == 0 )
	{
		source_send_newDataPacket();
		senderSendingIndex++;
	}
	drop(p);
//	totalNumberOfCBRPacket ++ ;
//	printf("-----------------received packet total == %d\n",totalNumberOfCBRPacket);
}

void
More::source_send_newDataPacket()
{
	printf("<-----@@@@@@@@@@@@------>source_");
	printf("index ==%d begin source_send_newDataPacket<------@@@@@@@@@@@@------>\n",index);

	//for(int i=0;i<120; i++)
	for(int i=0;i<codeingPacketNumber; i++)
	{
		//sendingPacketNumberInEachNode++;
		Packet* newpacket = source_generate_codedPackets(i);
		struct hdr_more_pkt* ph = HDR_MORE_PKT(newpacket);
		ph->indexforthebatch = i;
		ph->indexforFragment = i;
		ph->totalFragmentNum = codeingPacketNumber;
		ph->cur_wait_num = codeingPacketNumber-1-i;
		ph->batchNum = batchIndex;

	    Packet* packet_backoff = newpacket->copy();
	    rqueue_0.enque(packet_backoff);
	    printPacketContent(packet_backoff);


	}


	for(int i=0;i<120; i++)
		{

			sendingPacketNumberInEachNode++;

			Packet* PacketInQueue = generateCodedPacketBasedOnSendingQueue(rqueue_0);
			struct hdr_more_pkt* ph = HDR_MORE_PKT(PacketInQueue);

			ph->indexforFragment = i;
			ph->totalFragmentNum = 120;
			ph->cur_wait_num = 120-1-i;
			ph->batchNum = batchIndex;

		    Packet* packet_backoff = PacketInQueue->copy();
		    rqueue_0.enque(packet_backoff);
		    printPacketContent(packet_backoff);
			Scheduler::instance().schedule(target_, PacketInQueue,NO_DELAY);
		}


//    struct hdr_cmn* ch = HDR_CMN(newpacket);
//	printf("sendingPacketNumberInEachNode------------uid------------%d\n",ch->uid_);
//
//	Scheduler::instance().schedule(target_, newpacket,NO_DELAY);

	printf("sendingPacketNumberInEachNode-----------------source-------%d\n",sendingPacketNumberInEachNode);
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}


void
More::source_send_dataPackets()
{
	printf("<-----@@@@@@@@@@@@------>source_");
	printf("index ==%d begin send_dataPackets<------@@@@@@@@@@@@------>\n",index);

	int updatedLength = codeingPacketNumber - totalReceivedPacket;
	printf("index ==%d  updatedLength<------@@@@@@@@@@@@------%d>\n",index,updatedLength);

	if(updatedLength < 20)
	{
		batchIndex++;
		newBatchIndex = 1;
		totalReceivedPacket = 0;
	    printf("source_send_dataPackets resetHighPriorityTimer  at index ==%d\n",index);


	    int backoff = ExOR_schedule(0,index);

	    double backtime = backoffpacketNum*backoff*onePacketSendingDelay;

	    printf("resetHighPriorityTimer backoff time = %f\n",backtime);

	    printf("CURRENT_TIME == %f resetHighPriorityTimer\n",CURRENT_TIME);

	    if(wHighpsTimer.busy())
	    {
	    	wHighpsTimer.stop();
	        wHighpsTimer.start(backtime);
	     }
	     else
	     {
	    	wHighpsTimer.start(backtime);
	     }
	}
	else {

		for(int i=0;i<updatedLength; i++)
			{

				sendingPacketNumberInEachNode++;

				Packet* PacketInQueue = generateCodedPacketBasedOnSendingQueue(rqueue_0);
				struct hdr_more_pkt* ph = HDR_MORE_PKT(PacketInQueue);

				ph->indexforFragment = i;
				ph->totalFragmentNum = updatedLength;
				ph->cur_wait_num = updatedLength-1-i;
				ph->batchNum = batchIndex;

			    Packet* packet_backoff = PacketInQueue->copy();
			    rqueue_0.enque(packet_backoff);
			    printPacketContent(packet_backoff);
				Scheduler::instance().schedule(target_, PacketInQueue,NO_DELAY);
			}
	}

	printf("sendingPacketNumberInEachNode-----------------source-------%d\n",sendingPacketNumberInEachNode);
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}


Packet*
More::generateCodedPacketBasedOnSendingQueue(more_rqueue sen)
{
    more_rqueue send = networkcoding.enqueAllCodedPacketInQueueToOneCodedPacket
	    (codeingPacketNumber,512,sen,sen);

    Packet* p = send.get_tail();

    Packet* newPacket =allocpkt();
    struct hdr_cmn* ch = HDR_CMN(p);
    struct hdr_cmn* new_ch = HDR_CMN(newPacket);
    ch->uid_ = new_ch->uid_;

    return p;
}

Packet*
More::source_generate_codedPackets(int position)
{
    Packet* codedPacket = allocpkt();
    struct hdr_cmn* ch = HDR_CMN(codedPacket);
    struct hdr_ip* ih = HDR_IP(codedPacket);
        ch->ptype_ = PT_CBR;
        ch->direction_ = hdr_cmn::DOWN;;
        ch->size() = 1024;
        ch->error() = 0;
        ch->next_hop() = IP_BROADCAST;
        ch->prev_hop_ = index;
        ch->addr_type() = NS_AF_INET;//NS_AF_ILINK;//

        ih->saddr() = ra_addr();
        ih->daddr() = 19;
        ih->sport() = 0;
        ih->dport() = 0;
    codedPacket->allocdata(512);
    PacketData* packdata = (PacketData*)codedPacket->userdata();
    unsigned char* data_zc = (unsigned char*)packdata->data();
    *data_zc = 65;
    for(int i=0;i <511;i++)
    {
		data_zc++;
		*data_zc = 65;
    }
    unsigned char* encode = networkcoding.getRandomEncodingVector(8,1);
    unsigned char encoding = *encode;
    Packet* new_p = networkcoding.encodingPacket(encoding,codeingPacketNumber,codedPacket,512,position);
    return new_p;
}

void
More::source_receive_downstream_dataPackets(Packet* p)
{
	printf("-------------------------source_receive_downstream_dataPackets------------------------\n");

	struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
	printf("totalReceivedPacket ==%d\n",totalReceivedPacket);
	if(totalReceivedPacket < ph->currentIndexReceived)
	totalReceivedPacket = ph->currentIndexReceived;

//    Packet* newPacket = networkcoding.insertNewReceiveCodedPacket
//	    (p,rqueue_0,codeingPacketNumber,512);
//    if(newPacket != 0)
//    {
//    	rqueue_0.enque(newPacket);
//    	downstreamInnovativeNum++;
//    }



	resetHighPriorityTimer(p,index);
}

void
More::source_receive_ACKPackets(Packet* p)
{
	source_receive_downstream_dataPackets(p);
}



void
More::intermediates_receive_dataPackets(Packet* p)
{
	printf("intermediates_receive_dataPackets -- index--%d",index);


	printf("-----------------received packet total == %d\n",totalNumberOfCBRPacket);

	struct hdr_more_pkt* ph_coming = HDR_MORE_PKT(p);
	int roundIndexOfReceivedPacket = ph_coming->batchNum;
	printf("intermediates_receive_dataPackets -- batchIndex--%d",batchIndex);
	printf("intermediates_receive_dataPackets -- roundIndexOfReceivedPacket--%d",roundIndexOfReceivedPacket);
	if(batchIndex < roundIndexOfReceivedPacket)
	{
		printf("remove index of packet = %d\n",ph_coming->indexforthebatch);
		batchIndex = roundIndexOfReceivedPacket;
		rqueue_0.remove_all_packet();
		totalReceivedPacket = 0;
		totalNumberOfCBRPacket = 0;
		//sendingPacketNumberInEachNode = 0;
	}
	totalNumberOfCBRPacket ++ ;
	//printf("intermediates_receive_dataPackets -- batchIndex--%d",batchIndex);
    Packet* newPacket = networkcoding.insertNewReceiveCodedPacket
	    (p,rqueue_0,codeingPacketNumber,512);
    if(newPacket != 0)
    {
    	rqueue_0.enque(newPacket);
    }


	resetHighPriorityTimer(p,index);

}


void
More::intermediates_send_dataPackets()
{
	printf("<-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d begin send_dataPackets<------@@@@@@@@@@@@------>\n",index);
	printf("current------------------------(%f)\n",CURRENT_TIME);
	int updatedLength  = rqueue_0.lenghtofQueue() - totalReceivedPacket;
	int indexFragement = 0;
	for(int i=0;i<updatedLength; i++)
	{

		Packet* PacketInQueue = generateCodedPacketBasedOnSendingQueue(rqueue_0);
		struct hdr_more_pkt* ph = HDR_MORE_PKT(PacketInQueue);

		ph->indexforFragment = indexFragement;
		ph->totalFragmentNum = updatedLength;
		ph->cur_wait_num = updatedLength-1-indexFragement;
		ph->batchNum = batchIndex;
		indexFragement++;

		PacketInQueue = intermediate_configure_receivedPacketNum_batch(PacketInQueue);

		printPacketContent(PacketInQueue);
		struct hdr_cmn* ch = HDR_CMN(PacketInQueue);
		printf("sendingPacketNumberInEachNode------------uid------------uid=%d\n",ch->uid_);
		sendingPacketNumberInEachNode++;
		Scheduler::instance().schedule(target_, PacketInQueue,NO_DELAY);
	}
	printf("fragementLength------------------------(%d)\n",updatedLength);
	printf("batch------------------------(%d)\n",batchIndex);
	printf("-----------------received packet total == %d\n",totalNumberOfCBRPacket);
	printf("sendingPacketNumberInEachNode--------------index=%d----------%d\n",index,sendingPacketNumberInEachNode);
	printf("<-----@@@@@@@@@@@@----totalReceivedPacket==%d-->intermediates_",totalReceivedPacket);
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}

void
More::intermediates_receive_downstream_dataPackets(Packet* p)
{
    // do something when it receives the downstream data;
	printf("----being receive packet ----intermediates_==%d receive_downstream_dataPackets\n",index);

	struct hdr_more_pkt* ph_coming = HDR_MORE_PKT(p);
	int roundIndexOfReceivedPacket = ph_coming->batchNum;
	printf("---out if---%d\n",roundIndexOfReceivedPacket);
	if(batchIndex > roundIndexOfReceivedPacket)
	{
		printf("---in if---%d\n",batchIndex);

		resetHighPriorityTimer(p,index);
		return;
	}
	printf("totalReceivedPacket ==%d\n",totalReceivedPacket);

	if(totalReceivedPacket < ph_coming->currentIndexReceived)
	totalReceivedPacket = ph_coming->currentIndexReceived;

	printf("totalReceivedPacket ==%d\n",totalReceivedPacket);

	struct hdr_cmn* ch = HDR_CMN(p);

	if(ch->prev_hop_ != 19)
	{
	    Packet* newPacket = networkcoding.insertNewReceiveCodedPacket
		    (p,rqueue_0,codeingPacketNumber,512);
	    if(newPacket != 0)
	    {
	    	rqueue_0.enque(newPacket);
	    	destinationReceivedPacketNum++;
	    }
	}

	resetHighPriorityTimer(p,index);

}

void
More::intermediates_receive_ACKPackets(Packet*p)
{
    //do something before forward this ACK;
	printf("<ACK-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d begin send_ACKPackets<------@@@@@@@@@@@@------>\n",index);
	printf("current------------------------(%f)\n",CURRENT_TIME);
	struct hdr_more_pkt* ph_coming = HDR_MORE_PKT(p);
	int roundIndexOfReceivedPacket = ph_coming->batchNum;
	if(batchIndex > roundIndexOfReceivedPacket)
	{
		printf("---in if---%d\n",batchIndex);
		printf("---in if---%d\n",roundIndexOfReceivedPacket);
		resetHighPriorityTimer(p,index);
		return;
	}
	printf("totalReceivedPacket ==%d\n",totalReceivedPacket);
	if(totalReceivedPacket < ph_coming->currentIndexReceived)

	totalReceivedPacket = ph_coming->currentIndexReceived;

	resetHighPriorityTimer(p,index);

	printf("<ACK-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d   end send_ACKPackets<------@@@@@@@@@@@@------>\n",index);
}

Packet*
More::intermediate_configure_receivedPacketNum_batch(Packet* p)
{
	struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);

	ph->currentIndexReceived = rqueue_0.lenghtofQueue();
    ch->ptype_ = PT_CBR;
    ch->direction_ = hdr_cmn::DOWN;;
    ch->size() = 1024;
    ch->error() = 0;
    ch->next_hop() = IP_BROADCAST;
    ch->prev_hop_ = index;
    ch->addr_type() = NS_AF_INET;//NS_AF_ILINK;//

    ih->saddr() = ra_addr();
    ih->daddr() = IP_BROADCAST;
    ih->sport() = 0;
    ih->dport() = 0;

	return p;
}





void
More::destination_receive_dataPackets(Packet* p)
{
	printf("<-----############------>destination_");
	struct hdr_more_pkt* ph_coming = HDR_MORE_PKT(p);

	int roundIndexOfReceivedPacket = ph_coming->batchNum;
	if(batchIndex < roundIndexOfReceivedPacket)
	{
		batchIndex = roundIndexOfReceivedPacket;
		rqueue_0.remove_all_packet();
		totalReceivedPacket = 0;
	}
	printf("batchIndex  ==== %d\n",batchIndex);
    Packet* newPacket = networkcoding.insertNewReceiveCodedPacket
	    (p,rqueue_0,codeingPacketNumber,512);
    if(newPacket != 0)
    {
    	rqueue_0.enque(newPacket);
    	destinationReceivedPacketNum++;
    }
    printf("batch ===---===%d\n",batchIndex);
    printf("rqueue_0 ===---===%d\n",rqueue_0.lenghtofQueue());
	printf("destinationReceivedPacketNum ===---===%d\n",destinationReceivedPacketNum);
	if(destinationReceivedPacketNum==100)
	{
		printf("CURRENT_TIME == %f ---------------------------6666666666666666666666666666----------------"
				"------------------------------------------------------------\n",CURRENT_TIME);
		double duringTime = CURRENT_TIME - 5;
		double throughput = 1024*100*8/duringTime;
		printf("throughput == %f ----------------------------------666666666666666666666-------------"
				"----------------------------------------------------------\n",throughput);
	}
	resetHighPriorityTimer(p,index);
	printf("index ==%d   end receive_dataPackets<------############------>\n",index);
}


void
More::destination_send_ACKPackets(int queueIndex)
{
	printf("<-----############------>destination_send_ACKPackets\n");

    Packet* ack = allocpkt();

	struct hdr_more_pkt* ph = HDR_MORE_PKT(ack);
	ph->batchNum = batchIndex;

    ack = intermediate_configure_receivedPacketNum_batch(ack);


    struct hdr_cmn* ch = HDR_CMN(ack);
    printf("<ACK-----@@@@@@@@@@@@------>uid=%d\n",ch->uid_);
    Scheduler::instance().schedule(target_, ack,NO_DELAY);
	printf("<ACK-----@@@@@@@@@@@@------>destination_");
	printf("index ==%d   end send_ACKPackets<------@@@@@@@@@@@@------>\n",index);

}

void
More::destination_generate_data(int sequence)
{
    Packet* data = allocpkt();
    struct hdr_cmn* ch = HDR_CMN(data);
    struct hdr_ip* ih = HDR_IP(data);
    //struct hdr_cbr* ih = HDR_CBR(data);
    ch->direction() = hdr_cmn::UP;
    ch->prev_hop_ = index;
    ch->ptype() = PT_CBR;
    ch->error() = 0;
    ch->addr_type() = NS_AF_INET;
    ch->size() = 1024;//ip,tcp.more
    ih->saddr() = 0;
    ih->daddr() = 19;
    ih->sport() = 0;
    ih->dport() = 0;
    ih->ttl() = ih->ttl()-1;
    Scheduler::instance().schedule(target_,data,NO_DELAY);
}
//
//int
//More::ExOR_schedule(int sender, int receiver)
//{
//
//	if(newBatchIndex == 1)
//	{
//		return 2;
//	}
//	//                                     up wait  + down wait
//	if(sender == 0 && receiver == 1) return 0 + 5;
//	if(sender == 0 && receiver == 2) return 0 + 4;
//	if(sender == 0 && receiver == 3) return 0 + 3;
//	if(sender == 0 && receiver == 4) return 0 + 2;
//	if(sender == 0 && receiver == 5) return 0 + 1;
//	if(sender == 0 && receiver == 6) return 0 + 0;
//
//
//	if(sender == 1 && receiver == 0) return 0;
//	if(sender == 1 && receiver == 2) return 1 + 5;
//	if(sender == 1 && receiver == 3) return 1 + 4;
//	if(sender == 1 && receiver == 4) return 1 + 3;
//	if(sender == 1 && receiver == 5) return 1 + 2;
//	if(sender == 1 && receiver == 6) return 1 + 1;
//	if(sender == 1 && receiver == 7) return 1 + 0;
//
//	if(sender == 2 && receiver == 0) return 1 + 0;
//	if(sender == 2 && receiver == 1) return 0;
//	if(sender == 2 && receiver == 3) return 2 + 4;
//	if(sender == 2 && receiver == 4) return 2 + 3;
//	if(sender == 2 && receiver == 5) return 2 + 2;
//	if(sender == 2 && receiver == 6) return 2 + 1;
//	if(sender == 2 && receiver == 7) return 2 + 0;
//
//	if(sender == 3 && receiver == 0) return 2;
//	if(sender == 3 && receiver == 1) return 1;
//	if(sender == 3 && receiver == 2) return 0;
//	if(sender == 3 && receiver == 4) return 3 + 3;
//	if(sender == 3 && receiver == 5) return 3 + 2;
//	if(sender == 3 && receiver == 6) return 3 + 1;
//	if(sender == 3 && receiver == 7) return 3 + 0;
//
//
//	if(sender == 4 && receiver == 0) return 3;
//	if(sender == 4 && receiver == 1) return 2;
//	if(sender == 4 && receiver == 2) return 1;
//	if(sender == 4 && receiver == 3) return 0;
//	if(sender == 4 && receiver == 5) return 4 + 2;
//	if(sender == 4 && receiver == 6) return 4 + 1;
//	if(sender == 4 && receiver == 7) return 4 + 0;
//
//	if(sender == 5 && receiver == 0) return 4;
//	if(sender == 5 && receiver == 1) return 3;
//	if(sender == 5 && receiver == 2) return 2;
//	if(sender == 5 && receiver == 3) return 1;
//	if(sender == 5 && receiver == 4) return 0;
//	if(sender == 5 && receiver == 6) return 5 + 1;
//	if(sender == 5 && receiver == 7) return 5 + 0;
//
//	if(sender == 6 && receiver == 0) return 5;
//	if(sender == 6 && receiver == 1) return 4;
//	if(sender == 6 && receiver == 2) return 3;
//	if(sender == 6 && receiver == 3) return 2;
//	if(sender == 6 && receiver == 4) return 1;
//	if(sender == 6 && receiver == 5) return 0;
//	if(sender == 6 && receiver == 7) return 6 + 0;
//
//	if(sender == 7 && receiver == 0) return 6;
//	if(sender == 7 && receiver == 1) return 5;
//	if(sender == 7 && receiver == 2) return 4;
//	if(sender == 7 && receiver == 3) return 3;
//	if(sender == 7 && receiver == 4) return 2;
//	if(sender == 7 && receiver == 5) return 1;
//	if(sender == 7 && receiver == 6) return 1;
//
//	return 10;
//
//}

//int
//More::ExOR_schedule(int sender, int receiver)
//{
//
//	if(newBatchIndex == 1)
//	{
//		return 2;
//	}
//	//                                     up wait  + down wait
//	if(sender == 0 && receiver == 2) return 0 + 6;
//	if(sender == 0 && receiver == 5) return 0 + 5;
//
//
//
//	if(sender == 2 && receiver == 5) return 1+ 3;
//	if(sender == 2 && receiver == 8) return 1+ 4;
//	if(sender == 2 && receiver == 0) return 0;
//
//
//	if(sender == 5 && receiver == 11) return 2 + 3;
//	if(sender == 5 && receiver == 8) return 2 + 4;
//	if(sender == 5 && receiver == 2) return 0;
//	if(sender == 5 && receiver == 0) return 1;
//
//
//	if(sender == 8 && receiver == 14) return 3 + 2;
//	if(sender == 8 && receiver == 11) return 3 + 3;
//	if(sender == 8 && receiver == 5) return 0;
//	if(sender == 8 && receiver == 2) return 1;
//
//	if(sender == 11 && receiver == 17) return 4 + 1;
//	if(sender == 11 && receiver == 14) return 4 + 2;
//	if(sender == 11 && receiver == 8) return 0;
//	if(sender == 11 && receiver == 5) return 1;
//
//	if(sender == 14 && receiver == 19) return 5 + 0;
//	if(sender == 14 && receiver == 17) return 5 + 1;
//	if(sender == 14 && receiver == 11) return 0;
//	if(sender == 14 && receiver == 8) return 1;
//
//	if(sender == 17 && receiver == 19) return 6 + 0;
//	if(sender == 17 && receiver == 14) return 0;
//	if(sender == 17 && receiver == 11) return 1;
//
//
//	if(sender == 19 && receiver == 17) return 0;
//	if(sender == 19 && receiver == 14) return 1;
//
//
//	return 10;
//
//}

int
More::ExOR_schedule(int sender, int receiver)
{

	if(newBatchIndex == 1)
	{
		return 2;
	}
	//                                     up wait  + down wait
	if(sender == 0 && receiver == 2) return 1;
	if(sender == 0 && receiver == 5) return 0;



	if(sender == 2 && receiver == 5) return 1;
	if(sender == 2 && receiver == 8) return 0;
	if(sender == 2 && receiver == 0) return 0;


	if(sender == 5 && receiver == 11) return 0;
	if(sender == 5 && receiver == 8) return 2;
	if(sender == 5 && receiver == 2) return 0;
	if(sender == 5 && receiver == 0) return 1;


	if(sender == 8 && receiver == 14) return 0;
	if(sender == 8 && receiver == 11) return 2;
	if(sender == 8 && receiver == 5) return 1;
	if(sender == 8 && receiver == 2) return 0;

	if(sender == 11 && receiver == 17) return 0;
	if(sender == 11 && receiver == 14) return 2;
	if(sender == 11 && receiver == 8) return 1;
	if(sender == 11 && receiver == 5) return 0;

	if(sender == 14 && receiver == 19) return 0;
	if(sender == 14 && receiver == 17) return 2;
	if(sender == 14 && receiver == 11) return 1;
	if(sender == 14 && receiver == 8) return 0;

	if(sender == 17 && receiver == 19) return 1 + 0;
	if(sender == 17 && receiver == 14) return 0;
	if(sender == 17 && receiver == 11) return 1;


	if(sender == 19 && receiver == 17) return 0;
	if(sender == 19 && receiver == 14) return 1;


	return 10;

}

//timer function


void
More::WaitForReceivingNewpacketsFinishTimerHandler()
{
    printf("index == %d WaitForReceivingNewpacketsFinishTimerHandler timer expired\n",index);

    if(wrNewfTimer.busy())
    {
    	 wrNewfTimer.stop();
    	 wrNewfTimer.start(0.05);
    }
    else
    {
        wrNewfTimer.start(0.05);
    }
}


void
More::WaitForHighPrioritySendingTimerHandler()
{
	printf("index == %d WaitForHighPrioritySendingTimerHandler\n",index);
	printf("CURRENT_TIME == %f WaitForHighPrioritySendingTimerHandler\n",CURRENT_TIME);

	printf("newBatchIndex == %d newBatchIndex\n",newBatchIndex);

	if(index !=19 && index !=0)
	intermediates_send_dataPackets();
	else if(index == 0)
	{
		if(newBatchIndex == 1)
		{
//			source_send_newDataPacket();
//			newBatchIndex = 0;
		}
		else
		{
			source_send_dataPackets();
		}
	}
	else if(index == 19)
	destination_send_ACKPackets(0);

}

void
More::WaitForReceivingACKpacketsFinishTimerHandler()
{

}

void
More::DectinationACKWaitingTimerHandler()
{
	// this is used by nodes to increase Unack packets
	//destination_send_ACKPackets(0);
}

void
More::resetNewPacketTimer()
{
    printf("resetNewPacketTimer\n");


    wrNewfTimer.start(0.05);


    printf("resetNewPacketTimer done\n");
}

void
More::resetDestinationACKTimer(Packet* p)
{

    printf("resetDestinationACKTimer  at index ==%d\n",index);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    struct hdr_cmn* ch = HDR_CMN(p);

    int cur_num = ph->cur_wait_num-1;
    double backtime = cur_num*onePacketSendingDelay;

    if(destionACKTimer.busy())
    {
    	destionACKTimer.stop();
    	destionACKTimer.start(backtime);
    }
    else
    {
    	destionACKTimer.start(backtime);
    }
}



void
More::resetSendTimer()
{
	// after sending packet, how long it need to wait
	int backoff = op.sendTransmissionTime(index);
	double backtime = backoffpacketNum*backoff*onePacketSendingDelay;

    if(wHighpsTimer.busy())
    {
    	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
    			- Scheduler::instance().clock();
    	wHighpsTimer.stop();

    	if(needwait < backtime) wHighpsTimer.start(backtime);
    	else wHighpsTimer.start(needwait);
    }
    else
    {
		wHighpsTimer.start(backtime);
    }
}

void
More::resetOverhearHighPriorityTimer(const Packet* p,int ReceiverIndex)
{
    printf("resetOverhearHighPriorityTimer  at index ==%d\n",index);

    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

    int cur_num = ph->cur_wait_num;

    int backoff = op.getBackoffTime(p,ReceiverIndex);

    double backtime = backoffpacketNum*backoff*onePacketSendingDelay;

    if(wHighpsTimer.busy())
    {
    	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
    	    			- Scheduler::instance().clock();
		wHighpsTimer.stop();
//    	if(needwait < backtime) wHighpsTimer.start(needwait);
//    	else
    	wHighpsTimer.start(backtime);
    }
    else
    {
		wHighpsTimer.start(backtime);
    }
}

void
More::resetHighPriorityTimer(Packet* p,int ReceiverIndex)
{
	// after received packet, how long it needs to wait
    printf("resetHighPriorityTimer  at index ==%d\n",index);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    struct hdr_cmn* ch = HDR_CMN(p);

    int cur_num = ph->cur_wait_num;
    printf("cur_num backoff time = %d\n",cur_num);
    int backoff = ExOR_schedule(ch->prev_hop_,index);
    printf("resetHighPriorityTimer backoff backoff = %d\n",backoff);
    double backtime = backoffpacketNum*backoff*onePacketSendingDelay+
    		cur_num*onePacketSendingDelay+2*onePacketSendingDelay;


    printf("resetHighPriorityTimer backoff time = %f\n",backoffpacketNum*backoff*onePacketSendingDelay);

    printf("resetHighPriorityTimer backoff time = %f\n",backtime);

    printf("CURRENT_TIME == %f resetHighPriorityTimer\n",CURRENT_TIME);
    if(wHighpsTimer.busy())
    {
    	wHighpsTimer.stop();
        wHighpsTimer.start(backtime);
     }
     else
     {
    	wHighpsTimer.start(backtime);
     }

}



//testing function
void
More::printPacketContent(Packet* packetObj)
{
    PacketData* packdata_1 = (PacketData*)packetObj->userdata();

    unsigned char* data_for_add_1 = (unsigned char*)packdata_1->data();

     printf("printPacketContent	 data: ");
     for(int i=0;i<512;i++)
     {
    	 if(i <10)printf("%d-",*data_for_add_1);
    	 data_for_add_1++;
     }

     printf("	encoding vector");
     for(int i=0;i<codeingPacketNumber;i++)
     {
    	 printf("%d-",*data_for_add_1);
    	 data_for_add_1++;
     }

     printf("\n");
}

/*
 * more_nc.cc
 *
 *  Created on: Feb 24, 2014
 *      Author: chenzhang
 */

#include "more_nc.h"
#include <math.h>
#include <cstdlib>
#include <stdlib.h>
#include <iostream>
#include <stdio.h>
#include <string.h>



More_nc::More_nc()
{

}


//把2个无符号的整数相乘
uint8_t
More_nc::multiplyFunction(uint8_t a,uint8_t b)
{
	uint8_t p = 0;
	uint8_t counter;
	uint8_t carry;
	for (counter = 0; counter < 9; counter++) {
		if (b & 1)
			p ^= a;
		carry = a & 0x80;  /* detect if x^8 term is about to be generated */
		a <<= 1;
		if (carry)
			a ^= 0x001B; /* replace x^8 with x^4 + x^3 + x + 1 */
		b >>= 1;
	}
//	unsigned int c_int = p;
	//std::cout << "---------------------------------------------"<<"multiplyFunction3--"<< std::endl;
	return p;



	}

void
More_nc::maintainRowEchelon()
{

}

unsigned char*
More_nc::getRandomEncodingVector(unsigned int symbolSize_,unsigned int packetNumber_)
{

	unsigned char coder[packetNumber_];
	for (int i=0; i<packetNumber_; i++)
	{
	    coder[i]=rand() % (int)pow(2, symbolSize_)+1;
	   // if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;

	    while(coder[i]==0)
	    {
		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
	    }
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
//		if(coder[i]==0)coder[i]=rand() % (int)pow(2, symbolSize_)+1;
	}
	if(coder[0]==0)
	    printf("here is big mistake for encoding vector, where code is 0\n");
	unsigned char *pointToCoder =coder;
	return pointToCoder;
}

Packet*
More_nc::encodingPacket(unsigned char encoding,unsigned int packetNumber_, Packet* originalPacket,int packetLength,int position)
{
	PacketData* packdata = (PacketData*)originalPacket->userdata();

	unsigned char* data = (unsigned char*)packdata->data();

	unsigned char *coded_data_ = new unsigned char[packetLength+packetNumber_];
	//printf("repeatValue===========1\n");
    for(int i=0;i <packetLength+packetNumber_;i++)
    {
    	*coded_data_ = 0;
    	coded_data_++;
    }

    for(int i=0;i <packetLength+packetNumber_;i++)
    {
    	coded_data_--;
    }

	int lengthOfBackoff = position;//requeue_backoff.lenghtofQueue();

	//printf("lengthOfBackoff----%d\n");

    for(int i=0;i <lengthOfBackoff+packetLength;i++)
    {
    	coded_data_++;
    }

	*coded_data_= 1;

    for(int i=0;i <lengthOfBackoff+packetLength;i++)
    {
    	coded_data_--;
    }

    for(int i=0;i <packetLength;i++)
    {
    	unsigned char data_char = *data;
    	unsigned char data_char_coded  = multiplyFunction(data_char,encoding);
    	*data = data_char_coded;
    	*coded_data_ = *data;
    	coded_data_++;
    	data++;
    }
    //printf("repeatValue===========1------%d\n",packetNumber_);
	for(int i=0; i<packetNumber_;i++)
	{
    	unsigned char data_char = *coded_data_;
    	//printf("repeatValue========3==%d\n",i);
    	unsigned char data_char_coded = multiplyFunction(data_char,encoding);
    	*coded_data_ = data_char_coded;
    	coded_data_++;
	}
	//printf("repeatValue========3==1\n");
    for(int i=0;i <packetLength+packetNumber_;i++)
    {
    	coded_data_--;
    }

   originalPacket->allocdata(packetLength+packetNumber_);// fei pei kong jian

	PacketData* packdata_coded = (PacketData*)originalPacket->userdata();
	unsigned char* data_for_coded = (unsigned char*)packdata_coded->data();

    for(int i=0;i <packetLength+packetNumber_;i++)
    {
    	*data_for_coded  =*coded_data_;
    	data_for_coded++;
    	coded_data_++;
    }
    return originalPacket;
}


Packet*
More_nc::addTwoPackets(Packet*p1, Packet*p2,unsigned int packetNumber_,int packetLength)
{

    PacketData* packdata_1 = (PacketData*)p1->userdata();
    PacketData* packdata_2 = (PacketData*)p2->userdata();

    unsigned char* data_for_add_1 = (unsigned char*)packdata_1->data();
    unsigned char* data_for_add_2 = (unsigned char*)packdata_2->data();

    for(int i=0;i<packetNumber_+packetLength;i++)
    {
    	*data_for_add_2 = *data_for_add_1^*data_for_add_2;
    	data_for_add_2++;
    	data_for_add_1++;
    }

    return p2;
}



Packet*
More_nc::encodingPacketByCoefficient(Packet*p1,unsigned int packetNumber_,int packetLength)
{
	unsigned char* encoding = getRandomEncodingVector(8,1);
	unsigned char encode = *encoding;
	unsigned int encoding_int = encode;


	unsigned char* data_for_add_1 = p1->accessdata();



    for(int i=0;i<packetNumber_+packetLength;i++)
    {
    	*data_for_add_1 = multiplyFunction(*data_for_add_1,encode);

    	data_for_add_1++;
    }


	return p1;
}

more_rqueue
More_nc::enqueCodedPacket(Packet* p,unsigned int packetNumber_,int packetLength,more_rqueue rqueue,more_rqueue rqueue_send)
{
	more_rqueue rqueueInFunction = rqueue;

	int length = rqueueInFunction.lenghtofQueue();
	//std::cout << "----------------"<<"0002========"<< rqueue_send.lenghtofQueue() << std::endl;

	if(length >0)
	{

		Packet* combinedPacket = p->copy();

		for(int i=0;i<length;i++)
		{
		    Packet* PacketInQueue = rqueueInFunction.deque();
		    Packet* PacketForAdd = encodingPacketByCoefficient(PacketInQueue,packetNumber_,packetLength);
		    combinedPacket = addTwoPackets(PacketForAdd,combinedPacket,packetNumber_,packetLength);
		}
		rqueue_send.enque(combinedPacket);
	}
	else
	{
		Packet* combinedPacket = p->copy();

		rqueue_send.enque(combinedPacket);
	}
	return rqueue_send;
}





Packet*
More_nc::enqueCodedPacket(unsigned int packetNumber_,int packetLength,more_rqueue rqueue_send)
{
	int length = rqueue_send.lenghtofQueue();
	//std::cout << "------------------new-----------------------------------new-----------------------------------new---------------------------"<<"0002========"<< rqueue_send.lenghtofQueue() << std::endl;
	Packet* combinedPacket = rqueue_send.deque();

	for(int i=0;i<length-1;i++)
	{
		Packet* PacketInQueue = rqueue_send.deque();

		Packet* PacketForAdd = encodingPacketByCoefficient(PacketInQueue,packetNumber_,packetLength);

		combinedPacket = addTwoPackets(PacketForAdd,combinedPacket,packetNumber_,packetLength);

	}
	return combinedPacket;
}





more_rqueue
More_nc::enqueAllCodedPacketInQueueToOneCodedPacket(unsigned int packetNumber_,int packetLength,more_rqueue receive_queue,more_rqueue rqueue_send)
{

    int length = receive_queue.lenghtofQueue();
    more_rqueue rqueue_send_inner;
    if(length >0)
    {
	Packet* combinedPacket = receive_queue.deque()->copy();
	for(int i=0;i<length-1;i++)
	{
	    Packet* PacketInQueue = receive_queue.deque()->copy();
	    Packet* PacketForAdd = encodingPacketByCoefficient(PacketInQueue,packetNumber_,packetLength);
	    combinedPacket = addTwoPackets(PacketForAdd,combinedPacket,packetNumber_,packetLength);
	    Packet::free(PacketForAdd);
	}
	rqueue_send_inner.enque(combinedPacket);
	    //std::cout << "------------------new------1---23-------345345"<<receive_queue.lenghtofQueue()<<std::endl;
    }
    else
    {
	    //no packet
    }
    return rqueue_send_inner;
}


Packet*
More_nc::multipleAPacketByCoefficient(Packet*p,int packetNumber_,int packetLength,unsigned char encoding)
{
	unsigned char* data_for_multiple = p->accessdata();

	for(int i=0;i<packetNumber_+packetLength;i++)
	{
		*data_for_multiple = multiplyFunction(*data_for_multiple,encoding);
		data_for_multiple++;
	}
	return p;
}

Packet*
More_nc::minusOrAddTwoPacketsTogtherReturnTheFirstPacket(Packet*p1,Packet*p2,int packetNumber_,int packetLength)
{
	unsigned char* data_for_addOrMinus_1 = p1->accessdata();
	unsigned char* data_for_addOrMinus_2 = p2->accessdata();

   for(int i=0;i<packetNumber_+packetLength;i++)
	{
		*data_for_addOrMinus_1 = *data_for_addOrMinus_1^*data_for_addOrMinus_2;
		data_for_addOrMinus_1++;
		data_for_addOrMinus_2++;
	}

   return p1;

}

int
More_nc::getTheFirstNotNullValueOfCoefficientPosition(Packet*p,int packetNumber_,int packetLength)
{
	int value = 0;
	unsigned char* data_inPacket = p->accessdata();


//	PacketData* packdata = (PacketData*)p->userdata();
//
//	unsigned char* data_inPacket = (unsigned char*)packdata->data();

	for(int i=0;i<packetLength;i++)
	{
		data_inPacket++;
		//printf("data_inPacket=======%d=========%d\n",i,*data_inPacket);
	}
	//printf("data_inPacket=======%d=========%d\n",0,*data_inPacket);
	for(int i=0;i<packetNumber_;i++)
	{
		unsigned char b = 255;
		if(*data_inPacket !=0){// may have errors
		//if((b^*data_inPacket) != 0){
			value = i;
			return value;
		}
		data_inPacket++;
	}
	return -1;
}

Packet*
More_nc::setFirstNotNullValuesOfCoefficientToOneByMultiplyInverseValueForWholePacket(Packet*p,unsigned char inverseValue,int packetNumber_,int packetLength)
{
	unsigned char* data_inPacket = p->accessdata();
	for(int i=0;i<packetNumber_+packetLength;i++)
	{
		*data_inPacket = multiplyFunction(*data_inPacket,inverseValue);
		data_inPacket++;
	}
	return p;
}

more_rqueue
More_nc::changeValueOfQueueBasedOnOthersFirstNotNullValueOfCoefficient(more_rqueue receiveQueue,int packetNumber_,int packetLength,Packet* newPacket)
{


}

more_rqueue
More_nc::changePositionOfQueueBasedOnFirstNotNullValueOfCoefficient(more_rqueue receiveQueue,int packetNumber_,int packetLength,Packet* newPacket)
{
	int newPacketNoNullCoefficientPosition = getTheFirstNotNullValueOfCoefficientPosition(newPacket,packetNumber_,packetLength);

	int LengthOfQueue = receiveQueue.lenghtofQueue();
	if(LengthOfQueue == 0)
	{
		receiveQueue.enque(newPacket);
	}
	for(int i=0;i<LengthOfQueue;i++)
	{
		Packet* packetInQueue = receiveQueue.deque();
		if(newPacketNoNullCoefficientPosition != -1)
		{
			int packetInQueueNoNullCoefficientPosition = getTheFirstNotNullValueOfCoefficientPosition(packetInQueue,packetNumber_,packetLength);
			if(packetInQueueNoNullCoefficientPosition > newPacketNoNullCoefficientPosition)
			{
				receiveQueue.enque(newPacket);
				receiveQueue.enque(packetInQueue);
				newPacketNoNullCoefficientPosition = -1;
			}
			else
			{
				receiveQueue.enque(packetInQueue);
			}
		}
		else
		{
			receiveQueue.enque(packetInQueue);
		}

	}
	if(LengthOfQueue == receiveQueue.lenghtofQueue())
	{
		receiveQueue.enque(newPacket);
	}
	return receiveQueue;
}


unsigned char
More_nc::getCoefficientByCoefficientPosition(Packet* p,int position,int packetNumber_,int packetLength)
{
	unsigned char* data_inPacket = p->accessdata();
	for(int i=0;i<packetLength;i++)
	{
		data_inPacket++;
	}
	for(int i=0;i<position;i++)
	{
		data_inPacket++;
	}
	return *data_inPacket;
}




more_rqueue
More_nc::createReduceRowEchelon(more_rqueue receiveQueue,int packetNumber_,int packetLength,Packet* newPacket)
{
	int lengthOfQueue = receiveQueue.lenghtofQueue();
	int newPacketNoNullCoefficientPosition = getTheFirstNotNullValueOfCoefficientPosition(newPacket,packetNumber_,packetLength);
	if(lengthOfQueue >= 1)
	{
		for(int i=0;i<lengthOfQueue;i++)
		{
			Packet* packetInQueue = receiveQueue.deque();
			unsigned char valueNeedToZero = getCoefficientByCoefficientPosition(packetInQueue,newPacketNoNullCoefficientPosition,packetNumber_,packetLength);
			Packet* newPacketCopy = newPacket->copy();
			Packet* newPacketForMinus = multipleAPacketByCoefficient(newPacketCopy,packetNumber_,packetLength,valueNeedToZero);
			packetInQueue = minusOrAddTwoPacketsTogtherReturnTheFirstPacket(packetInQueue,newPacketForMinus,packetNumber_,packetLength);
			receiveQueue.enque(packetInQueue);
			//memory leak
			Packet::free(newPacketForMinus);
			//
		}
	}
	return receiveQueue;

}


Packet*
More_nc::insertNewReceiveCodedPacket(Packet*newPacket,more_rqueue receiveQueue,int packetNumber_,int packetLength)
{
	int lengthOfQueue = receiveQueue.lenghtofQueue();
	if(lengthOfQueue == 0)
	{
		int newPacketNoNullCoefficientPosition = getTheFirstNotNullValueOfCoefficientPosition(newPacket,packetNumber_,packetLength);
		unsigned char valueofFirstNoNullCoefficient = getCoefficientByCoefficientPosition(newPacket,newPacketNoNullCoefficientPosition,packetNumber_,packetLength);
		int inverseValueForFirstNoNullCoefficient = getInverseValue(valueofFirstNoNullCoefficient);

		newPacket = setFirstNotNullValuesOfCoefficientToOneByMultiplyInverseValueForWholePacket(newPacket,inverseValueForFirstNoNullCoefficient,packetNumber_,packetLength);
	}
	else
	{
		for(int i=0; i<lengthOfQueue;i++)
		{
			Packet* pacektInQueue = receiveQueue.deque();
			int pacektInQueueNoNullCoefficientPosition = getTheFirstNotNullValueOfCoefficientPosition(pacektInQueue,packetNumber_,packetLength);
			unsigned char valueofPacektInQueueCoefficient = getCoefficientByCoefficientPosition(newPacket,pacektInQueueNoNullCoefficientPosition,packetNumber_,packetLength);
			if(valueofPacektInQueueCoefficient !=0)
			{
				unsigned char inverseValueForPacektInQueueCoefficient = getInverseValue(valueofPacektInQueueCoefficient);
				newPacket = setFirstNotNullValuesOfCoefficientToOneByMultiplyInverseValueForWholePacket(newPacket,inverseValueForPacektInQueueCoefficient,packetNumber_,packetLength);
				newPacket = minusOrAddTwoPacketsTogtherReturnTheFirstPacket(newPacket,pacektInQueue,packetNumber_,packetLength);
			}
		}

		// set the first value to 1
		int newPacketNoNullCoefficientPosition = getTheFirstNotNullValueOfCoefficientPosition(newPacket,packetNumber_,packetLength);
		unsigned char valueofFirstNoNullCoefficient = getCoefficientByCoefficientPosition(newPacket,newPacketNoNullCoefficientPosition,packetNumber_,packetLength);
		int inverseValueForFirstNoNullCoefficient = getInverseValue(valueofFirstNoNullCoefficient);
		newPacket = setFirstNotNullValuesOfCoefficientToOneByMultiplyInverseValueForWholePacket(newPacket,inverseValueForFirstNoNullCoefficient,packetNumber_,packetLength);


	}
	//printf("innovate\n");
	bool innovative = false;
	unsigned char* data_for_newPacket = newPacket->accessdata();
    for(int i=0;i<packetNumber_+packetLength;i++)
    {
    	unsigned char data_in_newPacket = *data_for_newPacket;
    	if(data_in_newPacket !=0)
    	{
    		innovative = true;
    		break;
    	}

    	data_for_newPacket++;
    }

    if(innovative)return newPacket;
    else
    	{
    		Packet::free(newPacket);
    		return 0;
    	}
}


int*
More_nc::testPoint(int* a)
{
	*a =5;
	return a;
}

unsigned char
More_nc::getInverseValue(unsigned char inputValue)
{
	unsigned char inverseArray[256];// = new unsigned int[256];
	inverseArray[0] = 0;
	inverseArray[1] = 1;
	inverseArray[2] = 141;
	inverseArray[3] = 246;
	inverseArray[4] = 203;
	inverseArray[5] = 82;
	inverseArray[6] = 123;
	inverseArray[7] = 209;
	inverseArray[8] = 232;
	inverseArray[9] = 79;
	inverseArray[10] = 41;
	inverseArray[11] = 192;
	inverseArray[12] = 176;
	inverseArray[13] = 225;
	inverseArray[14] = 229;
	inverseArray[15] = 199;
	inverseArray[16] = 116;
	inverseArray[17] = 180;
	inverseArray[18] = 170;
	inverseArray[19] = 75;
	inverseArray[20] = 153;
	inverseArray[21] = 43;
	inverseArray[22] = 96;
	inverseArray[23] = 95;
	inverseArray[24] = 88;
	inverseArray[25] = 63;
	inverseArray[26] = 253;
	inverseArray[27] = 204;
	inverseArray[28] = 255;
	inverseArray[29] = 64;
	inverseArray[30] = 238;
	inverseArray[31] = 178;
	inverseArray[32] = 58;
	inverseArray[33] = 110;
	inverseArray[34] = 90;
	inverseArray[35] = 241;
	inverseArray[36] = 85;
	inverseArray[37] = 77;
	inverseArray[38] = 168;
	inverseArray[39] = 201;
	inverseArray[40] = 193;
	inverseArray[41] = 10;
	inverseArray[42] = 152;
	inverseArray[43] = 21;
	inverseArray[44] = 48;
	inverseArray[45] = 68;
	inverseArray[46] = 162;
	inverseArray[47] = 194;
	inverseArray[48] = 44;
	inverseArray[49] = 69;
	inverseArray[50] = 146;
	inverseArray[51] = 108;
	inverseArray[52] = 243;
	inverseArray[53] = 57;
	inverseArray[54] = 102;
	inverseArray[55] = 66;
	inverseArray[56] = 242;
	inverseArray[57] = 53;
	inverseArray[58] = 32;
	inverseArray[59] = 111;
	inverseArray[60] = 119;
	inverseArray[61] = 187;
	inverseArray[62] = 89;
	inverseArray[63] = 25;
	inverseArray[64] = 29;
	inverseArray[65] = 254;
	inverseArray[66] = 55;
	inverseArray[67] = 103;
	inverseArray[68] = 45;
	inverseArray[69] = 49;
	inverseArray[70] = 245;
	inverseArray[71] = 105;
	inverseArray[72] = 167;
	inverseArray[73] = 100;
	inverseArray[74] = 171;
	inverseArray[75] = 19;
	inverseArray[76] = 84;
	inverseArray[77] = 37;
	inverseArray[78] = 233;
	inverseArray[79] = 9;
	inverseArray[80] = 237;
	inverseArray[81] = 92;
	inverseArray[82] = 5;
	inverseArray[83] = 202;
	inverseArray[84] = 76;
	inverseArray[85] = 36;
	inverseArray[86] = 135;
	inverseArray[87] = 191;
	inverseArray[88] = 24;
	inverseArray[89] = 62;
	inverseArray[90] = 34;
	inverseArray[91] = 240;
	inverseArray[92] = 81;
	inverseArray[93] = 236;
	inverseArray[94] = 97;
	inverseArray[95] = 23;
	inverseArray[96] = 22;
	inverseArray[97] = 94;
	inverseArray[98] = 175;
	inverseArray[99] = 211;
	inverseArray[100] = 73;
	inverseArray[101] = 166;
	inverseArray[102] = 54;
	inverseArray[103] = 67;
	inverseArray[104] = 244;
	inverseArray[105] = 71;
	inverseArray[106] = 145;
	inverseArray[107] = 223;
	inverseArray[108] = 51;
	inverseArray[109] = 147;
	inverseArray[110] = 33;
	inverseArray[111] = 59;
	inverseArray[112] = 121;
	inverseArray[113] = 183;
	inverseArray[114] = 151;
	inverseArray[115] = 133;
	inverseArray[116] = 16;
	inverseArray[117] = 181;
	inverseArray[118] = 186;
	inverseArray[119] = 60;
	inverseArray[120] = 182;
	inverseArray[121] = 112;
	inverseArray[122] = 208;
	inverseArray[123] = 6;
	inverseArray[124] = 161;
	inverseArray[125] = 250;
	inverseArray[126] = 129;
	inverseArray[127] = 130;
	inverseArray[128] = 131;
	inverseArray[129] = 126;
	inverseArray[130] = 127;
	inverseArray[131] = 128;
	inverseArray[132] = 150;
	inverseArray[133] = 115;
	inverseArray[134] = 190;
	inverseArray[135] = 86;
	inverseArray[136] = 155;
	inverseArray[137] = 158;
	inverseArray[138] = 149;
	inverseArray[139] = 217;
	inverseArray[140] = 247;
	inverseArray[141] = 2;
	inverseArray[142] = 185;
	inverseArray[143] = 164;
	inverseArray[144] = 222;
	inverseArray[145] = 106;
	inverseArray[146] = 50;
	inverseArray[147] = 109;
	inverseArray[148] = 216;
	inverseArray[149] = 138;
	inverseArray[150] = 132;
	inverseArray[151] = 114;
	inverseArray[152] = 42;
	inverseArray[153] = 20;
	inverseArray[154] = 159;
	inverseArray[155] = 136;
	inverseArray[156] = 249;
	inverseArray[157] = 220;
	inverseArray[158] = 137;
	inverseArray[159] = 154;
	inverseArray[160] = 251;
	inverseArray[161] = 124;
	inverseArray[162] = 46;
	inverseArray[163] = 195;
	inverseArray[164] = 143;
	inverseArray[165] = 184;
	inverseArray[166] = 101;
	inverseArray[167] = 72;
	inverseArray[168] = 38;
	inverseArray[169] = 200;
	inverseArray[170] = 18;
	inverseArray[171] = 74;
	inverseArray[172] = 206;
	inverseArray[173] = 231;
	inverseArray[174] = 210;
	inverseArray[175] = 98;
	inverseArray[176] = 12;
	inverseArray[177] = 224;
	inverseArray[178] = 31;
	inverseArray[179] = 239;
	inverseArray[180] = 17;
	inverseArray[181] = 117;
	inverseArray[182] = 120;
	inverseArray[183] = 113;
	inverseArray[184] = 165;
	inverseArray[185] = 142;
	inverseArray[186] = 118;
	inverseArray[187] = 61;
	inverseArray[188] = 189;
	inverseArray[189] = 188;
	inverseArray[190] = 134;
	inverseArray[191] = 87;
	inverseArray[192] = 11;
	inverseArray[193] = 40;
	inverseArray[194] = 47;
	inverseArray[195] = 163;
	inverseArray[196] = 218;
	inverseArray[197] = 212;
	inverseArray[198] = 228;
	inverseArray[199] = 15;
	inverseArray[200] = 169;
	inverseArray[201] = 39;
	inverseArray[202] = 83;
	inverseArray[203] = 4;
	inverseArray[204] = 27;
	inverseArray[205] = 252;
	inverseArray[206] = 172;
	inverseArray[207] = 230;
	inverseArray[208] = 122;
	inverseArray[209] = 7;
	inverseArray[210] = 174;
	inverseArray[211] = 99;
	inverseArray[212] = 197;
	inverseArray[213] = 219;
	inverseArray[214] = 226;
	inverseArray[215] = 234;
	inverseArray[216] = 148;
	inverseArray[217] = 139;
	inverseArray[218] = 196;
	inverseArray[219] = 213;
	inverseArray[220] = 157;
	inverseArray[221] = 248;
	inverseArray[222] = 144;
	inverseArray[223] = 107;
	inverseArray[224] = 177;
	inverseArray[225] = 13;
	inverseArray[226] = 214;
	inverseArray[227] = 235;
	inverseArray[228] = 198;
	inverseArray[229] = 14;
	inverseArray[230] = 207;
	inverseArray[231] = 173;
	inverseArray[232] = 8;
	inverseArray[233] = 78;
	inverseArray[234] = 215;
	inverseArray[235] = 227;
	inverseArray[236] = 93;
	inverseArray[237] = 80;
	inverseArray[238] = 30;
	inverseArray[239] = 179;
	inverseArray[240] = 91;
	inverseArray[241] = 35;
	inverseArray[242] = 56;
	inverseArray[243] = 52;
	inverseArray[244] = 104;
	inverseArray[245] = 70;
	inverseArray[246] = 3;
	inverseArray[247] = 140;
	inverseArray[248] = 221;
	inverseArray[249] = 156;
	inverseArray[250] = 125;
	inverseArray[251] = 160;
	inverseArray[252] = 205;
	inverseArray[253] = 26;
	inverseArray[254] = 65;
	inverseArray[255] = 28;
//	for(unsigned int i=0;i<256;i++)
//	{
//
//		for(unsigned int j=0;j<256;j++)
//		{
//			inverseArray[i] = multiplyFunction(i,j);
//
//			if( inverseArray[i] == 1)
//			{
//				std::cout <<  "inverseArray["<<i<<"] = "<< j<<";"<<std::endl;
//			}
//		}
//	}

	return inverseArray[inputValue];
}
int
More_nc::queueLength(more_rqueue receiveQueue,unsigned int packetNumber_,int packetLength)
{
	int LengthOfQueue = receiveQueue.lenghtofQueue();
	for(int i=0;i<LengthOfQueue;i++)
	{
		Packet* packetInQueue = receiveQueue.deque();
		int packetInQueueNoNullCoefficientPosition = getTheFirstNotNullValueOfCoefficientPosition(packetInQueue,packetNumber_,packetLength);
		if(packetInQueueNoNullCoefficientPosition == i)
		{

		}
		else
		{
			return i;
		}
	}
	return LengthOfQueue;
}

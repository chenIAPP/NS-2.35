/*
 * more_nsb.h
 *
 *  Created on: 2015-09-21
 *      Author: winemocol
 */

#ifndef MORE_NSB_H_
#define MORE_NSB_H_

class More_NSB
{
	public:
	More_NSB();
};


#endif /* MORE_NSB_H_ */

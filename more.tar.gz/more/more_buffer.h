/*
 * more_buffer.h
 *
 *  Created on: 2014-11-12
 *      Author: winemocol
 */

#ifndef MORE_BUFFER_H_
#define MORE_BUFFER_H_
#include "more_rqueue.h"
class More_buffer
{
public:
	int indexOfCurrentNode;
	int indexOfdestinationNode;
	int indexOfSourceNode;
	int indexOfPort;

	int sourceSendingGroupIndex;
	int sourceSendingValueInGroupIndex;
	int destinationReceiveLatestSequence;
	int currentGroupIndexInDestination;
	int sourceLastestACKedSequence;
	int codeingPacketNumber;
	int sourceReceiveACKSequencArray[100];
	int sourceSendingQueueIndex[10][500];

	more_rqueue rqueue_0;
	more_rqueue rqueue_1;
	more_rqueue rqueue_2;
	more_rqueue rqueue_3;
	more_rqueue rqueue_4;
	more_rqueue rqueue_5;
	more_rqueue rqueue_6;
	more_rqueue rqueue_7;
	more_rqueue rqueue_8;
	more_rqueue rqueue_9;

	More_buffer();

	void initizeMoreBuffer();
	void initizeFlowNumber(int _indexOfCurrentNode,int _indexOfdestinationNode,int _indexOfSourceNode,int _indexOfPort);


	more_rqueue returnCurrentSendingQueueBySequence(int Sequence);
	more_rqueue returnCurrentSendingQueueByGroupIndex(int GroupIndex);
	void increaseSeuquenceAndGroupIndexInDestiantion();
	int returnCurrentSendingGroupIndexBySequence(int Sequence);
	void recoveSendingQueueByGroupIndexAndNewQueue(int GroupIndex,more_rqueue queue);
	void showQueueSize();
	more_rqueue returnCurrentSendingQueueByGroupIndexInDestination(int GroupIndex);
};

#endif /* MORE_BUFFER_H_ */

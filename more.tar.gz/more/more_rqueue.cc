/*
 * more_rqueue.cc
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */

#include <assert.h>
#include <cmu-trace.h>
#include <more/more_rqueue.h>
#include <iostream>
#define CURRENT_TIME    Scheduler::instance().clock()
#define QDEBUG

/*
  Packet Queue used by MORE.
*/
more_rqueue::more_rqueue()
{
	//std::cout << "========more_rqueue===more_rqueue================" << std::endl;
	head_ = tail_ = 0;
	len_ = 0;
	limit_ = MORE_MAX_LEN;
	timeout_ = MORE_MAX_TIME;
}

int
more_rqueue::lenghtofQueue()
{
	return len_;
}

void
more_rqueue::enque(Packet* p)//往queue里面添加一个包
{
	struct hdr_cmn *ch = HDR_CMN(p);

	//std::cout << "========more_rqueue===enque====1============" << len_<<::endl;

	//purge();//清除超时的那些包,已经在queue里面的那些超时的包

	//std::cout << "========more_rqueue===more_rqueue=====2===========" << len_<<::endl;
	p->next_ = 0;
	ch->ts_ = CURRENT_TIME + timeout_;
	if (len_ == limit_)
	{
		//std::cout << "========more_rqueue===enque====2============" << len_<<::endl;
		Packet *p_h = remove_head();//取处理一个包，并且减少len
		assert(p);//没有取处理的话给个警告
		if(HDR_CMN(p_h)->ts_ > CURRENT_TIME)
		{
			drop(p_h, DROP_RTR_QFULL);
		}
		else
		{
			drop(p_h, DROP_RTR_QTIMEOUT);
		}
	}
	if(head_ == 0)
	{//std::cout << "========more_rqueue===enque====3============" << len_<<::endl;
		head_ = tail_ = p;
	}
	else
	{//std::cout << "========more_rqueue===enque====4============" << len_<<::endl;
	   tail_->next_ = p;
	   tail_ = p;
	 }
	//std::cout << "========more_rqueue===more_rqueue=========3=======" << len_<<::endl;
	len_++;
	//std::cout << "========more_rqueue===enque====5============" << len_<<::endl;
//#ifdef QDEBUG
//   verifyQueue();
//#endif // QDEBUG
}

Packet*
more_rqueue::deque()//取出queue里面的head的第一个包
{
//	std::cout << "========more_rqueue===deque=========3=======" << len_<<::endl;
	Packet *p;
	//purge();

//	if( head_ == NULL)
//	{
//		std::cout << "========more_rqueue===deque=========3====cuo le= kong==" << len_<<::endl;
//	}
//	else
//	{
//		std::cout << "========more_rqueue===deque=========3==bu kong==dui le===" << len_<<::endl;
//	}


	p = remove_head();
	//std::cout << "========more_rqueue===deque=========3=======" << len_<<::endl;
#ifdef QDEBUG
	verifyQueue();
#endif // QDEBUG
	return p;
}

Packet*
more_rqueue::getdeque(void)
{
	Packet *p;
	//purge();
	p = get_head();

#ifdef QDEBUG
	verifyQueue();
#endif // QDEBUG
	return p;

}

Packet*
more_rqueue::deque(nsaddr_t dst)
{
	Packet *p, *prev;
	//purge();
	findPacketWithDst(dst,p,prev);
	assert(p == 0 || (p == head_ && prev == 0) || (prev->next_ == p));
	if(p ==0) return 0;
	if (p == head_)
	{
		p = remove_head();
	}
	else if (p == tail_)
	{
		prev->next_ = 0;
		tail_ = prev;
		len_--;
	 }
	else
	{
		prev->next_ = p->next_;
		len_--;
	}
#ifdef QDEBUG
 verifyQueue();
#endif // QDEBUG
 return p;
}

char
more_rqueue::find(nsaddr_t dst)
{
	Packet *p;
	Packet *prev;
	findPacketWithDst(dst,p,prev);
	if(p == 0) return 0;
	else return 1;
}


Packet*
more_rqueue::get_head()
{
	Packet *p = head_;
	return p;
}


Packet*
more_rqueue::get_tail()
{
	Packet *p = tail_;
	return p;
}


//priviate functions:

Packet*
more_rqueue::remove_head()
{
	//std::cout << "========more_rqueue===remove_head=========3=======" << len_<<::endl;
	Packet *p = head_;
	if(head_ == tail_)
	{
		//std::cout << "========more_rqueue===remove_head=========3===if====" << len_<<::endl;
		head_ = tail_ =0;
	}
	else
	{


		head_ = head_->next_;
	}

	if(p) len_--;
	return p;
}


void
more_rqueue::remove_all_packet()
{
	//printf("the begin length of queue is %d\n",len_);
	if(len_ > 0)
	{

		if(head_ == tail_)
		{
			//printf("the only one packet in queue is %d\n",len_);
			Packet *p = head_;
			len_--;
			head_ = tail_ = 0;
			Packet::free(p);
		}
		else
		{
			int lengthofqueue = len_;
			for(int i=0;i<lengthofqueue;i++)
			{
				Packet *p = head_;
				head_ = head_->next_;
				len_--;
				Packet::free(p);
			}
			head_ = tail_ = 0;
		}
	}
	//printf("the end length of queue is %d\n",len_);
	//len_ = 0;
}




void
more_rqueue::findPacketWithDst(nsaddr_t dst, Packet*&p, Packet*& prev)
{
	p = prev = 0;
	for(p = head_; p; p = p->next_)
	{
		if(HDR_IP(p)->daddr() == dst) return;
	}
	prev = p;
}

void
more_rqueue::verifyQueue()
{
	Packet *p, *prev = 0;
	int cnt = 0;
	for(p = head_; p; p = p->next_)
	{
		cnt++;
		prev = p;
	}
	assert( cnt == len_);
	assert( prev == tail_);
}

bool
more_rqueue::findAgedPacket(Packet*& p, Packet*& prev)
{
	p = prev = 0;
	for(p = head_; p; p =p->next_)
	{
		if(HDR_CMN(p)->ts_ < CURRENT_TIME) return true;
		prev = p;
	}
	return false;
}

void
more_rqueue::purge()
{
	Packet *p, *prev;
	while(findAgedPacket(p,prev))
	{
		assert(p == 0 || (p == head_ && prev == 0) || (prev->next_ == p));
		if(p == 0) return;
		if(p == head_) p = remove_head();
		else if ( p == tail_)
		{
			prev->next_ = 0;
			tail_ = prev;
			len_ --;
		}
		else
		{
			prev->next_ = p->next_;
			len_--;
		}
#ifdef QDEBUG
 	verifyQueue();
#endif // QDEBUG
 		p = prev = 0;
	}
}

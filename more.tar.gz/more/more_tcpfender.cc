/*
 * more.cc
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */
#include "more.h"
#include "more_loss.h"
#include "more_pkt.h"
#include <packet.h>
#include <random.h>
#include <cmu-trace.h>
#include <iostream>
#include <stdio.h>
#include <sys/time.h>
#include <random.h>
#define CURRENT_TIME    Scheduler::instance().clock()
int hdr_more_pkt::offset_;

static class MoreHeaderClass : public PacketHeaderClass {
public:

	MoreHeaderClass():PacketHeaderClass("PacketHeader/More",sizeof(hdr_all_more))
	{
		bind_offset(&hdr_more_pkt::offset_);
	}
}class_rtProtoMore_hdr;

static class MoreClass : public TclClass{

public:

	MoreClass():TclClass("Agent/More"){}

	TclObject* create(int argc, const char*const* argv){
		assert(argc ==5);
		return (new More((nsaddr_t) Address ::instance().str2addr(argv[4])));
	}

}class_rtProtoMore;

int
More::command(int argc, const char*const *argv)
{

	if(argc ==2 )
	{
	    if(strcasecmp(argv[1],"start") == 0)
	    {
		return TCL_OK;
	    }
	}
	else if (strcasecmp(argv[1],"print_rtable") == 0)
	{
	    if(logtarget_ != 0)
	    {
		sprintf(logtarget_->pt_->buffer(), "P %f _%d_ Routing Table", CURRENT_TIME, ra_addr());

		logtarget_->pt_->dump();

		rtable_.print(logtarget_);
	    }
	    else{

                    fprintf(stdout, "%f _%d_ If you want to print this routing table "

                    "you must create a trace file in your tcl script", CURRENT_TIME, ra_addr());

		}

	    return TCL_OK;
	}
	else if (argc ==3)
	{
		//Obtatins corresponding dumx to carry packets to upper layers
		if(strcmp(argv[1], "port-dmux") == 0){
            dmux_ = (PortClassifier*)TclObject::lookup(argv[2]);

                  if (dmux_ == 0) {

                      fprintf(stderr, "%s: %s lookup of %s failed\n", __FILE__, argv[1], argv[2]);
                      return TCL_ERROR;
                  }

                  return TCL_OK;
		}

        // Obtains corresponding tracer

        else if (strcmp(argv[1], "log-target") == 0 || strcmp(argv[1], "tracetarget") == 0) {

               logtarget_ = (Trace*)TclObject::lookup(argv[2]);
               if (logtarget_ == 0)return TCL_ERROR;
               return TCL_OK;

        }

        else if(strcmp(argv[1], "drop-target") == 0) {
        int stat = SR_Q.command(argc,argv);
        if (stat != TCL_OK) return stat;
        return Agent::command(argc, argv);
        }

        else if (strcmp(argv[1], "install-tap") == 0) {
        	mac_ = (Mac*)TclObject::lookup(argv[2]);
        	if (mac_ == 0) return TCL_ERROR;
        	mac_->installTap(this);
        	return TCL_OK;
        }
	}
    // Pass the command to the base class

    return Agent::command(argc, argv);
}

void
More::tap(const Packet *p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);

	printf("index==%d---",index);
	printf("type==%d---",ch->ptype_);
	printf("address=dis=%d---",ih->daddr());
	printf("address=sour=%d---",ih->saddr());
	printf("do something here\n");

	if(ch->ptype_ == 5 && ch->prev_hop_ > index && ch->next_hop_ != index)
	{
		printf("do something here 2\n");
		//intermediates_overhear_ACKPackets(p);
		//resetOverhearHighPriorityTimer(p,index);
	}

	//fprintf(stdout,"Node in Promiscuous Mode");
}

More::More(nsaddr_t id) : Agent(PT_MORE),SR_Q(),rqueue_0(),rqueue_1(),
			rqueue_2(),rqueue_3(),rqueue_4(),rqueue_5(),rqueue_6(),
			rqueue_7(),rqueue_8(),rqueue_9(),squeue_0(),squeue_1(),
			squeue_2(),squeue_3(),squeue_4(),squeue_5(),squeue_6(),
			squeue_7(),squeue_8(),squeue_9(),
			wrNewfTimer(this),wrAckTimer(this),wHighpsTimer(this),
			destionACKTimer(this){

	bind_bool("accessible_var_",&accessible_var_);
	ra_addr_= id;
	index = id;
//TCPFender variable --begin
	sendingOrWaitingIndex = 0;
	newpacketRound = 0;
	source_index = 0 ;
	destination_index = 5;
	op.destinationIndex = 5;
	codeingPacketNumber = 10;
	totalNumberOfGroup = 10;

	sourceSendPacketMAXSequence = 0;
	sourceReceivedPacketMAXQueueIndex = 0;
	destinationReceivedPacketMAXSequence = 0;
	destinationReceivedMaxQueueIndex = 0;
	receiveNewPacketTimer = 0;
	highPriorityNodesTimer = 0;
	NotSendingPacket = 0;
	sourceReceivedMAXACKSequence = -1;
	packetretransmissionIndex = 0;
//test correct index;


	onePacketSendingDelay = 0.006;
	//some idea about automatic update this parameter, for example: it delay when it detect other transmission
	// it detect the available bandiwidht,and set a best transmission time for itself.



	backoffpacketNum = 2;

    sendingTestCorrect = 0;
    recevingTestCorrect = 0;

	for(int i=0;i<10;i++)
	{
	    unAckedPackeNumberInQueue[i] = 0;

	    temporaryUnAckedPacketNumberInQueue[i] = 0;
	    temporaryUnAckedPacketNumberInFirQueue[i] = 0;
	    temporaryUnAckedPacketNumberInSecQueue[i] = 0;
	    temporaryUnAckedPacketNumberInThirQueue[i] = 0;


	    receivedNewPacketNumberInQueue[i]=0;
	    receivedPackeNumberInQueue[i] = 0;
	    requiredSendingPackeNumberInQueue[i] = 0;
	    finishedACKNumInQueue[i] = 0;
	    sendinPacketRoundIndex[i] = 0;
	    ACkedNumInQueue[i] =0;
	    //currentRoundValueInQueue[i] = 0;
	}
	temporaryUnAckedPacketNumberInFirQueue[10] = 0;
	temporaryUnAckedPacketNumberInSecQueue[10] = 0;
	temporaryUnAckedPacketNumberInThirQueue[10] = 0;
//TCPFender variable --end
}

void
More::recv(Packet* p, Handler*h)
{
    //printf("the receving method has been called\n");

//    for(int i =1;i<1000;i++)
//	{
//	    int maxPacketNumber = codeingPacketNumber*totalNumberOfGroup;
//	    int remainder = i % maxPacketNumber;
//	    printf("remainder===%d\n",remainder);
//	}

	struct hdr_cmn* ch = HDR_CMN(p);


//	for(int i=0;i<=5;i++)
//	{
//		ch->prev_hop_ = i;
//		for(int j=0; j<=5;j++)
//		{
//			int backoff = op.getBackoffTime(p,j);
//			int sce = op.getScheduleBackoffTime(p,j);
//			printf("the backoff sender =%d, receiver =%d===%d ----%d\n",ch->prev_hop_,j,backoff,sce);
//		}
//	}

//	if(ch->ptype_ == PT_TCP && index == 0)
//	{
//		traditionalSendPacket(p);
//	}
//	else if(ch->ptype_ == PT_TCP && ch->prev_hop_ < index )
//	{
//		traditionalSendPacket(p);
//	}
//	else if(ch->ptype_ == PT_ACK && index == 5)
//	{
//		traditionalReceiveACK(p);
//	}
//	else if(ch->ptype_ == PT_ACK && ch->prev_hop_ > index)
//	{
//		traditionalReceiveACK(p);
//	}
//	return;



    TCPFender_flow(p);
}



void
More::traditionalSendPacket(Packet* p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);
	hdr_tcp *tcph = hdr_tcp::access(p);
	ch->size() = 572;
	ch->addr_type() = NS_AF_INET;
	ih->daddr() = 5;
	ih->sport() = 0;
	ih->dport() = 0;
	ih->ttl() = ih->ttl()-1;
	ch->direction() = hdr_cmn::DOWN;
	if(index == 0)
	{
		printf("coming0\n");
		ch->next_hop_ = 1;
		ch->prev_hop_ = 0;
	}
	else if (index == 1)
	{
		printf("coming3\n");
		ch->next_hop_ = 2;
		ch->prev_hop_ = 1;
	}
	else if (index == 2)
	{
		ch->next_hop_ = 3;
		ch->prev_hop_ = 2;
	}
	else if (index == 3)
	{
		ch->next_hop_ = 4;
		ch->prev_hop_ = 3;
	}
	else if (index == 4)
	{
		ch->next_hop_ = 5;
		ch->prev_hop_ = 4;
	}
	else
	{
		Packet::free(p);
		return;
	}

	Scheduler::instance().schedule(target_, p,NO_DELAY);
}

void
More::traditionalReceiveACK(Packet* p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);
	hdr_tcp *tcph = hdr_tcp::access(p);
	ch->addr_type() = NS_AF_INET;
	ih->daddr() = 0;
	ih->sport() = 0;
	ih->dport() = 0;
	ih->ttl() = ih->ttl()-1;
	ch->direction() = hdr_cmn::DOWN;
	if(index == 5)
	{
		ch->next_hop_ = 4;
		ch->prev_hop_ = 5;
	}
	else if (index == 4)
	{
		ch->next_hop_ = 3;
		ch->prev_hop_ = 4;
	}
	else if (index == 3)
	{
		ch->next_hop_ = 2;
		ch->prev_hop_ = 3;
	}
	else if (index == 2)
	{
		ch->next_hop_ = 1;
		ch->prev_hop_ = 2;
	}
	else if (index == 1)
	{
		ch->next_hop_ = 0;
		ch->prev_hop_ = 1;
	}
	else
	{
		//Packet::free(p);
		return;
	}

	Scheduler::instance().schedule(target_, p,NO_DELAY);
}

void
More::TCPFender_flow(Packet* p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);
	hdr_tcp *tcph = hdr_tcp::access(p);
	ns_addr_t desti = ih->dst_;
	ns_addr_t source= ih->src_;

    if (ih->saddr() == ra_addr()) {
	// If there exists a loop, must drop the packet
       if (ch->num_forwards() > 0)
       {
    	   drop(p, DROP_RTR_ROUTE_LOOP);
    	   return;
       }
    // else if this is a packet I am originating, must add IP header
       else if (ch->num_forwards() == 0)
       {
    	   ch->size() += IP_HDR_LEN;
       }
    }

    printf("TCPFender_flow---------------   ----------   ---------- "
    		" ----------  ------------  ---------  ------------  ---------\n");
    printf("a node receive packets with uid=%d, index=%d, destination port=%d,source port=%d,"
	    "\n",ch->uid_,index,desti.port_,source.port_);
    printf("TCP packet----sequence-%d---packet type-%d--------from %d------------uid=%d--"
	    "------------\n",tcph->seqno(),ch->ptype_,ch->prev_hop_,ch->uid_);

//    if(ch->ptype_ == 0 && index == 2) return;
//     if(ch->ptype_ == 1 && index == 2) return;
//     if(ch->ptype_ == 4 && index == 2) return;
//    if(ch->ptype_ == 0 && index == 1) return;
//    if(ch->ptype_ == 0 && index == 2) return;
//    if(ch->ptype_ == 0 && index == 4) return;h

    int state = op.checkstate(p,index);

    switch (state)
    {
    	case 0:
    		source_receive_dataPackets(p);
    		break;
    	case 1:
    		source_receive_downstream_dataPackets(p);
    		break;
    	case 2:
    		destination_receive_dataPackets(p);
    		break;
    	case 3:
    		intermediates_receive_dataPackets(p);
    		break;
    	case 4:
    		intermediates_receive_downstream_dataPackets(p);
    		break;
    	case 5:
    		source_receive_ACKPackets(p);
    		break;
    	case 6:
    		intermediates_receive_ACKPackets(p);
    		break;
    }
}

//void
//More::TCPFender_flow(Packet* p)
//{
//    struct hdr_cmn* ch = HDR_CMN(p);
//    struct hdr_ip* ih = HDR_IP(p);
//    hdr_tcp *tcph = hdr_tcp::access(p);
//    ns_addr_t desti = ih->dst_;
//    ns_addr_t source= ih->src_;
//
//    if (ih->saddr() == ra_addr()) {
//	// If there exists a loop, must drop the packet
//       if (ch->num_forwards() > 0)
//       {
//    	   drop(p, DROP_RTR_ROUTE_LOOP);
//    	   return;
//       }
//       // else if this is a packet I am originating, must add IP header
//       else if (ch->num_forwards() == 0)
//       {
//    	   ch->size() += IP_HDR_LEN;
//       }
//    }
//
//    printf("TCPFender_flow---------------   ----------   ---------- "
//    		" ----------  ------------  ---------  ------------  ---------\n");
//    printf("a node receive packets with uid=%d, index=%d, destination port=%d,source port=%d,"
//	    "\n",ch->uid_,index,desti.port_,source.port_);
//    printf("TCP packet----sequence-%d---packet type-%d--------from %d------------uid=%d--"
//	    "------------\n",tcph->seqno(),ch->ptype_,ch->prev_hop_,ch->uid_);
//
//    switch (ch->ptype_)
//    {
//		case PT_TCP:
//
//	    if(index == source_index&& ch->prev_hop_ == 0)
//	    {
//	    	source_receive_dataPackets(p);
//	    }
//	    else if(index == source_index&& ch->prev_hop_ > 0)
//	    {
//	    	source_receive_downstream_dataPackets(p);
//	    }
//	    else if (index == destination_index)
//	    {
//	    	destination_receive_dataPackets(p);
//	    }
//	    else
//	    {
//	    	if(ch->prev_hop_ < index)
//	    	{
//		    	intermediates_receive_dataPackets(p);
//	    	}
//	    	else if(ch->prev_hop_ > index)
//	    	{
//	    		//intermediates_receive_downstream_dataPackets(p);
//	    	}
//	    	else
//	    	{
//	    		printf("nodes receive themselves packets\n");
//	    	}
//	    }
//
//	    break;
//
//	case PT_ACK:
//
//	    if(index == source_index)
//	    {
//	    	source_receive_ACKPackets(p);
//	    }
//	    else if (index == destination_index){
//
//	    }
//	    else
//	    {
//	    	intermediates_receive_ACKPackets(p);
//	    }
//
//	    break;
//
//	default:
//		printf("TCPFender_flow------packet type error------------------------------"
//		"----------------------\n");
//	    break;
//    }
//}

void
More::source_receive_dataPackets(Packet* p)
{
    hdr_tcp *pre_tcph = hdr_tcp::access(p);
    int pre_sequ = pre_tcph->seqno();
    if(sourceSendPacketMAXSequence <= pre_sequ)
    {
    	printf("source receive new data packet\n");
    	source_receive_new_dataPackets(p);
    }
    else
    {
    	printf("source receive old data packet\n");
    	source_receive_retransmitted_dataPackets(p);
    }
}

void
More::source_receive_new_dataPackets(Packet* p)
{
	printf("<-----############------>source_");
	printf("index ==%d begin receive_new_dataPackets<------############------>\n",index);
	packetretransmissionIndex = 0;



    sendingTestCorrect = 1;
    if(recevingTestCorrect == 1)
    	printf("index ==%d error synchronize, send packet while receiving \n",index);

    resetNewPacketTimer();
    hdr_tcp *tcph = hdr_tcp::access(p);
// the position of the following function cann't sweap;
    updateRoundInforForEachQueue(tcph->seqno());

    updateTheUnAckedPacketsInQueue(p);


    more_rqueue rqueue = getCurrentReceiveQueueBySequence(tcph->seqno());




    Packet* codedPacket = source_generate_codedPackets(p,sourceSendPacketMAXSequence);
    Packet* packet_backoff = codedPacket->copy();
    Packet::free(codedPacket);
    sourceSendPacketMAXSequence++;
    printf("source_receive_new_dataPackets -- ---- \n");
    printPacketContent(packet_backoff);
    rqueue.enque(packet_backoff);
    hdr_tcp *tcph_coded = hdr_tcp::access(packet_backoff);
    saveReceivingQueueInLocalByQueueSequence(tcph_coded->seqno(),rqueue);

    sendingTestCorrect = 0;
	printf("<-----############------>source_");
	printf("index ==%d   end receive_new_dataPackets<------############------>\n",index);
}

void
More::source_send_newDataPacket()
{
	printf("<-----@@@@@@@@@@@@------>source_");
	printf("index ==%d begin source_send_newDataPacket<------@@@@@@@@@@@@------>\n",index);

	recevingTestCorrect = 1;
    if(sendingTestCorrect == 1)
    	printf("index ==%d error synchronize, receiving packet while sending \n",index);

    int cumNum = 0;
    for(int i=0;i<totalNumberOfGroup;i++)
    {
		if(receivedNewPacketNumberInQueue[i]>0)
		{
			cumNum = cumNum+receivedNewPacketNumberInQueue[i];
		}
    }
    printf("cum=new==%d\n",cumNum);
    int total = cumNum;
    for(int i=0;i<totalNumberOfGroup;i++)
    {
	// check whether it needs to send packets
    	printf("totalNumberOfGroup===========%d\n",i);

		if(receivedNewPacketNumberInQueue[i]>0)
		{
			more_rqueue rqueue = getCurrentReceiveQueueIndex(i);
			//temporaryUnAckedPacketNumberInQueue[i] = rqueue.lenghtofQueue();
			printf("rqueue length = %d\n",rqueue.lenghtofQueue());
			for(int z=0;z<receivedNewPacketNumberInQueue[i];z++)
			{
				printf("requiredSendingPackeNumberInQueue at-%d for total=%d> 0\n",i,
						receivedNewPacketNumberInQueue[i]);

				Packet* codedPacket = generateCodedPacketBasedOnSendingQueue(rqueue);
				Packet* sendingPacket = source_configure_dataPackets(codedPacket);

				struct hdr_more_pkt* ph = HDR_MORE_PKT(sendingPacket);
				hdr_tcp *tcph = hdr_tcp::access(sendingPacket);
				tcph->reason_ = cumNum;
				ph->pkt_batch_num_ = i;
				ph->newPacketIndex_ = newpacketRound;
				ph->cur_wait_num = cumNum;
				cumNum--;
				tcph->seqno_ = sendinPacketRoundIndex[i]*100+i*10+
						rqueue.lenghtofQueue()-receivedNewPacketNumberInQueue[i]+z;
				ph->pkt_round() = sendinPacketRoundIndex[i];
				printf("source_send_dataPackets  inner at %d\n",z);

				printPacketContent(sendingPacket);
				Scheduler::instance().schedule(target_, sendingPacket,NO_DELAY);
			}

			unAckedPackeNumberInQueue[i] = unAckedPackeNumberInQueue[i]+
					receivedNewPacketNumberInQueue[i];
			receivedNewPacketNumberInQueue[i] = 0;

		}
	}
    newpacketRound ++;
    recevingTestCorrect = 0;
// after sending packet for one round, make sure that it need sometimes
    //to wait for downstream node receives packets;
    if(total >0)resetSendTimer();
    //resetDestinationACKTimer();
	printf("<-----@@@@@@@@@@@@------>source_");
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}

void
More::source_send_dataPackets()
{
	printf("<-----@@@@@@@@@@@@------>source_");
	printf("index ==%d begin send_dataPackets<------@@@@@@@@@@@@------>\n",index);


 	 for(int i=0;i<totalNumberOfGroup;i++)
 	 {
 		updateTheUnAckedPacketsByIndex(i);
 	 }


     int cumNum = 0;
     for(int i=0;i<totalNumberOfGroup;i++)
     {
 		if(requiredSendingPackeNumberInQueue[i]>0)
 		{
 			cumNum = cumNum+requiredSendingPackeNumberInQueue[i];
 		}
     }
     printf("cum===%d\n",cumNum);
     int total = cumNum;
	recevingTestCorrect = 1;
    if(sendingTestCorrect == 1)
    	printf("index ==%d error synchronize, receiving packet while sending \n",index);

    for(int i=0;i<totalNumberOfGroup;i++)
    {
	// check whether it needs to send packets
    	printf("totalNumberOfGroup===========%d\n",i);
    	printf("requiredSendingPackeNumberInQueue[%d]===========%d\n",i,
    			requiredSendingPackeNumberInQueue[i]);
		if(requiredSendingPackeNumberInQueue[i]>0)
		{
			more_rqueue rqueue = getCurrentReceiveQueueIndex(i);
			//temporaryUnAckedPacketNumberInQueue[i] = rqueue.lenghtofQueue();

			for(int z=0;z<requiredSendingPackeNumberInQueue[i];z++)
			{
				printf("requiredSendingPackeNumberInQueue > 0\n");
				Packet* codedPacket = generateCodedPacketBasedOnSendingQueue(rqueue);
				Packet* sendingPacket = source_configure_dataPackets(codedPacket);

				struct hdr_more_pkt* ph = HDR_MORE_PKT(sendingPacket);
				hdr_tcp *tcph = hdr_tcp::access(sendingPacket);
				tcph->reason_ = cumNum;
				ph->pkt_batch_num_ = i;
				ph->newPacketIndex_ = newpacketRound;
				ph->cur_wait_num = cumNum;
				cumNum--;
				tcph->seqno_ = sendinPacketRoundIndex[i]*100+i*10+
						rqueue.lenghtofQueue()-requiredSendingPackeNumberInQueue[i]+z;
				ph->pkt_round() = sendinPacketRoundIndex[i];
				printf("source_send_dataPackets  inner at %d\n",z);

				printPacketContent(sendingPacket);
				Scheduler::instance().schedule(target_, sendingPacket,NO_DELAY);
			}
		}
	}
    recevingTestCorrect = 0;
// after sending packet for one round, make sure that it need sometimes
    //to wait for downstream node receives packets;
    if(total >0)resetSendTimer();
	printf("<-----@@@@@@@@@@@@------>source_");
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}

void
More::source_receive_retransmitted_dataPackets(Packet* p)
{
	resetNewPacketTimer();

	//packetretransmissionIndex = 1;
    hdr_tcp *tcph = hdr_tcp::access(p);
    more_rqueue rqueue = getCurrentReceiveQueueBySequence(tcph->seqno());
    int sequence = tcph->seqno();

    int maxPacketNumber = codeingPacketNumber*totalNumberOfGroup;
    int remainder = sequence % maxPacketNumber;

    if(codeingPacketNumber*0<=remainder && remainder< codeingPacketNumber*1)
    {
    	receivedNewPacketNumberInQueue[0]++;
    	//requiredSendingPackeNumberInQueue[0]++;
    }
    else if(codeingPacketNumber*1<=remainder && remainder<codeingPacketNumber*2)
    {
    	receivedNewPacketNumberInQueue[1]++;
    	//requiredSendingPackeNumberInQueue[1]++;
    }
    else if(codeingPacketNumber*2<=remainder && remainder<codeingPacketNumber*3)
    {
    	receivedNewPacketNumberInQueue[2]++;
    	//requiredSendingPackeNumberInQueue[2]++;
    }
    else if(codeingPacketNumber*3<=remainder && remainder<codeingPacketNumber*4)
    {
    	receivedNewPacketNumberInQueue[3]++;
    	//requiredSendingPackeNumberInQueue[3]++;
    }
    else if(codeingPacketNumber*4<=remainder && remainder<codeingPacketNumber*5)
    {
    	receivedNewPacketNumberInQueue[4]++;
    	//requiredSendingPackeNumberInQueue[4]++;
    }
    else if(codeingPacketNumber*5<=remainder && remainder<codeingPacketNumber*6)
    {
    	receivedNewPacketNumberInQueue[5]++;
    	//requiredSendingPackeNumberInQueue[5]++;
    }
    else if(codeingPacketNumber*6<=remainder && remainder<codeingPacketNumber*7)
    {
    	receivedNewPacketNumberInQueue[6]++;
    	//requiredSendingPackeNumberInQueue[6]++;
    }
    else if(codeingPacketNumber*7<=remainder && remainder<codeingPacketNumber*8)
    {
    	receivedNewPacketNumberInQueue[7]++;
    	//requiredSendingPackeNumberInQueue[7]++;
    }
    else if(codeingPacketNumber*8<=remainder && remainder<codeingPacketNumber*9)
    {
    	receivedNewPacketNumberInQueue[8]++;
    	//requiredSendingPackeNumberInQueue[8]++;
    }
    else if(codeingPacketNumber*9<=remainder && remainder<codeingPacketNumber*10)
    {
    	receivedNewPacketNumberInQueue[9]++;
    	//requiredSendingPackeNumberInQueue[9]++;
    }
    else
    {
    	receivedNewPacketNumberInQueue[0]++;
    	//requiredSendingPackeNumberInQueue[0]++;
    }
}

void
More::source_receive_downstream_dataPackets(Packet* p)
{
	printf("source_receive_downstream_dataPackets\n");
    source_checkDownstreamDataInformation(p);
    resetHighPriorityTimer(p,index);
}

void
More::source_receive_ACKPackets(Packet* p)
{
	source_checkACKInformation(p);
	source_ACKMechanism_duplicateACK(p);
    //source_ACKMechanism_simpleACK(p);
	resetHighPriorityTimer(p,index);
}

void
More::source_checkACKInformation(Packet* p)
{
	printf("source_checkACKInformation\n");
	struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

	if(sendinPacketRoundIndex[0] < ph->round_Batch_0)
	{
		sendinPacketRoundIndex[0] = ph->round_Batch_0;
		clearQueueByIndex(0);
//
//	   	receivedPackeNumberInQueue[0] = 0;
//	    requiredSendingPackeNumberInQueue[0] = 0;
//	    unAckedPackeNumberInQueue[0] = 0;

		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[0] == ph->round_Batch_0
			&&receivedPackeNumberInQueue[0] < ph->num_for_eachBatch_0)
	{
		receivedPackeNumberInQueue[0] = ph->num_for_eachBatch_0;
	}

	if(sendinPacketRoundIndex[1] < ph->round_Batch_1)
	{
		sendinPacketRoundIndex[1] = ph->round_Batch_1;
		clearQueueByIndex(1);
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[1] == ph->round_Batch_1
			&&receivedPackeNumberInQueue[1] < ph->num_for_eachBatch_1)
	{
		receivedPackeNumberInQueue[1] = ph->num_for_eachBatch_1;
	}

	if(sendinPacketRoundIndex[2] < ph->round_Batch_2)
	{
		sendinPacketRoundIndex[2] = ph->round_Batch_2;
		clearQueueByIndex(2);
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[2] == ph->round_Batch_2
			&&receivedPackeNumberInQueue[2] < ph->num_for_eachBatch_2)
	{
		receivedPackeNumberInQueue[2] = ph->num_for_eachBatch_2;
	}

	if(sendinPacketRoundIndex[3] < ph->round_Batch_3)
	{
		sendinPacketRoundIndex[3] = ph->round_Batch_3;
		clearQueueByIndex(3);
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[3] == ph->round_Batch_3
			&&receivedPackeNumberInQueue[3] < ph->num_for_eachBatch_3)
	{
		receivedPackeNumberInQueue[3] = ph->num_for_eachBatch_3;
	}

	if(sendinPacketRoundIndex[4] < ph->round_Batch_4)
	{
		sendinPacketRoundIndex[4] = ph->round_Batch_4;
		clearQueueByIndex(4);
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[4] == ph->round_Batch_4
			&&receivedPackeNumberInQueue[4] < ph->num_for_eachBatch_4)
	{
		receivedPackeNumberInQueue[4] = ph->num_for_eachBatch_4;
	}

	if(sendinPacketRoundIndex[5] < ph->round_Batch_5)
	{
		sendinPacketRoundIndex[5] = ph->round_Batch_5;
		clearQueueByIndex(5);
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[5] == ph->round_Batch_5
			&&receivedPackeNumberInQueue[5] < ph->num_for_eachBatch_5)
	{
		receivedPackeNumberInQueue[5] = ph->num_for_eachBatch_5;
	}

	if(sendinPacketRoundIndex[6] < ph->round_Batch_6)
	{
		sendinPacketRoundIndex[6] = ph->round_Batch_6;
		clearQueueByIndex(6);
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[6] == ph->round_Batch_6
			&&receivedPackeNumberInQueue[6] < ph->num_for_eachBatch_6)
	{
		receivedPackeNumberInQueue[6] = ph->num_for_eachBatch_6;
	}

	if(sendinPacketRoundIndex[7] < ph->round_Batch_7)
	{
		sendinPacketRoundIndex[7] = ph->round_Batch_7;
		clearQueueByIndex(7);
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[7] == ph->round_Batch_7
			&&receivedPackeNumberInQueue[7] < ph->num_for_eachBatch_7)
	{
		receivedPackeNumberInQueue[7] = ph->num_for_eachBatch_7;
	}

	if(sendinPacketRoundIndex[8] < ph->round_Batch_8)
	{
		sendinPacketRoundIndex[8] = ph->round_Batch_8;
		clearQueueByIndex(8);
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[8] == ph->round_Batch_8
			&&receivedPackeNumberInQueue[8] < ph->num_for_eachBatch_8)
	{
		receivedPackeNumberInQueue[8] = ph->num_for_eachBatch_8;
	}

	if(sendinPacketRoundIndex[9] < ph->round_Batch_9)
	{
		sendinPacketRoundIndex[9] = ph->round_Batch_9;
		clearQueueByIndex(9);
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[9] == ph->round_Batch_9
			&&receivedPackeNumberInQueue[9] < ph->num_for_eachBatch_9)
	{
		receivedPackeNumberInQueue[9] = ph->num_for_eachBatch_9;
	}

	updateRequiredSendingPacketsInQueue();

	printf("num_for_eachBatch_0 = %d\n",ph->num_for_eachBatch_0);
	printf("num_for_eachBatch_1 = %d\n",ph->num_for_eachBatch_1);
	printf("num_for_eachBatch_2 = %d\n",ph->num_for_eachBatch_2);
	printf("num_for_eachBatch_3 = %d\n",ph->num_for_eachBatch_3);
	printf("num_for_eachBatch_4 = %d\n",ph->num_for_eachBatch_4);
	printf("num_for_eachBatch_5 = %d\n",ph->num_for_eachBatch_5);
	printf("num_for_eachBatch_6 = %d\n",ph->num_for_eachBatch_6);
	printf("num_for_eachBatch_7 = %d\n",ph->num_for_eachBatch_7);
	printf("num_for_eachBatch_8 = %d\n",ph->num_for_eachBatch_8);
	printf("num_for_eachBatch_9 = %d\n",ph->num_for_eachBatch_9);
}

void
More::source_ACKMechanism_duplicateACK(Packet* p)
{
	printf("source_ACKMechanism_simpleACK ---"
			"sourceReceivedMAXACKSequence=%d\n",sourceReceivedMAXACKSequence);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

	int roundIndex = ph->pkt_round();
	int receivedNum = ph->num_for_currentBatch;
	int currentBatch = ph->current_batch_;

	printf("roundIndex ===== %d\n",roundIndex);
	printf("receivedNum ===== %d\n",receivedNum);
	printf("currentBatch ===== %d\n",currentBatch);
	printf("sendinPacketRoundIndex[currentBatch] ===== %d\n",sendinPacketRoundIndex[currentBatch]);
	printf("sourceReceivedPacketMAXQueueIndex ===== %d\n",sourceReceivedPacketMAXQueueIndex);
	printf("sourceReceivedMAXACKSequence ===== %d\n",sourceReceivedMAXACKSequence);
	printf("roundIndex*100+currentBatch*10+receivedNum-1 ===== %d\n",
			roundIndex*100+currentBatch*10+receivedNum-1);

	if(sendinPacketRoundIndex[currentBatch]==roundIndex &&
			sourceReceivedPacketMAXQueueIndex == currentBatch)
	{
		//receive current batch packets
		printf("finishedACKNumInQueue[currentBatch] = %d\n",finishedACKNumInQueue[currentBatch]);
		if(finishedACKNumInQueue[currentBatch]<receivedNum)
		{
			finishedACKNumInQueue[currentBatch] = receivedNum;
			printf(" if condition"
					"finishedACKNumInQueue[currentBatch] = %d\n",finishedACKNumInQueue[currentBatch]);
		}

		// make sure it is the first time that the current batch gets full rank.
		if(sourceReceivedMAXACKSequence < roundIndex*100+currentBatch*10+receivedNum-1)
		{
			if(receivedNum == 10)
			{
				int sequenceforack = roundIndex*100+currentBatch*10+receivedNum-1;
				int batchIndex = currentBatch+1;
				sourceReceivedPacketMAXQueueIndex++;

				printf("sendinPacketRoundIndex[batchIndex] ===== %d\n",
						sendinPacketRoundIndex[batchIndex]);
				if(batchIndex == 10 && (sendinPacketRoundIndex[0]
				>sendinPacketRoundIndex[currentBatch]))
					batchIndex = 0;

				while(finishedACKNumInQueue[batchIndex] == 10)
				{
					sequenceforack = sequenceforack + 10;
					sourceReceivedPacketMAXQueueIndex++;
					batchIndex++;
					if(batchIndex == 10 && (sendinPacketRoundIndex[0]
					>sendinPacketRoundIndex[currentBatch]))
						batchIndex = 0;
				}
				printf("finishedACKNumInQueue[batchIndex] ===== %d\n",
						finishedACKNumInQueue[batchIndex]);
				sequenceforack = sequenceforack+finishedACKNumInQueue[batchIndex];
				sourceReceivedMAXACKSequence = sequenceforack;
				printf("source_generate_ack======1=======%d\n",sourceReceivedMAXACKSequence);
				source_generate_ack(sourceReceivedMAXACKSequence);
			}
			else
			{
				sourceReceivedMAXACKSequence = roundIndex*100+currentBatch*10+receivedNum-1;
				printf("source_generate_ack=====2========%d\n",sourceReceivedMAXACKSequence);
				source_generate_ack(sourceReceivedMAXACKSequence);
			}
		}
	}
	else if (sendinPacketRoundIndex[currentBatch]==roundIndex &&
			currentBatch > sourceReceivedPacketMAXQueueIndex)
	{
		printf("finishedACKNumInQueue[currentBatch] ===== %d\n",
				finishedACKNumInQueue[currentBatch]);
		//sourceReceivedPacketMAXQueueIndex = currentBatch;
//		finishedACKNumInQueue[currentBatch] = receivedNum;
////		int sequenceforack = roundIndex*100+sourceReceivedPacketMAXQueueIndex*10+receivedNum-1;
////		sourceReceivedMAXACKSequence = sequenceforack;
//		source_generate_ack(sourceReceivedMAXACKSequence);

//		if(finishedACKNumInQueue[currentBatch]<receivedNum)
//		{
//			finishedACKNumInQueue[currentBatch]++;
//			printf("source_generate_ack=======3======%d\n",sourceReceivedMAXACKSequence);
//			source_generate_ack(sourceReceivedMAXACKSequence);
//		}
// receive next batch packets
		sourceReceivedPacketMAXQueueIndex = currentBatch;
		sourceReceivedMAXACKSequence = roundIndex*100+currentBatch*10+receivedNum-1;
						printf("source_generate_ack=====2========%d\n",sourceReceivedMAXACKSequence);
		source_generate_ack(sourceReceivedMAXACKSequence);
	}
	else if (sendinPacketRoundIndex[currentBatch] >
	sendinPacketRoundIndex[sourceReceivedPacketMAXQueueIndex] &&
			currentBatch < sourceReceivedPacketMAXQueueIndex)
	{
		printf("finishedACKNumInQueue[currentBatch] ===== %d\n",
				finishedACKNumInQueue[currentBatch]);
//		sourceReceivedPacketMAXQueueIndex = currentBatch;
//		finishedACKNumInQueue[currentBatch] = receivedNum;
////		int sequenceforack = roundIndex*100+currentBatch*10+receivedNum-1;
////		sourceReceivedMAXACKSequence = sequenceforack;
//		source_generate_ack(sourceReceivedMAXACKSequence);

		sourceReceivedPacketMAXQueueIndex = currentBatch;
		sourceReceivedMAXACKSequence = roundIndex*100+currentBatch*10+receivedNum-1;
						printf("source_generate_ack=====3========%d\n",sourceReceivedMAXACKSequence);
		source_generate_ack(sourceReceivedMAXACKSequence);

		// receive next batch packets
	}
	else
	{
		printf("drop old packets\n");
	}

}

void
More::source_ACKMechanism_simpleACK(Packet* p)
{
    // the increase of current batch--> send ACK
    // the increase of next batch ---> send duplicated ACK

	printf("source_ACKMechanism_simpleACK ---"
			"sourceReceivedMAXACKSequence=%d\n",sourceReceivedMAXACKSequence);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

	int roundIndex = ph->pkt_round();
	int receivedNum = ph->num_for_currentBatch;
	int currentBatch = ph->current_batch_;

	printf("roundIndex ===== %d\n",roundIndex);
	printf("receivedNum ===== %d\n",receivedNum);
	printf("currentBatch ===== %d\n",currentBatch);
	printf("sendinPacketRoundIndex[currentBatch] ===== %d\n",sendinPacketRoundIndex[currentBatch]);
	printf("sourceReceivedPacketMAXQueueIndex ===== %d\n",sourceReceivedPacketMAXQueueIndex);
	printf("sourceReceivedMAXACKSequence ===== %d\n",sourceReceivedMAXACKSequence);
	printf("roundIndex*100+currentBatch*10+receivedNum-1 ===== %d\n",
			roundIndex*100+currentBatch*10+receivedNum-1);

	if(sendinPacketRoundIndex[currentBatch]==roundIndex &&
			sourceReceivedPacketMAXQueueIndex == currentBatch)
	{
		//receive current batch packets
		printf("finishedACKNumInQueue[currentBatch] = %d\n",finishedACKNumInQueue[currentBatch]);
		if(finishedACKNumInQueue[currentBatch]<receivedNum)
		{
			finishedACKNumInQueue[currentBatch]++;
			printf(" if condition"
					"finishedACKNumInQueue[currentBatch] = %d\n",finishedACKNumInQueue[currentBatch]);
		}

		// make sure it is the first time that the current batch gets full rank.
		if(sourceReceivedMAXACKSequence < roundIndex*100+currentBatch*10+receivedNum-1)
		{
			if(receivedNum == 10)
			{
				int sequenceforack = roundIndex*100+currentBatch*10+receivedNum-1;
				int batchIndex = currentBatch+1;
				sourceReceivedPacketMAXQueueIndex++;

				printf("sendinPacketRoundIndex[batchIndex] ===== %d\n",
						sendinPacketRoundIndex[batchIndex]);
				if(batchIndex == 10 && (sendinPacketRoundIndex[batchIndex]
				>sendinPacketRoundIndex[currentBatch]))
					batchIndex = 0;

				while(finishedACKNumInQueue[batchIndex] == 10)
				{
					sequenceforack = sequenceforack + 10;
					sourceReceivedPacketMAXQueueIndex++;
					batchIndex++;
					if(batchIndex == 10 && (sendinPacketRoundIndex[batchIndex]
					>sendinPacketRoundIndex[currentBatch]))
						batchIndex = 0;
				}
				printf("finishedACKNumInQueue[batchIndex] ===== %d\n",
						finishedACKNumInQueue[batchIndex]);
				sequenceforack = sequenceforack+finishedACKNumInQueue[batchIndex];
				sourceReceivedMAXACKSequence = sequenceforack;
				printf("source_generate_ack======1=======%d\n",sourceReceivedMAXACKSequence);
				source_generate_ack(sourceReceivedMAXACKSequence);
			}
			else
			{
				sourceReceivedMAXACKSequence = roundIndex*100+currentBatch*10+receivedNum-1;
				printf("source_generate_ack=====2========%d\n",sourceReceivedMAXACKSequence);
				source_generate_ack(sourceReceivedMAXACKSequence);
			}
		}
	}
	else if (sendinPacketRoundIndex[currentBatch]==roundIndex &&
			currentBatch > sourceReceivedPacketMAXQueueIndex)
	{
		printf("finishedACKNumInQueue[currentBatch] ===== %d\n",
				finishedACKNumInQueue[currentBatch]);
		if(finishedACKNumInQueue[currentBatch]<receivedNum)
		{
			finishedACKNumInQueue[currentBatch]++;
			printf("source_generate_ack=======3======%d\n",sourceReceivedMAXACKSequence);
			source_generate_ack(sourceReceivedMAXACKSequence);
		}
//		sourceReceivedPacketMAXQueueIndex = currentBatch;
//		sourceReceivedMAXACKSequence = roundIndex*100+currentBatch*10+receivedNum-1;
//					printf("source_generate_ack=====2========%d\n",sourceReceivedMAXACKSequence);
//		source_generate_ack(sourceReceivedMAXACKSequence);
		// receive next batch packets
	}
	else if (sendinPacketRoundIndex[currentBatch] >
	sendinPacketRoundIndex[sourceReceivedPacketMAXQueueIndex] &&
			currentBatch < sourceReceivedPacketMAXQueueIndex)
	{
		if(finishedACKNumInQueue[currentBatch]<receivedNum)
		{
			finishedACKNumInQueue[currentBatch]++;
			printf("source_generate_ack======4=======%d\n",sourceReceivedMAXACKSequence);
			source_generate_ack(sourceReceivedMAXACKSequence);
		}
		// receive next batch packets
	}
	else
	{
		printf("drop old packets\n");
	}
}

void
More::source_checkDownstreamDataInformation(Packet* p)
{
	printf("source_checkDownstreamDataInformation\n");

	struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
	printf("num_for_eachBatch_0 = %d\n",ph->num_for_eachBatch_0);
	printf("num_for_eachBatch_1 = %d\n",ph->num_for_eachBatch_1);
	printf("num_for_eachBatch_2 = %d\n",ph->num_for_eachBatch_2);
	printf("num_for_eachBatch_3 = %d\n",ph->num_for_eachBatch_3);
	printf("num_for_eachBatch_4 = %d\n",ph->num_for_eachBatch_4);
	printf("num_for_eachBatch_5 = %d\n",ph->num_for_eachBatch_5);
	printf("num_for_eachBatch_6 = %d\n",ph->num_for_eachBatch_6);
	printf("num_for_eachBatch_7 = %d\n",ph->num_for_eachBatch_7);
	printf("num_for_eachBatch_8 = %d\n",ph->num_for_eachBatch_8);
	printf("num_for_eachBatch_9 = %d\n",ph->num_for_eachBatch_9);


	printf("unAckedPackeNumberInQueue[0] ==%d ---\n",
				unAckedPackeNumberInQueue[0]);

	if(sendinPacketRoundIndex[0] < ph->round_Batch_0)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[0] == ph->round_Batch_0
			&&receivedPackeNumberInQueue[0] < ph->num_for_eachBatch_0)
	{
		printf("receivedPackeNumberInQueue[0]==%d\n",receivedPackeNumberInQueue[0]);
		receivedPackeNumberInQueue[0] = ph->num_for_eachBatch_0;
	}
	else{
		printf("receivedPackeNumberInQueue[0]==%d\n",receivedPackeNumberInQueue[0]);
		printf("source node  error\n");
	}

	if(sendinPacketRoundIndex[1] < ph->round_Batch_1)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[1] == ph->round_Batch_1
			&&receivedPackeNumberInQueue[1] < ph->num_for_eachBatch_1)
	{
		receivedPackeNumberInQueue[1] = ph->num_for_eachBatch_1;
	}

	if(sendinPacketRoundIndex[2] < ph->round_Batch_2)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[2] == ph->round_Batch_2
			&&receivedPackeNumberInQueue[2] < ph->num_for_eachBatch_2)
	{
		receivedPackeNumberInQueue[2] = ph->num_for_eachBatch_2;
	}

	if(sendinPacketRoundIndex[3] < ph->round_Batch_3)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[3] == ph->round_Batch_3
			&&receivedPackeNumberInQueue[3] < ph->num_for_eachBatch_3)
	{
		receivedPackeNumberInQueue[3] = ph->num_for_eachBatch_3;
	}

	if(sendinPacketRoundIndex[4] < ph->round_Batch_4)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[4] == ph->round_Batch_4
			&&receivedPackeNumberInQueue[4] < ph->num_for_eachBatch_4)
	{
		receivedPackeNumberInQueue[4] = ph->num_for_eachBatch_4;
	}

	if(sendinPacketRoundIndex[5] < ph->round_Batch_5)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[5] == ph->round_Batch_5
			&&receivedPackeNumberInQueue[5] < ph->num_for_eachBatch_5)
	{
		receivedPackeNumberInQueue[5] = ph->num_for_eachBatch_5;
	}

	if(sendinPacketRoundIndex[6] < ph->round_Batch_6)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[6] == ph->round_Batch_6
			&&receivedPackeNumberInQueue[6] < ph->num_for_eachBatch_6)
	{
		receivedPackeNumberInQueue[6] = ph->num_for_eachBatch_6;
	}

	if(sendinPacketRoundIndex[7] < ph->round_Batch_7)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[7] == ph->round_Batch_7
			&&receivedPackeNumberInQueue[7] < ph->num_for_eachBatch_7)
	{
		receivedPackeNumberInQueue[7] = ph->num_for_eachBatch_7;
	}

	if(sendinPacketRoundIndex[8] < ph->round_Batch_8)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[8] == ph->round_Batch_8
			&&receivedPackeNumberInQueue[8] < ph->num_for_eachBatch_8)
	{
		receivedPackeNumberInQueue[8] = ph->num_for_eachBatch_8;
	}

	if(sendinPacketRoundIndex[9] < ph->round_Batch_9)
	{
		printf("source node ack error\n");
	}
	else if (sendinPacketRoundIndex[9] == ph->round_Batch_9
			&&receivedPackeNumberInQueue[9] < ph->num_for_eachBatch_9)
	{
		receivedPackeNumberInQueue[9] = ph->num_for_eachBatch_9;
	}

    //updateRequiredSendingPacketsInQueue();
}

void
More::source_generate_ack(int sequence)
{
	printf("source_generate_ack\n");
    Packet* data = allocpkt();
    struct hdr_cmn* ch = HDR_CMN(data);
    struct hdr_ip* ih = HDR_IP(data);
    hdr_tcp *tcph = hdr_tcp::access(data);
    tcph->seqno() = sequence;
    ch->direction() = hdr_cmn::UP;
    ch->prev_hop_ = index;
    ch->ptype() = PT_ACK;
    ch->error() = 0;
    ch->addr_type() = NS_AF_INET;
    ch->size() = 20+20+20;//ip,tcp.more
    ih->saddr() = 5;
    ih->daddr() = 0;
    ih->sport() = 0;
    ih->dport() = 0;
    ih->ttl() = ih->ttl()-1;
    Scheduler::instance().schedule(target_,data,NO_DELAY);
}

/*intermediate node receive and forward packets begin
 */


// it doesn't use in current project.
void
More::intermediates_receive_newdataPackets(Packet* p)
{
	printf("<-----############------>intermediate_");
	printf("index ==%d begin intermediates_receive_newdataPackets<------############------>\n",index);
    //resetRecevingAckTimer(p,index);
    printPacketContent(p);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    int queueIndex = ph->pkt_batch_num_ ;


    intermediateClearQueue(queueIndex,ph->pkt_round());

    // code again
    more_rqueue squeue = getCurrentSendingQueueIndex(queueIndex);
    Packet* newPacket = networkcoding.insertNewReceiveCodedPacket
	    (p,squeue,codeingPacketNumber,512);
    printf("<-----########squeue length==%d####------>intermediate_\n",squeue.lenghtofQueue());
    if(newPacket != 0)
    {
    	squeue.enque(newPacket);
    	//unAckedPackeNumberInQueue[queueIndex]++;
    	updateTheUnAckedPacketsInQueue(p);
		saveSendingQueueInLocalByQueueIndex(queueIndex,squeue);
    }

	printf("<-----############------>intermediate_");
	printf("index ==%d   end receive_dataPackets<------############------>\n",index);
}

void
More::intermediates_receive_olddataPackets(Packet* p)
{
	printf("<-----############------>intermediate_");
	printf("index ==%d begin intermediates_receive_olddataPackets<------############------>\n",index);
	resetHighPriorityTimer(p,index);
    printPacketContent(p);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    int queueIndex = ph->pkt_batch_num_ ;


    intermediateClearQueue(queueIndex,ph->pkt_round());

    // code again
    more_rqueue squeue = getCurrentSendingQueueIndex(queueIndex);
    Packet* newPacket = networkcoding.insertNewReceiveCodedPacket
	    (p,squeue,codeingPacketNumber,512);
    printf("<-----########squeue length==%d####------>intermediate_\n",squeue.lenghtofQueue());
    if(newPacket != 0)
    {
    	squeue.enque(newPacket);
    	unAckedPackeNumberInQueue[queueIndex]++;
    	//updateTheUnAckedPacketsInQueue(p);
		saveSendingQueueInLocalByQueueIndex(queueIndex,squeue);
    }

	printf("<-----############------>intermediate_");
	printf("index ==%d   end receive_dataPackets<------############------>\n",index);
}

void
More::intermediates_receive_dataPackets(Packet* p)
{
//   struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
//
//   if(ph->newPacketIndex_ > newpacketRound ||ph->newPacketIndex_  ==0)
//   {
//	   newpacketRound = ph->newPacketIndex_;
//	   intermediates_receive_newdataPackets(p);
//   }else {
	   intermediates_receive_olddataPackets(p);
  // }

}

//intermediate sending
void
More::intermediate_send_newdataPackets()
{
	printf("<-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d begin send_dataPackets<------@@@@@@@@@@@@------>\n",index);

    printf("receivedNewPacketNumberInQueue===%d\n",receivedNewPacketNumberInQueue[0]);

    int cumNum = 0;
    for(int i=0;i<totalNumberOfGroup;i++)
    {
		if(receivedNewPacketNumberInQueue[i]>0)
		{
			cumNum = cumNum+receivedNewPacketNumberInQueue[i];
		}
    }
    int total = cumNum;
    printf("send_newdata- cumNum=%d\n",cumNum);
    for(int i=0;i<totalNumberOfGroup;i++)
    {
	// check whether it needs to send packets
    	if(receivedNewPacketNumberInQueue[i]>0)
	    {
    		more_rqueue squeue = getCurrentSendingQueueIndex(i);
    		//temporaryUnAckedPacketNumberInQueue[i] = squeue.lenghtofQueue();

			for(int z=0;z<receivedNewPacketNumberInQueue[i];z++)
			{

				Packet* codedPacket = generateCodedPacketBasedOnSendingQueue(squeue);
				Packet* sendingPacket = intermediate_configure_dataPackets(codedPacket);

				struct hdr_more_pkt* ph = HDR_MORE_PKT(sendingPacket);
				hdr_tcp *tcph = hdr_tcp::access(sendingPacket);
				ph->pkt_batch_num_ = i;
				sendingPacket = intermediate_configure_receivedPacketNum_batch(sendingPacket);
				tcph->reason_ = cumNum;
				tcph->seqno_ = sendinPacketRoundIndex[i]*100+i*10+
						squeue.lenghtofQueue()-receivedNewPacketNumberInQueue[i]+z;
				ph->pkt_round() = sendinPacketRoundIndex[i];
				ph->cur_wait_num = cumNum;
				cumNum--;

				printf("intermediates_send_dataPackets  at %d\n",z);
				printPacketContent(sendingPacket);

				//updateTheUnAckedPacketsByIndex(i);
//				temporaryUnAckedPacketNumberInQueue[i] = temporaryUnAckedPacketNumberInQueue[i]+
//						receivedNewPacketNumberInQueue[i];
				unAckedPackeNumberInQueue[i]++;
				Scheduler::instance().schedule(target_, sendingPacket,NO_DELAY);
			}
			receivedNewPacketNumberInQueue[i] = 0;
	    }
    }
// after sending packet for one round, make sure that it need sometimes
    //to wait for downstream node receives packets;
    if(total >0)resetSendTimer();
    //resetDestinationACKTimer();
	printf("<-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}

void
More::intermediates_send_dataPackets()
{
	printf("<-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d begin send_dataPackets<------@@@@@@@@@@@@------>\n",index);

  	 for(int i=0;i<totalNumberOfGroup;i++)
  	 {
  		updateTheUnAckedPacketsByIndex(i);
  	 }

     int cumNum = 0;
     for(int i=0;i<totalNumberOfGroup;i++)
     {
 		if(requiredSendingPackeNumberInQueue[i]>0)
 		{
 			cumNum = cumNum+requiredSendingPackeNumberInQueue[i];
 		}
     }

    int total = cumNum;
    printf("send_data- cumNum=%d\n",cumNum);
    for(int i=0;i<totalNumberOfGroup;i++)
    {
	// check whether it needs to send packets
    	printf("unAckedPackeNumberInQueue=inter==%d\n",unAckedPackeNumberInQueue[i]);
    	if(requiredSendingPackeNumberInQueue[i]>0)
	    {
    		more_rqueue squeue = getCurrentSendingQueueIndex(i);
    	    //temporaryUnAckedPacketNumberInQueue[i] = squeue.lenghtofQueue();

			for(int z=0;z<requiredSendingPackeNumberInQueue[i];z++)
			{

				Packet* codedPacket = generateCodedPacketBasedOnSendingQueue(squeue);
				Packet* sendingPacket = intermediate_configure_dataPackets(codedPacket);

				struct hdr_more_pkt* ph = HDR_MORE_PKT(sendingPacket);
				hdr_tcp *tcph = hdr_tcp::access(sendingPacket);
				ph->pkt_batch_num_ = i;
				sendingPacket = intermediate_configure_receivedPacketNum_batch(sendingPacket);

				tcph->seqno_ = sendinPacketRoundIndex[i]*100+i*10+
						squeue.lenghtofQueue()-requiredSendingPackeNumberInQueue[i]+z;
				ph->pkt_round() = sendinPacketRoundIndex[i];
				tcph->reason_ = cumNum;
				ph->cur_wait_num = cumNum;
				cumNum--;
				printf("intermediates_send_dataPackets  at %d\n",z);
				printPacketContent(sendingPacket);
				Scheduler::instance().schedule(target_, sendingPacket,NO_DELAY);
			}

	    }
    }
// after sending packet for one round, make sure that it need sometimes
    //to wait for downstream node receives packets;
    if(total >0)resetSendTimer();
	printf("<-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}


void
More::intermediates_receive_downstream_dataPackets(Packet* p)
{
    // do something when it receives the downstream data;
	printf("intermediates_==%d receive_downstream_dataPackets\n",index);
    intermediates_checkDownstreamDataInformation(p);
    intermediates_checkDownstreamDataInnovativeInformation(p);
    resetHighPriorityTimer(p,index);
}

void
More::intermediates_checkDownstreamDataInformation(Packet* p)
{
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

    if(sendinPacketRoundIndex[0] < ph->round_Batch_0)
    {
    	intermediateClearQueue(0,ph->round_Batch_0);
    	receivedPackeNumberInQueue[0] = ph->num_for_eachBatch_0;
    	printf("receivedPackeNumberInQueue--0----%d\n",receivedPackeNumberInQueue[0]);
    }
    else if (sendinPacketRoundIndex[0] == ph->round_Batch_0
    		&&receivedPackeNumberInQueue[0] < ph->num_for_eachBatch_0)
    {
    	receivedPackeNumberInQueue[0] = ph->num_for_eachBatch_0;
    	printf("receivedPackeNumberInQueue--0----%d\n",receivedPackeNumberInQueue[0]);
    }

    if(sendinPacketRoundIndex[1] < ph->round_Batch_1)
    {
    	intermediateClearQueue(1,ph->round_Batch_1);
    	receivedPackeNumberInQueue[1] = ph->num_for_eachBatch_1;
    	printf("receivedPackeNumberInQueue--1----%d\n",receivedPackeNumberInQueue[1]);
    }
    else if (sendinPacketRoundIndex[1] == ph->round_Batch_1
    		&&receivedPackeNumberInQueue[1] < ph->num_for_eachBatch_1)
    {
    	receivedPackeNumberInQueue[1] = ph->num_for_eachBatch_1;
    	printf("receivedPackeNumberInQueue--1----%d\n",receivedPackeNumberInQueue[1]);
    }

    if(sendinPacketRoundIndex[2] < ph->round_Batch_2)
    {
    	intermediateClearQueue(2,ph->round_Batch_2);
    	receivedPackeNumberInQueue[2] = ph->num_for_eachBatch_2;
    	printf("receivedPackeNumberInQueue--2----%d\n",receivedPackeNumberInQueue[2]);
    }
    else if (sendinPacketRoundIndex[2] == ph->round_Batch_2
    		&&receivedPackeNumberInQueue[2] < ph->num_for_eachBatch_2)
    {
    	receivedPackeNumberInQueue[2] = ph->num_for_eachBatch_2;
    	printf("receivedPackeNumberInQueue--2----%d\n",receivedPackeNumberInQueue[2]);
    }

    if(sendinPacketRoundIndex[3] < ph->round_Batch_3)
    {
    	intermediateClearQueue(3,ph->round_Batch_3);
    	receivedPackeNumberInQueue[3] = ph->num_for_eachBatch_3;
    	printf("receivedPackeNumberInQueue--3----%d\n",receivedPackeNumberInQueue[3]);
    }
    else if (sendinPacketRoundIndex[3] == ph->round_Batch_3
    		&&receivedPackeNumberInQueue[3] < ph->num_for_eachBatch_3)
    {
    	receivedPackeNumberInQueue[3] = ph->num_for_eachBatch_3;
    	printf("receivedPackeNumberInQueue--3----%d\n",receivedPackeNumberInQueue[3]);
    }

    if(sendinPacketRoundIndex[4] < ph->round_Batch_4)
    {
    	intermediateClearQueue(4,ph->round_Batch_4);
    	receivedPackeNumberInQueue[4] = ph->num_for_eachBatch_4;
    	printf("receivedPackeNumberInQueue--4----%d\n",receivedPackeNumberInQueue[4]);
    }
    else if (sendinPacketRoundIndex[4] == ph->round_Batch_4
    		&&receivedPackeNumberInQueue[4] < ph->num_for_eachBatch_4)
    {
    	receivedPackeNumberInQueue[4] = ph->num_for_eachBatch_4;
    	printf("receivedPackeNumberInQueue--4----%d\n",receivedPackeNumberInQueue[4]);
    }

    if(sendinPacketRoundIndex[5] < ph->round_Batch_5)
    {
    	intermediateClearQueue(5,ph->round_Batch_5);
    	receivedPackeNumberInQueue[5] = ph->num_for_eachBatch_5;
    	printf("receivedPackeNumberInQueue--5----%d\n",receivedPackeNumberInQueue[5]);
    }
    else if (sendinPacketRoundIndex[5] == ph->round_Batch_5
    		&&receivedPackeNumberInQueue[5] < ph->num_for_eachBatch_5)
    {
    	receivedPackeNumberInQueue[5] = ph->num_for_eachBatch_5;
    	printf("receivedPackeNumberInQueue--5----%d\n",receivedPackeNumberInQueue[5]);
    }

    if(sendinPacketRoundIndex[6] < ph->round_Batch_6)
    {
    	intermediateClearQueue(6,ph->round_Batch_6);
    	receivedPackeNumberInQueue[6] = ph->num_for_eachBatch_6;
    	printf("receivedPackeNumberInQueue--6----%d\n",receivedPackeNumberInQueue[6]);
    }
    else if (sendinPacketRoundIndex[6] == ph->round_Batch_6
    		&&receivedPackeNumberInQueue[6] < ph->num_for_eachBatch_6)
    {
    	receivedPackeNumberInQueue[6] = ph->num_for_eachBatch_6;
    	printf("receivedPackeNumberInQueue--6----%d\n",receivedPackeNumberInQueue[6]);
    }

    if(sendinPacketRoundIndex[7] < ph->round_Batch_7)
    {
    	intermediateClearQueue(7,ph->round_Batch_7);
    	receivedPackeNumberInQueue[7] = ph->num_for_eachBatch_7;
    	printf("receivedPackeNumberInQueue--7----%d\n",receivedPackeNumberInQueue[7]);
    }
    else if (sendinPacketRoundIndex[7] == ph->round_Batch_7
    		&&receivedPackeNumberInQueue[7] < ph->num_for_eachBatch_7)
    {
    	receivedPackeNumberInQueue[7] = ph->num_for_eachBatch_7;
    	printf("receivedPackeNumberInQueue--7----%d\n",receivedPackeNumberInQueue[7]);
    }

    if(sendinPacketRoundIndex[8] < ph->round_Batch_8)
    {
    	intermediateClearQueue(8,ph->round_Batch_8);
    	receivedPackeNumberInQueue[8] = ph->num_for_eachBatch_8;
    	printf("receivedPackeNumberInQueue--8----%d\n",receivedPackeNumberInQueue[8]);
    }
    else if (sendinPacketRoundIndex[8] == ph->round_Batch_8
    		&&receivedPackeNumberInQueue[8] < ph->num_for_eachBatch_8)
    {
    	receivedPackeNumberInQueue[8] = ph->num_for_eachBatch_8;
    	printf("receivedPackeNumberInQueue--8----%d\n",receivedPackeNumberInQueue[8]);
    }

    if(sendinPacketRoundIndex[9] < ph->round_Batch_9)
    {
    	intermediateClearQueue(9,ph->round_Batch_9);
    	receivedPackeNumberInQueue[9] = ph->num_for_eachBatch_9;
    	printf("receivedPackeNumberInQueue--9----%d\n",receivedPackeNumberInQueue[9]);
    }
    else if (sendinPacketRoundIndex[9] == ph->round_Batch_9
    		&&receivedPackeNumberInQueue[9] < ph->num_for_eachBatch_9)
    {
    	receivedPackeNumberInQueue[9] = ph->num_for_eachBatch_9;
    	printf("receivedPackeNumberInQueue--9----%d\n",receivedPackeNumberInQueue[9]);
    }

    updateRequiredSendingPacketsInQueue();
}

void
More::intermediates_checkDownstreamDataInnovativeInformation(Packet* p)
{
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    int queueIndex = ph->pkt_batch_num_ ;

    intermediateClearQueue(queueIndex,ph->pkt_round());

    // code again
    more_rqueue squeue = getCurrentSendingQueueIndex(queueIndex);
    Packet* newPacket = networkcoding.insertNewReceiveCodedPacket
	    (p,squeue,codeingPacketNumber,512);
    printf("intermediates_out_checkDownstreamDataInnovativeInformation=%d\n",index);
    if(newPacket != 0)
    {
    	printf("intermediates_checkDownstreamDataInnovativeInformation=%d\n",index);
    	unAckedPackeNumberInQueue[queueIndex]++;
    }
}

void
More::intermediates_receive_ACKPackets(Packet*p)
{
    //do something before forward this ACK;
    intermediates_checkACKInformation(p);
    intermediates_send_ACKPackets(p);
    resetHighPriorityTimer(p,index);
}

void
More::intermediates_overhear_ACKPackets(const Packet*p)
{
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

    if(sendinPacketRoundIndex[0] < ph->round_Batch_0)
    {
    	intermediateClearQueue(0,ph->round_Batch_0);
    	receivedPackeNumberInQueue[0] = ph->num_for_eachBatch_0;
    }
    else if (sendinPacketRoundIndex[0] == ph->round_Batch_0
    		&&receivedPackeNumberInQueue[0] < ph->num_for_eachBatch_0)
    {
    	receivedPackeNumberInQueue[0] = ph->num_for_eachBatch_0;
    }

    if(sendinPacketRoundIndex[1] < ph->round_Batch_1)
    {
    	intermediateClearQueue(1,ph->round_Batch_1);
    	receivedPackeNumberInQueue[1] = ph->num_for_eachBatch_1;
    }
    else if (sendinPacketRoundIndex[1] == ph->round_Batch_1
    		&&receivedPackeNumberInQueue[1] < ph->num_for_eachBatch_1)
    {
    	receivedPackeNumberInQueue[1] = ph->num_for_eachBatch_1;
    }

    if(sendinPacketRoundIndex[2] < ph->round_Batch_2)
    {
    	intermediateClearQueue(2,ph->round_Batch_2);
    	receivedPackeNumberInQueue[2] = ph->num_for_eachBatch_2;
    }
    else if (sendinPacketRoundIndex[2] == ph->round_Batch_2
    		&&receivedPackeNumberInQueue[2] < ph->num_for_eachBatch_2)
    {
    	receivedPackeNumberInQueue[2] = ph->num_for_eachBatch_2;
    }

    if(sendinPacketRoundIndex[3] < ph->round_Batch_3)
    {
    	intermediateClearQueue(3,ph->round_Batch_3);
    	receivedPackeNumberInQueue[3] = ph->num_for_eachBatch_3;
    }
    else if (sendinPacketRoundIndex[3] == ph->round_Batch_3
    		&&receivedPackeNumberInQueue[3] < ph->num_for_eachBatch_3)
    {
    	receivedPackeNumberInQueue[3] = ph->num_for_eachBatch_3;
    }

    if(sendinPacketRoundIndex[4] < ph->round_Batch_4)
    {
    	intermediateClearQueue(4,ph->round_Batch_4);
    	receivedPackeNumberInQueue[4] = ph->num_for_eachBatch_4;
    }
    else if (sendinPacketRoundIndex[4] == ph->round_Batch_4
    		&&receivedPackeNumberInQueue[4] < ph->num_for_eachBatch_4)
    {
    	receivedPackeNumberInQueue[4] = ph->num_for_eachBatch_4;
    }

    if(sendinPacketRoundIndex[5] < ph->round_Batch_5)
    {
    	intermediateClearQueue(5,ph->round_Batch_5);
    	receivedPackeNumberInQueue[5] = ph->num_for_eachBatch_5;
    }
    else if (sendinPacketRoundIndex[5] == ph->round_Batch_5
    		&&receivedPackeNumberInQueue[5] < ph->num_for_eachBatch_5)
    {
    	receivedPackeNumberInQueue[5] = ph->num_for_eachBatch_5;
    }

    if(sendinPacketRoundIndex[6] < ph->round_Batch_6)
    {
    	intermediateClearQueue(6,ph->round_Batch_6);
    	receivedPackeNumberInQueue[6] = ph->num_for_eachBatch_6;
    }
    else if (sendinPacketRoundIndex[6] == ph->round_Batch_6
    		&&receivedPackeNumberInQueue[6] < ph->num_for_eachBatch_6)
    {
    	receivedPackeNumberInQueue[6] = ph->num_for_eachBatch_6;
    }

    if(sendinPacketRoundIndex[7] < ph->round_Batch_7)
    {
    	intermediateClearQueue(7,ph->round_Batch_7);
    	receivedPackeNumberInQueue[7] = ph->num_for_eachBatch_7;
    }
    else if (sendinPacketRoundIndex[7] == ph->round_Batch_7
    		&&receivedPackeNumberInQueue[7] < ph->num_for_eachBatch_7)
    {
    	receivedPackeNumberInQueue[7] = ph->num_for_eachBatch_7;
    }

    if(sendinPacketRoundIndex[8] < ph->round_Batch_8)
    {
    	intermediateClearQueue(8,ph->round_Batch_8);
    	receivedPackeNumberInQueue[8] = ph->num_for_eachBatch_8;
    }
    else if (sendinPacketRoundIndex[8] == ph->round_Batch_8
    		&&receivedPackeNumberInQueue[8] < ph->num_for_eachBatch_8)
    {
    	receivedPackeNumberInQueue[8] = ph->num_for_eachBatch_8;
    }

    if(sendinPacketRoundIndex[9] < ph->round_Batch_9)
    {
    	intermediateClearQueue(9,ph->round_Batch_9);
    	receivedPackeNumberInQueue[9] = ph->num_for_eachBatch_9;
    }
    else if (sendinPacketRoundIndex[9] == ph->round_Batch_9
    		&&receivedPackeNumberInQueue[9] < ph->num_for_eachBatch_9)
    {
    	receivedPackeNumberInQueue[9] = ph->num_for_eachBatch_9;
    }

    updateRequiredSendingPacketsInQueue();
}

void
More::intermediates_checkACKInformation(Packet* p)
{
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

    if(sendinPacketRoundIndex[0] < ph->round_Batch_0)
    {
    	intermediateClearQueue(0,ph->round_Batch_0);
    	receivedPackeNumberInQueue[0] = ph->num_for_eachBatch_0;
    }
    else if (sendinPacketRoundIndex[0] == ph->round_Batch_0
    		&&receivedPackeNumberInQueue[0] < ph->num_for_eachBatch_0)
    {
    	receivedPackeNumberInQueue[0] = ph->num_for_eachBatch_0;
    }

    if(sendinPacketRoundIndex[1] < ph->round_Batch_1)
    {
    	intermediateClearQueue(1,ph->round_Batch_1);
    	receivedPackeNumberInQueue[1] = ph->num_for_eachBatch_1;
    }
    else if (sendinPacketRoundIndex[1] == ph->round_Batch_1
    		&&receivedPackeNumberInQueue[1] < ph->num_for_eachBatch_1)
    {
    	receivedPackeNumberInQueue[1] = ph->num_for_eachBatch_1;
    }

    if(sendinPacketRoundIndex[2] < ph->round_Batch_2)
    {
    	intermediateClearQueue(2,ph->round_Batch_2);
    	receivedPackeNumberInQueue[2] = ph->num_for_eachBatch_2;
    }
    else if (sendinPacketRoundIndex[2] == ph->round_Batch_2
    		&&receivedPackeNumberInQueue[2] < ph->num_for_eachBatch_2)
    {
    	receivedPackeNumberInQueue[2] = ph->num_for_eachBatch_2;
    }

    if(sendinPacketRoundIndex[3] < ph->round_Batch_3)
    {
    	intermediateClearQueue(3,ph->round_Batch_3);
    	receivedPackeNumberInQueue[3] = ph->num_for_eachBatch_3;
    }
    else if (sendinPacketRoundIndex[3] == ph->round_Batch_3
    		&&receivedPackeNumberInQueue[3] < ph->num_for_eachBatch_3)
    {
    	receivedPackeNumberInQueue[3] = ph->num_for_eachBatch_3;
    }

    if(sendinPacketRoundIndex[4] < ph->round_Batch_4)
    {
    	intermediateClearQueue(4,ph->round_Batch_4);
    	receivedPackeNumberInQueue[4] = ph->num_for_eachBatch_4;
    }
    else if (sendinPacketRoundIndex[4] == ph->round_Batch_4
    		&&receivedPackeNumberInQueue[4] < ph->num_for_eachBatch_4)
    {
    	receivedPackeNumberInQueue[4] = ph->num_for_eachBatch_4;
    }

    if(sendinPacketRoundIndex[5] < ph->round_Batch_5)
    {
    	intermediateClearQueue(5,ph->round_Batch_5);
    	receivedPackeNumberInQueue[5] = ph->num_for_eachBatch_5;
    }
    else if (sendinPacketRoundIndex[5] == ph->round_Batch_5
    		&&receivedPackeNumberInQueue[5] < ph->num_for_eachBatch_5)
    {
    	receivedPackeNumberInQueue[5] = ph->num_for_eachBatch_5;
    }

    if(sendinPacketRoundIndex[6] < ph->round_Batch_6)
    {
    	intermediateClearQueue(6,ph->round_Batch_6);
    	receivedPackeNumberInQueue[6] = ph->num_for_eachBatch_6;
    }
    else if (sendinPacketRoundIndex[6] == ph->round_Batch_6
    		&&receivedPackeNumberInQueue[6] < ph->num_for_eachBatch_6)
    {
    	receivedPackeNumberInQueue[6] = ph->num_for_eachBatch_6;
    }

    if(sendinPacketRoundIndex[7] < ph->round_Batch_7)
    {
    	intermediateClearQueue(7,ph->round_Batch_7);
    	receivedPackeNumberInQueue[7] = ph->num_for_eachBatch_7;
    }
    else if (sendinPacketRoundIndex[7] == ph->round_Batch_7
    		&&receivedPackeNumberInQueue[7] < ph->num_for_eachBatch_7)
    {
    	receivedPackeNumberInQueue[7] = ph->num_for_eachBatch_7;
    }

    if(sendinPacketRoundIndex[8] < ph->round_Batch_8)
    {
    	intermediateClearQueue(8,ph->round_Batch_8);
    	receivedPackeNumberInQueue[8] = ph->num_for_eachBatch_8;
    }
    else if (sendinPacketRoundIndex[8] == ph->round_Batch_8
    		&&receivedPackeNumberInQueue[8] < ph->num_for_eachBatch_8)
    {
    	receivedPackeNumberInQueue[8] = ph->num_for_eachBatch_8;
    }

    if(sendinPacketRoundIndex[9] < ph->round_Batch_9)
    {
    	intermediateClearQueue(9,ph->round_Batch_9);
    	receivedPackeNumberInQueue[9] = ph->num_for_eachBatch_9;
    }
    else if (sendinPacketRoundIndex[9] == ph->round_Batch_9
    		&&receivedPackeNumberInQueue[9] < ph->num_for_eachBatch_9)
    {
    	receivedPackeNumberInQueue[9] = ph->num_for_eachBatch_9;
    }

    updateRequiredSendingPacketsInQueue();

	printf("intermediate unAckedPackeNumberInQueue 0 = %d\n",unAckedPackeNumberInQueue[0]);
	printf("intermediate unAckedPackeNumberInQueue 1 = %d\n",unAckedPackeNumberInQueue[1]);
	printf("intermediate unAckedPackeNumberInQueue 2 = %d\n",unAckedPackeNumberInQueue[2]);
	printf("intermediate unAckedPackeNumberInQueue 3 = %d\n",unAckedPackeNumberInQueue[3]);
	printf("intermediate unAckedPackeNumberInQueue 4 = %d\n",unAckedPackeNumberInQueue[4]);
	printf("intermediate unAckedPackeNumberInQueue 5 = %d\n",unAckedPackeNumberInQueue[5]);
	printf("intermediate unAckedPackeNumberInQueue 6 = %d\n",unAckedPackeNumberInQueue[6]);
	printf("intermediate unAckedPackeNumberInQueue 7 = %d\n",unAckedPackeNumberInQueue[7]);
	printf("intermediate unAckedPackeNumberInQueue 8 = %d\n",unAckedPackeNumberInQueue[8]);
	printf("intermediate unAckedPackeNumberInQueue 9 = %d\n",unAckedPackeNumberInQueue[9]);


	printf("intermediate receivedPackeNumberInQueue 0 = %d\n",receivedPackeNumberInQueue[0]);
	printf("intermediate receivedPackeNumberInQueue 1 = %d\n",receivedPackeNumberInQueue[1]);
	printf("intermediate receivedPackeNumberInQueue 2 = %d\n",receivedPackeNumberInQueue[2]);
	printf("intermediate receivedPackeNumberInQueue 3 = %d\n",receivedPackeNumberInQueue[3]);
	printf("intermediate receivedPackeNumberInQueue 4 = %d\n",receivedPackeNumberInQueue[4]);
	printf("intermediate receivedPackeNumberInQueue 5 = %d\n",receivedPackeNumberInQueue[5]);
	printf("intermediate receivedPackeNumberInQueue 6 = %d\n",receivedPackeNumberInQueue[6]);
	printf("intermediate receivedPackeNumberInQueue 7 = %d\n",receivedPackeNumberInQueue[7]);
	printf("intermediate receivedPackeNumberInQueue 8 = %d\n",receivedPackeNumberInQueue[8]);
	printf("intermediate receivedPackeNumberInQueue 9 = %d\n",receivedPackeNumberInQueue[9]);

	printf("intermediate num_for_eachBatch_0 = %d\n",ph->num_for_eachBatch_0);
	printf("intermediate num_for_eachBatch_1 = %d\n",ph->num_for_eachBatch_1);
	printf("intermediate num_for_eachBatch_2 = %d\n",ph->num_for_eachBatch_2);
	printf("intermediate num_for_eachBatch_3 = %d\n",ph->num_for_eachBatch_3);
	printf("intermediate num_for_eachBatch_4 = %d\n",ph->num_for_eachBatch_4);
	printf("intermediate num_for_eachBatch_5 = %d\n",ph->num_for_eachBatch_5);
	printf("intermediate num_for_eachBatch_6 = %d\n",ph->num_for_eachBatch_6);
	printf("intermediate num_for_eachBatch_7 = %d\n",ph->num_for_eachBatch_7);
	printf("intermediate num_for_eachBatch_8 = %d\n",ph->num_for_eachBatch_8);
	printf("intermediate num_for_eachBatch_9 = %d\n",ph->num_for_eachBatch_9);

}

void
More::intermediates_send_ACKPackets(Packet* p)
{
    intermediates_ACKMechanism_simpleACK(p);
}

void
More::intermediates_ACKMechanism_simpleACK(Packet* p)
{
    // add received packets information
	printf("<ACK-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d begin send_ACKPackets<------@@@@@@@@@@@@------>\n",index);

    p = intermediate_configure_receivedPacketNum_batch(p);
    struct hdr_cmn* ch = HDR_CMN(p);
    struct hdr_ip* ih = HDR_IP(p);
    ch->direction() = hdr_cmn::DOWN;
    ch->prev_hop_ = index;
    ch->ptype() = PT_ACK;
    ch->error() = 0;
//    if(index == 4)ch->next_hop() = 3;
    if(index == 3)ch->next_hop() = 0;
    //ch->next_hop() = 0;//need update here
    ch->addr_type() = NS_AF_INET;
    ch->size() = 20+20+20;//ip,tcp.more
    ih->saddr() = 5;
    ih->daddr() = 9;
    ih->sport() = 0;
    ih->dport() = 0;
    ih->ttl() = ih->ttl()-1;
    Scheduler::instance().schedule(target_, p,NO_DELAY);

	printf("<ACK-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d   end send_ACKPackets<------@@@@@@@@@@@@------>\n",index);

}

/*intermediate node receive and forward packets end
 */


/*destination node receive packets,up deliver and ACK begin
 */
void
More::destination_receive_dataPackets(Packet* p)
{
    //resetNewPacketTimer();
	printf("<-----############------>destination_");
	printf("index ==%d begin receive_dataPackets<------############------>\n",index);

    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    int queueIndex = ph->pkt_batch_num_ ;

    intermediateClearQueue(queueIndex,ph->pkt_round());

    more_rqueue rec = getCurrentReceiveQueueIndex(queueIndex);
    Packet* newPacket = networkcoding.insertNewReceiveCodedPacket
	    (p,rec,codeingPacketNumber,512);
    printf("the number of reque == %d\n",rec.lenghtofQueue());
    if(newPacket !=0)
    {
    	printf("new packet coming  = queueIndex--=%d-round--==%d\n",queueIndex,ph->pkt_round());
		rec = networkcoding.createReduceRowEchelon
			(rec,codeingPacketNumber,512,newPacket);
		rec = networkcoding.changePositionOfQueueBasedOnFirstNotNullValueOfCoefficient
			(rec,codeingPacketNumber,512,newPacket);
		//rec.enque(newPacket);
		printf("the number of reque == %d\n",rec.lenghtofQueue());
//		more_rqueue squeue = getCurrentSendingQueueIndex(queueIndex);
//		transferPacketsFromRecToSenQueue(rec,squeue,queueIndex);
		saveReceivingQueueInLocalByQueueIndex(queueIndex,rec);
		//destinationLastReceivedPacket = p->copy();// may have some problems
		desination_deliever_packet_toUpperLayer(p,rec,queueIndex,newPacket);
		//destination_send_ACKPackets(queueIndex);
		resetDestinationACKTimer(p);
    }
    else if (0)//Retransmission of packets
    {
    	//destination_send_ACKPackets(p);
    }
	printf("<-----############------>destination_");
	printf("index ==%d   end receive_dataPackets<------############------>\n",index);
}

//destination send ACK
void
More::destination_send_ACKPackets(int queueIndex)
{
    destination_ACKMechanism_simpleACK(queueIndex);
    //resetDestinationACKTimer();
}

void
More::destination_ACKMechanism_simpleACK(int queueIndex)
{

	printf("<ACK-----@@@@@@@@@@@@------>destination_");
	printf("index ==%d begin send_ACKPackets<------@@@@@@@@@@@@------>\n",index);

//    struct hdr_more_pkt* ph_data = HDR_MORE_PKT(p);
//    int queueIndex = ph_data->pkt_batch_num_ ;
//    int retransmissionFactor = ph_data->retransmissionFactor();
//    int roundIndex = ph_data->pkt_round();

//    printf("queueIndex  = %d\n",queueIndex);
//    printf("retransmissionFactor  = %d\n",retransmissionFactor);
//    printf("roundIndex  = %d\n",roundIndex);

    Packet* ack = allocpkt();
    // add received packets information
    ack = destination_configure_receivedPacketNum_batch(ack);
    struct hdr_cmn* ch = HDR_CMN(ack);
    struct hdr_ip* ih = HDR_IP(ack);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(ack);
    hdr_tcp *tcph = hdr_tcp::access(ack);
    ph->pkt_src() = ra_addr();
    ph->more_type = MORETYPE_DATA;
    ph->max_received_batch() =
	    destinationReceivedMaxQueueIndex;// destination successfully received batch

    ph->current_batch() = destinationReceivedMaxQueueIndex;//queueIndex;
    ph->num_for_currentBatch =getCurrentReceiveQueueIndex(destinationReceivedMaxQueueIndex).lenghtofQueue();
    		//getCurrentReceiveQueueIndex(queueIndex).lenghtofQueue();
   // ph->retransmissionFactor() = retransmissionFactor;
	tcph->seqno_ = sendinPacketRoundIndex[destinationReceivedMaxQueueIndex]*100+
			destinationReceivedMaxQueueIndex*10+
			getCurrentReceiveQueueIndex(destinationReceivedMaxQueueIndex).lenghtofQueue()-1;
	tcph->ackno_ = destinationReceivedMaxQueueIndex;
	tcph->reason_ = getCurrentReceiveQueueIndex(destinationReceivedMaxQueueIndex).lenghtofQueue();


	ph->pkt_round() = sendinPacketRoundIndex[destinationReceivedMaxQueueIndex];
    //ph->pkt_round() = roundIndex;
    ch->direction() = hdr_cmn::DOWN;
    ch->prev_hop_ = index;
    ch->ptype() = PT_ACK;
    ch->error() = 0;
    ch->next_hop() = 3;
    ch->addr_type() = NS_AF_INET;
    ch->size() = 20+20+20;//ip,tcp.more
    ih->saddr() = 5;
    ih->daddr() = 0;
    ih->sport() = 0;
    ih->dport() = 0;
    ih->ttl() = ih->ttl()-1;
    Scheduler::instance().schedule(target_, ack,NO_DELAY);
	printf("<ACK-----@@@@@@@@@@@@------>destination_");
	printf("index ==%d   end send_ACKPackets<------@@@@@@@@@@@@------>\n",index);
}

void
More::desination_deliever_packet_toUpperLayer(Packet* p,more_rqueue rec,
	int index,Packet* newPacket)
{
    desination_upperLayer_mechanism_wholeBatch(p,rec,index,newPacket);
}

void
More::desination_upperLayer_mechanism_wholeBatch(Packet* p,more_rqueue rec,
	int index,Packet* newPacket)
{

	printf("desination_upperLayer_mechanism_wholeBatch\n");

    if(destinationReceivedMaxQueueIndex == index && rec.lenghtofQueue() == 10)
    {
    	printf("destinationReceivedMaxQueueIndex++ 1\n");
    	//rec.remove_all_packet();
    	saveReceivingQueueInLocalByQueueIndex(destinationReceivedMaxQueueIndex,rec);
    	destinationReceivedMaxQueueIndex++;

    	if(destinationReceivedMaxQueueIndex == 10)
    	{
    		destinationReceivedMaxQueueIndex = 0;
    		printf("destinationReceivedMaxQueueIndex == 10\n");
    		sendinPacketRoundIndex[0] = sendinPacketRoundIndex[0]+1;
    		clearQueueByIndex(0);
    	}else {

        	if(sendinPacketRoundIndex[destinationReceivedMaxQueueIndex] <
        			sendinPacketRoundIndex[destinationReceivedMaxQueueIndex-1])
        	{
        		sendinPacketRoundIndex[destinationReceivedMaxQueueIndex]
        		                       = sendinPacketRoundIndex[destinationReceivedMaxQueueIndex]+1;
        		clearQueueByIndex(destinationReceivedMaxQueueIndex);
        	}
    	}
    	more_rqueue rec_inner = getCurrentSendingQueueIndex
		(destinationReceivedMaxQueueIndex);

		for(int i = 0;i<10;i++)
		{
			//destination_generate_data(destinationReceivedPacketMAXSequence);
			destinationReceivedPacketMAXSequence++;
		}

		while(rec_inner.lenghtofQueue() == 10)
		{
			printf("destinationReceivedMaxQueueIndex++ 2\n");
			//rec_inner.remove_all_packet();
			saveReceivingQueueInLocalByQueueIndex(destinationReceivedMaxQueueIndex,rec);
			destinationReceivedMaxQueueIndex++;
			if(destinationReceivedMaxQueueIndex == 10) destinationReceivedMaxQueueIndex = 0;
			rec_inner = getCurrentSendingQueueIndex
					(destinationReceivedMaxQueueIndex);
			for(int i = 0;i<10;i++)
			{
				//destination_generate_data(destinationReceivedPacketMAXSequence);
				destinationReceivedPacketMAXSequence++;
			}
		}
    }
}

void
More::destination_generate_data(int sequence)
{
    Packet* data = allocpkt();
    struct hdr_cmn* ch = HDR_CMN(data);
    struct hdr_ip* ih = HDR_IP(data);
    hdr_tcp *tcph = hdr_tcp::access(data);
    tcph->seqno() = sequence;
    ch->direction() = hdr_cmn::UP;
    ch->prev_hop_ = index;
    ch->ptype() = PT_TCP;
    ch->error() = 0;
    ch->addr_type() = NS_AF_INET;
    ch->size() = 20+20+20;//ip,tcp.more
    ih->saddr() = 0;
    ih->daddr() = 5;
    ih->sport() = 0;
    ih->dport() = 0;
    ih->ttl() = ih->ttl()-1;
    Scheduler::instance().schedule(target_,data,NO_DELAY);
}

/*destination node receive packets,up deliver and ACKbegin
 */

Packet*
More::generateCodedPacketBasedOnSendingQueue(more_rqueue sen)
{
    more_rqueue send = networkcoding.enqueAllCodedPacketInQueueToOneCodedPacket
	    (codeingPacketNumber,512,sen,sen);

    Packet* p = send.get_tail();

    Packet* newPacket =allocpkt();
    struct hdr_cmn* ch = HDR_CMN(p);
    struct hdr_cmn* new_ch = HDR_CMN(newPacket);
    ch->uid_ = new_ch->uid_;

    return p;
}

Packet*
More::source_generate_codedPackets(Packet* p, int sequence)
{
    struct hdr_cmn* pre_ch = HDR_CMN(p);
    hdr_tcp *pre_tcph = hdr_tcp::access(p);
    double pre_ts = pre_tcph->ts_;/* time packet generated (at source) */
    int pre_sequ = pre_tcph->seqno();/* sequence number */
    int pre_ch_size = pre_ch->size(); // simulated packet size
    int pre_ch_type = pre_ch->ptype_;// TCP or ACK or .... TCP =0;
    Packet::free(p);
    Packet* codedPacket = allocpkt();
    struct hdr_cmn* ch = HDR_CMN(codedPacket);
    hdr_tcp *tcph = hdr_tcp::access(codedPacket);
    ch->size() = pre_ch_size;
    ch->ptype_ =pre_ch_type;
    tcph->ts_ = pre_ts;
    tcph->seqno() = pre_sequ;
    codedPacket->allocdata(512);
    PacketData* packdata = (PacketData*)codedPacket->userdata();
    unsigned char* data_zc = (unsigned char*)packdata->data();
    *data_zc = 65;
    for(int i=0;i <511;i++)
    {
		data_zc++;
		*data_zc = 65;
    }
    unsigned char* encode = networkcoding.getRandomEncodingVector(8,1);
    unsigned char encoding = *encode;
    int position = sequence % codeingPacketNumber;
    Packet* new_p = networkcoding.encodingPacket(encoding,codeingPacketNumber,codedPacket,512,position);
    return new_p;
}

/*
 * configure packets begin
 */
Packet*
More::intermediate_configure_receivedPacketNum_batch(Packet* p)
{
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    more_rqueue squeue_0 = getCurrentSendingQueueIndex(0);
    ph->num_for_eachBatch_0 = squeue_0.lenghtofQueue();
    ph->round_Batch_0 = sendinPacketRoundIndex[0];

    more_rqueue squeue_1 = getCurrentSendingQueueIndex(1);
    ph->num_for_eachBatch_1 = squeue_1.lenghtofQueue();
    ph->round_Batch_1 = sendinPacketRoundIndex[1];

    more_rqueue squeue_2 = getCurrentSendingQueueIndex(2);
    ph->num_for_eachBatch_2 = squeue_2.lenghtofQueue();
    ph->round_Batch_2 = sendinPacketRoundIndex[2];

    more_rqueue squeue_3 = getCurrentSendingQueueIndex(3);
    ph->num_for_eachBatch_3 = squeue_3.lenghtofQueue();
    ph->round_Batch_3 = sendinPacketRoundIndex[3];

    more_rqueue squeue_4 = getCurrentSendingQueueIndex(4);
    ph->num_for_eachBatch_4 = squeue_4.lenghtofQueue();
    ph->round_Batch_4 = sendinPacketRoundIndex[4];

    more_rqueue squeue_5 = getCurrentSendingQueueIndex(5);
    ph->num_for_eachBatch_5 = squeue_5.lenghtofQueue();
    ph->round_Batch_5 = sendinPacketRoundIndex[5];

    more_rqueue squeue_6 = getCurrentSendingQueueIndex(6);
    ph->num_for_eachBatch_6 = squeue_6.lenghtofQueue();
    ph->round_Batch_6 = sendinPacketRoundIndex[6];

    more_rqueue squeue_7 = getCurrentSendingQueueIndex(7);
    ph->num_for_eachBatch_7 = squeue_7.lenghtofQueue();
    ph->round_Batch_7 = sendinPacketRoundIndex[7];

    more_rqueue squeue_8 = getCurrentSendingQueueIndex(8);
    ph->num_for_eachBatch_8 = squeue_8.lenghtofQueue();
    ph->round_Batch_8 = sendinPacketRoundIndex[8];

    more_rqueue squeue_9 = getCurrentSendingQueueIndex(9);
    ph->num_for_eachBatch_9 = squeue_9.lenghtofQueue();
    ph->round_Batch_9 = sendinPacketRoundIndex[9];
//
//    struct hdr_cmn* ch = HDR_CMN(p);
//    struct hdr_ip* ih = HDR_IP(p);
//    ph->pkt_src() = ra_addr();
//    ph->more_type = MORETYPE_DATA;
//    ph->pkt_len() = 20;
//
//
//    ch->ptype() = PT_TCP;
//    ch->direction() = hdr_cmn::DOWN;
//    ch->size() = 512+20+20+20;
//    ch->error() = 0;
//    ch->next_hop() = 2;
//    ch->prev_hop_ = index;
//    ch->addr_type() = NS_AF_INET;//NS_AF_ILINK;//
//    ih->saddr() = ra_addr();
//    ih->daddr() = 2;
//    ih->sport() = 0;
//    ih->dport() = 0;

    return p;
}

Packet*
More::destination_configure_receivedPacketNum_batch(Packet* p)
{
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    more_rqueue rqueue_0 = getCurrentReceiveQueueIndex(0);
    ph->num_for_eachBatch_0 = rqueue_0.lenghtofQueue();
    ph->round_Batch_0 = sendinPacketRoundIndex[0];

    more_rqueue rqueue_1 = getCurrentReceiveQueueIndex(1);
    ph->num_for_eachBatch_1 = rqueue_1.lenghtofQueue();
    ph->round_Batch_1 = sendinPacketRoundIndex[1];

    more_rqueue rqueue_2 = getCurrentReceiveQueueIndex(2);
    ph->num_for_eachBatch_2 = rqueue_2.lenghtofQueue();
    ph->round_Batch_2 = sendinPacketRoundIndex[2];

    more_rqueue rqueue_3 = getCurrentReceiveQueueIndex(3);
    ph->num_for_eachBatch_3 = rqueue_3.lenghtofQueue();
    ph->round_Batch_3 = sendinPacketRoundIndex[3];

    more_rqueue rqueue_4 = getCurrentReceiveQueueIndex(4);
    ph->num_for_eachBatch_4 = rqueue_4.lenghtofQueue();
    ph->round_Batch_4 = sendinPacketRoundIndex[4];

    more_rqueue rqueue_5 = getCurrentReceiveQueueIndex(5);
    ph->num_for_eachBatch_5 = rqueue_5.lenghtofQueue();
    ph->round_Batch_5 = sendinPacketRoundIndex[5];

    more_rqueue rqueue_6 = getCurrentReceiveQueueIndex(6);
    ph->num_for_eachBatch_6 = rqueue_6.lenghtofQueue();
    ph->round_Batch_6 = sendinPacketRoundIndex[6];

    more_rqueue rqueue_7 = getCurrentReceiveQueueIndex(7);
    ph->num_for_eachBatch_7 = rqueue_7.lenghtofQueue();
    ph->round_Batch_7 = sendinPacketRoundIndex[7];

    more_rqueue rqueue_8 = getCurrentReceiveQueueIndex(8);
    ph->num_for_eachBatch_8 = rqueue_8.lenghtofQueue();
    ph->round_Batch_8 = sendinPacketRoundIndex[8];

    more_rqueue rqueue_9 = getCurrentReceiveQueueIndex(9);
    ph->num_for_eachBatch_9 = rqueue_9.lenghtofQueue();
    ph->round_Batch_9 = sendinPacketRoundIndex[9];

	printf(" destination num_for_eachBatch_0 = %d,%d\n",ph->num_for_eachBatch_0,ph->round_Batch_0);
	printf(" destination num_for_eachBatch_1 = %d,,%d\n",ph->num_for_eachBatch_1,ph->round_Batch_1);
	printf(" destination num_for_eachBatch_2 = %d,%d\n",ph->num_for_eachBatch_2,ph->round_Batch_2);
	printf(" destination num_for_eachBatch_3 = %d,%d\n",ph->num_for_eachBatch_3,ph->round_Batch_3);
	printf(" destination num_for_eachBatch_4 = %d,%d\n",ph->num_for_eachBatch_4,ph->round_Batch_4);
	printf(" destination num_for_eachBatch_5 = %d,%d\n",ph->num_for_eachBatch_5,ph->round_Batch_5);
	printf(" destination num_for_eachBatch_6 = %d,%d\n",ph->num_for_eachBatch_6,ph->round_Batch_6);
	printf(" destination num_for_eachBatch_7 = %d,%d\n",ph->num_for_eachBatch_7,ph->round_Batch_7);
	printf(" destination num_for_eachBatch_8 = %d,%d\n",ph->num_for_eachBatch_8,ph->round_Batch_8);
	printf(" destination num_for_eachBatch_9 = %d,%d\n",ph->num_for_eachBatch_9,ph->round_Batch_9);

    return p;
}

Packet*
More::source_configure_dataPackets(Packet* p)
{
    struct hdr_cmn* ch = HDR_CMN(p);
    struct hdr_ip* ih = HDR_IP(p);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    ph->pkt_src() = ra_addr();
    ph->more_type = MORETYPE_DATA;
    ph->pkt_len() = 20;
//
//
    more_rqueue squeue_0 = getCurrentReceiveQueueIndex(0);
    ph->num_for_eachBatch_0 = squeue_0.lenghtofQueue();
    ph->round_Batch_0 = sendinPacketRoundIndex[0];

    more_rqueue squeue_1 = getCurrentReceiveQueueIndex(1);
    ph->num_for_eachBatch_1 = squeue_1.lenghtofQueue();
    ph->round_Batch_1 = sendinPacketRoundIndex[1];

    more_rqueue squeue_2 = getCurrentReceiveQueueIndex(2);
    ph->num_for_eachBatch_2 = squeue_2.lenghtofQueue();
    ph->round_Batch_2 = sendinPacketRoundIndex[2];

    more_rqueue squeue_3 = getCurrentReceiveQueueIndex(3);
    ph->num_for_eachBatch_3 = squeue_3.lenghtofQueue();
    ph->round_Batch_3 = sendinPacketRoundIndex[3];

    more_rqueue squeue_4 = getCurrentReceiveQueueIndex(4);
    ph->num_for_eachBatch_4 = squeue_4.lenghtofQueue();
    ph->round_Batch_4 = sendinPacketRoundIndex[4];

    more_rqueue squeue_5 = getCurrentReceiveQueueIndex(5);
    ph->num_for_eachBatch_5 = squeue_5.lenghtofQueue();
    ph->round_Batch_5 = sendinPacketRoundIndex[5];

    more_rqueue squeue_6 = getCurrentReceiveQueueIndex(6);
    ph->num_for_eachBatch_6 = squeue_6.lenghtofQueue();
    ph->round_Batch_6 = sendinPacketRoundIndex[6];

    more_rqueue squeue_7 = getCurrentReceiveQueueIndex(7);
    ph->num_for_eachBatch_7 = squeue_7.lenghtofQueue();
    ph->round_Batch_7 = sendinPacketRoundIndex[7];

    more_rqueue squeue_8 = getCurrentReceiveQueueIndex(8);
    ph->num_for_eachBatch_8 = squeue_8.lenghtofQueue();
    ph->round_Batch_8 = sendinPacketRoundIndex[8];

    more_rqueue squeue_9 = getCurrentReceiveQueueIndex(9);
    ph->num_for_eachBatch_9 = squeue_9.lenghtofQueue();
    ph->round_Batch_9 = sendinPacketRoundIndex[9];
//
//    ch->ptype() = PT_TCP;
//    ch->direction() = hdr_cmn::DOWN;
//    ch->size() = 512+20+20+20;
//    ch->error() = 0;
//    ch->next_hop() = 1;
//    ch->prev_hop_ = index;
//    ch->addr_type() = NS_AF_INET;//NS_AF_ILINK;//
//    ih->saddr() = ra_addr();
//    ih->daddr() = 2;
//    ih->sport() = 0;
//    ih->dport() = 0;
    return p;
}

Packet*
More::intermediate_configure_dataPackets(Packet* p)
{
    struct hdr_cmn* ch = HDR_CMN(p);
    struct hdr_ip* ih = HDR_IP(p);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    ph->pkt_src() = ra_addr();
    ph->more_type = MORETYPE_DATA;
    ph->pkt_len() = 20;
    ch->ptype() = PT_TCP;
    ch->direction() = hdr_cmn::DOWN;
    ch->size() = 512+20+20+20;
    ch->error() = 0;
    ch->next_hop() = IP_BROADCAST;
    ch->prev_hop_ = index;
    ch->addr_type() = NS_AF_INET;//NS_AF_ILINK;//
    ih->saddr() = ra_addr();
    ih->daddr() = IP_BROADCAST;
    ih->sport() = 0;
    ih->dport() = 0;
    return p;
}

/*
 * configure packets end
 */

void
More::caculateRequiredSendingNum()
{

}

void
More::transferPacketsFromRecToSenQueue(more_rqueue rec,more_rqueue sen,int index)
{
    int receivingQueueLength = rec.lenghtofQueue();

    for(int i =0;i<receivingQueueLength;i++)
    {
		Packet* p = rec.deque();
		printPacketContent(p);
		sen.enque(p);
    }
    saveReceivingQueueInLocalByQueueIndex(index,rec);
    saveSendingQueueInLocalByQueueIndex(index,sen);
}

void
More::updateTheUnAckedPacketsInQueue(Packet* p)
{
    hdr_tcp *tcph = hdr_tcp::access(p);
    int maxPacketNumber = codeingPacketNumber*totalNumberOfGroup;
    int remainder = tcph->seqno() % maxPacketNumber;

    if(codeingPacketNumber*0<=remainder && remainder< codeingPacketNumber*1)
    {
    	//unAckedPackeNumberInQueue[0]++;
    	receivedNewPacketNumberInQueue[0]++;
    }
    else if(codeingPacketNumber*1<=remainder && remainder<codeingPacketNumber*2)
    {
    	//unAckedPackeNumberInQueue[1]++;
    	receivedNewPacketNumberInQueue[1]++;
    }
    else if(codeingPacketNumber*2<=remainder && remainder<codeingPacketNumber*3)
    {
    	//unAckedPackeNumberInQueue[2]++;
    	receivedNewPacketNumberInQueue[2]++;
    }
    else if(codeingPacketNumber*3<=remainder && remainder<codeingPacketNumber*4)
    {
    	//unAckedPackeNumberInQueue[3]++;
    	receivedNewPacketNumberInQueue[3]++;
    }
    else if(codeingPacketNumber*4<=remainder && remainder<codeingPacketNumber*5)
    {
    	//unAckedPackeNumberInQueue[4]++;
    	receivedNewPacketNumberInQueue[4]++;
    }
    else if(codeingPacketNumber*5<=remainder && remainder<codeingPacketNumber*6)
    {
    	//unAckedPackeNumberInQueue[5]++;
    	receivedNewPacketNumberInQueue[5]++;
    }
    else if(codeingPacketNumber*6<=remainder && remainder<codeingPacketNumber*7)
    {
    	//unAckedPackeNumberInQueue[6]++;
    	receivedNewPacketNumberInQueue[6]++;
    }
    else if(codeingPacketNumber*7<=remainder && remainder<codeingPacketNumber*8)
    {
    	//unAckedPackeNumberInQueue[7]++;
    	receivedNewPacketNumberInQueue[7]++;
    }
    else if(codeingPacketNumber*8<=remainder && remainder<codeingPacketNumber*9)
    {
    	//unAckedPackeNumberInQueue[8]++;
    	receivedNewPacketNumberInQueue[8]++;
    }
    else if(codeingPacketNumber*9<=remainder && remainder<codeingPacketNumber*10)
    {
    	//unAckedPackeNumberInQueue[9]++;
    	receivedNewPacketNumberInQueue[9]++;
    }
    else
    {
    	//unAckedPackeNumberInQueue[0]++;
    }

    //updateRequiredSendingPacketsInQueue();

}

void
More::updateRequiredSendingPacketsInQueue()
{
	requiredSendingPackeNumberInQueue[0] =
			unAckedPackeNumberInQueue[0] - receivedPackeNumberInQueue[0];
	printf("requiredSendingPackeNumberInQueue 0 --- %d\n",requiredSendingPackeNumberInQueue[0]);
	if(requiredSendingPackeNumberInQueue[0] < 0){
			unAckedPackeNumberInQueue[0] = receivedPackeNumberInQueue[0];
			requiredSendingPackeNumberInQueue[0]=0;
		}


	requiredSendingPackeNumberInQueue[1] =
			unAckedPackeNumberInQueue[1] - receivedPackeNumberInQueue[1];
	printf("requiredSendingPackeNumberInQueue 1 --- %d\n",requiredSendingPackeNumberInQueue[1]);
	if(requiredSendingPackeNumberInQueue[1] < 0){
		unAckedPackeNumberInQueue[1] = receivedPackeNumberInQueue[1];
		requiredSendingPackeNumberInQueue[1]=0;
	}


	requiredSendingPackeNumberInQueue[2] =
			unAckedPackeNumberInQueue[2] - receivedPackeNumberInQueue[2];
	printf("requiredSendingPackeNumberInQueue 2 --- %d\n",requiredSendingPackeNumberInQueue[2]);
	if(requiredSendingPackeNumberInQueue[2] < 0){
		unAckedPackeNumberInQueue[2] = receivedPackeNumberInQueue[2];
		requiredSendingPackeNumberInQueue[2]=0;
	}


	requiredSendingPackeNumberInQueue[3] =
			unAckedPackeNumberInQueue[3] - receivedPackeNumberInQueue[3];
	printf("requiredSendingPackeNumberInQueue 3 --- %d\n",requiredSendingPackeNumberInQueue[3]);
	if(requiredSendingPackeNumberInQueue[3] < 0){
		unAckedPackeNumberInQueue[3] = receivedPackeNumberInQueue[3];
		requiredSendingPackeNumberInQueue[3]=0;
	}


	requiredSendingPackeNumberInQueue[4] =
			unAckedPackeNumberInQueue[4] - receivedPackeNumberInQueue[4];
	printf("requiredSendingPackeNumberInQueue 4 --- %d\n",requiredSendingPackeNumberInQueue[4]);
	if(requiredSendingPackeNumberInQueue[4] < 0){
		unAckedPackeNumberInQueue[4] = receivedPackeNumberInQueue[4];
		requiredSendingPackeNumberInQueue[4]=0;
	}


	requiredSendingPackeNumberInQueue[5] =
			unAckedPackeNumberInQueue[5] - receivedPackeNumberInQueue[5];
	printf("requiredSendingPackeNumberInQueue 5 --- %d\n",requiredSendingPackeNumberInQueue[5]);
	if(requiredSendingPackeNumberInQueue[5] < 0){
		unAckedPackeNumberInQueue[5] = receivedPackeNumberInQueue[5];
		requiredSendingPackeNumberInQueue[5]=0;
	}


	requiredSendingPackeNumberInQueue[6] =
			unAckedPackeNumberInQueue[6] - receivedPackeNumberInQueue[6];
	printf("requiredSendingPackeNumberInQueue 6 --- %d\n",requiredSendingPackeNumberInQueue[6]);
	if(requiredSendingPackeNumberInQueue[6] < 0){
		unAckedPackeNumberInQueue[6] = receivedPackeNumberInQueue[6];
		requiredSendingPackeNumberInQueue[6]=0;
	}


	requiredSendingPackeNumberInQueue[7] =
			unAckedPackeNumberInQueue[7] - receivedPackeNumberInQueue[7];
	printf("requiredSendingPackeNumberInQueue 7 --- %d\n",requiredSendingPackeNumberInQueue[7]);
	if(requiredSendingPackeNumberInQueue[7] < 0){
		unAckedPackeNumberInQueue[7] = receivedPackeNumberInQueue[7];
		requiredSendingPackeNumberInQueue[7]=0;
	}


	requiredSendingPackeNumberInQueue[8] =
			unAckedPackeNumberInQueue[8] - receivedPackeNumberInQueue[8];
	printf("requiredSendingPackeNumberInQueue 8 --- %d\n",requiredSendingPackeNumberInQueue[8]);
	if(requiredSendingPackeNumberInQueue[8] < 0){
		unAckedPackeNumberInQueue[8] = receivedPackeNumberInQueue[8];
		requiredSendingPackeNumberInQueue[8]=0;
	}


	requiredSendingPackeNumberInQueue[9] =
			unAckedPackeNumberInQueue[9] - receivedPackeNumberInQueue[9];
	printf("requiredSendingPackeNumberInQueue 9 --- %d\n",requiredSendingPackeNumberInQueue[9]);
	if(requiredSendingPackeNumberInQueue[9] < 0){
		unAckedPackeNumberInQueue[9] = receivedPackeNumberInQueue[9];
		requiredSendingPackeNumberInQueue[9]=0;
	}
}

void
More::updateTheUnAckedPacketsByIndex(int index)
{
    //unAckedPackeNumberInQueue[index]++;
    //receivedNewPacketNumberInQueue[index]++;
    updateRequiredSendingPacketsInQueueByIndex(index);
}

void
More::updateRequiredSendingPacketsInQueueByIndex(int index)
{
	printf("unAckedPackeNumberInQueue[index] ==%d ---\n",
			unAckedPackeNumberInQueue[index]);
	requiredSendingPackeNumberInQueue[index] =
			unAckedPackeNumberInQueue[index] - receivedPackeNumberInQueue[index];
	if(requiredSendingPackeNumberInQueue[index] < 0)
		printf("updateRequiredSendingPacketsInQueueByIndex index ==%d --- error\n",index);
}

void
More::updateRoundInforForEachQueue(int sequence)
{
	printf("updateRoundInforForEachQueue -- sequence = %d\n",sequence);
    int maxPacketNumber = codeingPacketNumber*totalNumberOfGroup;
    int remainder = sequence % maxPacketNumber;
    int division = sequence / maxPacketNumber;

    printf("updateRoundInforForEachQueue---remainder==%d\n",remainder);
    printf("updateRoundInforForEachQueue---division==%d\n",division);

    if(codeingPacketNumber*0<=remainder && remainder< codeingPacketNumber*1)
    {
    	if(sendinPacketRoundIndex[0] < division){
    		sendinPacketRoundIndex[0] = division;
    		printf("coming\n");
    		clearQueueByIndex(0);
    	}
    }
    else if(codeingPacketNumber*1<=remainder && remainder<codeingPacketNumber*2)
    {
    	if(sendinPacketRoundIndex[1] < division){
    		sendinPacketRoundIndex[1] = division;
    		printf("coming 1\n");
    		clearQueueByIndex(1);
    	}
    }
    else if(codeingPacketNumber*2<=remainder && remainder<codeingPacketNumber*3)
    {
    	if(sendinPacketRoundIndex[2] < division){
    		sendinPacketRoundIndex[2] = division;
    		clearQueueByIndex(2);
    	}
    }
    else if(codeingPacketNumber*3<=remainder && remainder<codeingPacketNumber*4)
    {
    	if(sendinPacketRoundIndex[3] < division){
    		sendinPacketRoundIndex[3] = division;
    		clearQueueByIndex(3);
    	}
    }
    else if(codeingPacketNumber*4<=remainder && remainder<codeingPacketNumber*5)
    {
    	if(sendinPacketRoundIndex[4] < division){
    		sendinPacketRoundIndex[4] = division;
    		clearQueueByIndex(4);
    	}
    }
    else if(codeingPacketNumber*5<=remainder && remainder<codeingPacketNumber*6)
    {
    	if(sendinPacketRoundIndex[5] < division){
    		sendinPacketRoundIndex[5] = division;
    		clearQueueByIndex(5);
    	}
    }
    else if(codeingPacketNumber*6<=remainder && remainder<codeingPacketNumber*7)
    {
    	if(sendinPacketRoundIndex[6] < division){
    		sendinPacketRoundIndex[6] = division;
    		clearQueueByIndex(6);
    	}
    }
    else if(codeingPacketNumber*7<=remainder && remainder<codeingPacketNumber*8)
    {
    	if(sendinPacketRoundIndex[7] < division){
    		sendinPacketRoundIndex[7] = division;
    		clearQueueByIndex(7);
    	}
    }
    else if(codeingPacketNumber*8<=remainder && remainder<codeingPacketNumber*9)
    {
    	if(sendinPacketRoundIndex[8] < division){
    		sendinPacketRoundIndex[8] = division;
    		clearQueueByIndex(8);
    	}
    }
    else if(codeingPacketNumber*9<=remainder && remainder<codeingPacketNumber*10)
    {
    	if(sendinPacketRoundIndex[9] < division){
    		sendinPacketRoundIndex[9] = division;
    		clearQueueByIndex(9);
    	}
    }
    else
    {
    	if(sendinPacketRoundIndex[0] < division){
    		sendinPacketRoundIndex[0] = division;
    		clearQueueByIndex(0);
    	}
    }
}

bool
More::checkTransmitParameter()
{
    //return(receiveNewPacketTimer == 1 && highPriorityNodesTimer == 1 && NotSendingPacket ==1);
    return true;
}

bool
More::checkSendingParameter()
{
    return true;
    //return (NotSendingPacket==1);
}
//queue function

void
More::sourceClearQueue(int sequence)
{

}

void
More::intermediateClearQueue(int index,int roundValue)
{
    if(sendinPacketRoundIndex[index] < roundValue)
    {
    	sendinPacketRoundIndex[index] = roundValue;

    	receivedPackeNumberInQueue[index] = 0;
    	requiredSendingPackeNumberInQueue[index] = 0;
    	unAckedPackeNumberInQueue[index] = 0;

    	clearQueueByIndex(index);
    }
}

void
More::clearQueueByIndex(int index)
{
   	receivedPackeNumberInQueue[index] = 0;
    requiredSendingPackeNumberInQueue[index] = 0;
    unAckedPackeNumberInQueue[index] = 0;
    receivedNewPacketNumberInQueue[index]=0;
    if(index == 0)
    {printf("clearQueueByIndex 0 \n");
	squeue_0.remove_all_packet();
	rqueue_0.remove_all_packet();
    }
    else if(index == 1)
    {
    	printf("clearQueueByIndex 1 \n");
	squeue_1.remove_all_packet();
	rqueue_1.remove_all_packet();
	printf("clearQueueByIndex 1 length=%d\n",rqueue_1.lenghtofQueue());
    }
    else if(index == 2)
    {
	squeue_2.remove_all_packet();
	rqueue_2.remove_all_packet();
    }
    else if(index == 3)
    {
	squeue_3.remove_all_packet();
	rqueue_3.remove_all_packet();
    }
    else if(index == 4)
    {
	squeue_4.remove_all_packet();
	rqueue_4.remove_all_packet();
    }
    else if(index == 5)
    {
	squeue_5.remove_all_packet();
	rqueue_5.remove_all_packet();
    }
    else if(index == 6)
    {
	squeue_6.remove_all_packet();
	rqueue_6.remove_all_packet();
    }
    else if(index == 7)
    {
	squeue_7.remove_all_packet();
	rqueue_7.remove_all_packet();
    }
    else if(index == 8)
    {
	squeue_8.remove_all_packet();
	rqueue_8.remove_all_packet();
    }
    else if(index == 9)
    {
	squeue_9.remove_all_packet();
	rqueue_9.remove_all_packet();
    }
}

void
More::destinationClearQueue(int index)
{

}

more_rqueue
More::getCurrentReceiveQueueBySequence(int sequence)
{
    int maxPacketNumber = codeingPacketNumber*totalNumberOfGroup;
    int remainder = sequence % maxPacketNumber;

    if(codeingPacketNumber*0<=remainder && remainder< codeingPacketNumber*1)
    {
	return rqueue_0;
    }
    else if(codeingPacketNumber*1<=remainder && remainder<codeingPacketNumber*2)
    {
	return rqueue_1;
    }
    else if(codeingPacketNumber*2<=remainder && remainder<codeingPacketNumber*3)
    {
	return rqueue_2;
    }
    else if(codeingPacketNumber*3<=remainder && remainder<codeingPacketNumber*4)
    {
	return rqueue_3;
    }
    else if(codeingPacketNumber*4<=remainder && remainder<codeingPacketNumber*5)
    {
	return rqueue_4;
    }
    else if(codeingPacketNumber*5<=remainder && remainder<codeingPacketNumber*6)
    {
	return rqueue_5;
    }
    else if(codeingPacketNumber*6<=remainder && remainder<codeingPacketNumber*7)
    {
	return rqueue_6;
    }
    else if(codeingPacketNumber*7<=remainder && remainder<codeingPacketNumber*8)
    {
	return rqueue_7;
    }
    else if(codeingPacketNumber*8<=remainder && remainder<codeingPacketNumber*9)
    {
	return rqueue_8;
    }
    else if(codeingPacketNumber*9<=remainder && remainder<codeingPacketNumber*10)
    {
	return rqueue_9;
    }
    else
    {
	return rqueue_0;
    }
}

more_rqueue
More::getCurrentReceiveQueueIndex(int index)
{
    if(index == 0)
    {
	return rqueue_0;
    }
    else if(index == 1)
    {
	return rqueue_1;
    }
    else if(index == 2)
    {
	return rqueue_2;
    }
    else if(index == 3)
    {
	return rqueue_3;
    }
    else if(index == 4)
    {
	return rqueue_4;
    }
    else if(index == 5)
    {
	return rqueue_5;
    }
    else if(index == 6)
    {
	return rqueue_6;
    }
    else if(index == 7)
    {
	return rqueue_7;
    }
    else if(index == 8)
    {
	return rqueue_8;
    }
    else if(index == 9)
    {
	return rqueue_9;
    }
    else
    {
	return rqueue_0;
    }
}

more_rqueue
More::getCurrentSendingQueueIndex(int index)
{
    if(index == 0)
    {
	return squeue_0;
    }
    else if(index == 1)
    {
	return squeue_1;
    }
    else if(index == 2)
    {
	return squeue_2;
    }
    else if(index == 3)
    {
	return squeue_3;
    }
    else if(index == 4)
    {
	return squeue_4;
    }
    else if(index == 5)
    {
	return squeue_5;
    }
    else if(index == 6)
    {
	return squeue_6;
    }
    else if(index == 7)
    {
	return squeue_7;
    }
    else if(index == 8)
    {
	return squeue_8;
    }
    else if(index == 9)
    {
	return squeue_9;
    }
    else
    {
	return squeue_0;
    }
}

void
More::saveReceivingQueueInLocalByQueueSequence(int sequence,more_rqueue queue)
{
	printf("saveReceivingQueueInLocalByQueueSequence -- sequence = %d\n",sequence);
    int maxPacketNumber = codeingPacketNumber*totalNumberOfGroup;
    int remainder = sequence % maxPacketNumber;
    printf("remainder ---------------%d\n",remainder);
    if(codeingPacketNumber*0<=remainder && remainder< codeingPacketNumber*1)
    {printf("1\n");
	rqueue_0 = queue;
    }
    else if(codeingPacketNumber*1<=remainder && remainder<codeingPacketNumber*2)
    {
    	printf("2\n");
	rqueue_1 = queue;
    }
    else if(codeingPacketNumber*2<=remainder && remainder<codeingPacketNumber*3)
    {
	rqueue_2 = queue;
    }
    else if(codeingPacketNumber*3<=remainder && remainder<codeingPacketNumber*4)
    {
	rqueue_3 = queue;
    }
    else if(codeingPacketNumber*4<=remainder && remainder<codeingPacketNumber*5)
    {
	rqueue_4 = queue;
    }
    else if(codeingPacketNumber*5<=remainder && remainder<codeingPacketNumber*6)
    {
	rqueue_5 = queue;
    }
    else if(codeingPacketNumber*6<=remainder && remainder<codeingPacketNumber*7)
    {
	rqueue_6 = queue;
    }
    else if(codeingPacketNumber*7<=remainder && remainder<codeingPacketNumber*8)
    {
	rqueue_7 = queue;
    }
    else if(codeingPacketNumber*8<=remainder && remainder<codeingPacketNumber*9)
    {
	rqueue_8 = queue;
    }
    else if(codeingPacketNumber*9<=remainder && remainder<codeingPacketNumber*10)
    {
	rqueue_9 = queue;
    }
    else
    {
	rqueue_0 = queue;
    }
}

void
More::saveReceivingQueueInLocalByQueueIndex(int index,more_rqueue queue)
{
    if(index == 0)
    {
    	rqueue_0 = queue;
    }
    else if(index == 1)
    {
    	rqueue_1 = queue;;
    }
    else if(index == 2)
    {
    	rqueue_2 = queue;
    }
    else if(index == 3)
    {
    	rqueue_3 = queue;
    }
    else if(index == 4)
    {
    	rqueue_4 = queue;
    }
    else if(index == 5)
    {
    	rqueue_5 = queue;
    }
    else if(index == 6)
    {
    	rqueue_6 = queue;
    }
    else if(index == 7)
    {
    	rqueue_7 = queue;
    }
    else if(index == 8)
    {
    	rqueue_8 = queue;
    }
    else if(index == 9)
    {
    	rqueue_9 = queue;
    }
    else
    {
    	rqueue_0 = queue;
    }
}

void
More::saveSendingQueueInLocalByQueueIndex(int index,more_rqueue queue)
{
    if(index == 0)
    {
	squeue_0 = queue;
    }
    else if(index == 1)
    {
	squeue_1 = queue;;
    }
    else if(index == 2)
    {
	squeue_2 = queue;
    }
    else if(index == 3)
    {
	squeue_3 = queue;
    }
    else if(index == 4)
    {
	squeue_4 = queue;
    }
    else if(index == 5)
    {
	squeue_5 = queue;
    }
    else if(index == 6)
    {
	squeue_6 = queue;
    }
    else if(index == 7)
    {
	squeue_7 = queue;
    }
    else if(index == 8)
    {
	squeue_8 = queue;
    }
    else if(index == 9)
    {
	squeue_9 = queue;
    }
    else
    {
	squeue_0 = queue;
    }
}

more_rqueue
More::getCurrentSendingQueueBySequence(int sequence)
{
    int maxPacketNumber = codeingPacketNumber*totalNumberOfGroup;
    int remainder = sequence % maxPacketNumber;

    if(codeingPacketNumber*0<=remainder && remainder< codeingPacketNumber*1)
    {
	return squeue_0;
    }
    else if(codeingPacketNumber*1<=remainder && remainder<codeingPacketNumber*2)
    {
	return squeue_1;
    }
    else if(codeingPacketNumber*2<=remainder && remainder<codeingPacketNumber*3)
    {
	return squeue_2;
    }
    else if(codeingPacketNumber*3<=remainder && remainder<codeingPacketNumber*4)
    {
	return squeue_3;
    }
    else if(codeingPacketNumber*4<=remainder && remainder<codeingPacketNumber*5)
    {
	return squeue_4;
    }
    else if(codeingPacketNumber*5<=remainder && remainder<codeingPacketNumber*6)
    {
	return squeue_5;
    }
    else if(codeingPacketNumber*6<=remainder && remainder<codeingPacketNumber*7)
    {
	return squeue_6;
    }
    else if(codeingPacketNumber*7<=remainder && remainder<codeingPacketNumber*8)
    {
	return squeue_7;
    }
    else if(codeingPacketNumber*8<=remainder && remainder<codeingPacketNumber*9)
    {
	return squeue_8;
    }
    else if(codeingPacketNumber*9<=remainder && remainder<codeingPacketNumber*10)
    {
	return squeue_9;
    }
    else
    {
	return squeue_0;
    }
}

//timer function


void
More::WaitForReceivingNewpacketsFinishTimerHandler()
{
    printf("index == %d WaitForReceivingNewpacketsFinishTimerHandler timer expired\n",index);
    if(wHighpsTimer.busy())
    {

    }else{
    	source_send_newDataPacket();
    }
}

void
More::WaitForHighPrioritySendingTimerHandler()
{
	printf("index == %d WaitForHighPrioritySendingTimerHandler\n",index);


	if(index != 0)
	{

		if(index == 1 || index ==2 || index == 4)
		{
			printf("WaitForHighPrioritySendingTimerHandler expired at index = %d\n",index);
		}

	    if(wrAckTimer.busy())
	    {

	    }else{
	    	intermediates_send_dataPackets();
	    	intermediate_send_newdataPackets();
	    }
	}
	else
	{
		if(wrNewfTimer.busy())
		{

		}else{
			source_send_dataPackets();
			source_send_newDataPacket();
		}
	}
}

void
More::WaitForReceivingACKpacketsFinishTimerHandler()
{

}

void
More::DectinationACKWaitingTimerHandler()
{
	// this is used by nodes to increase Unack packets
	destination_send_ACKPackets(0);
}

void
More::resetNewPacketTimer()
{
    printf("resetNewPacketTimer\n");
    if(wrNewfTimer.busy())
    {
    	printf("resetNewPacketTimer if\n");
		receiveNewPacketTimer = 0;
		wrNewfTimer.stop();
		printf("resetNewPacketTimer stop\n");
		wrNewfTimer.start(0.00001);
		printf("resetNewPacketTimer start\n");
    }
    else
    {
    	printf("resetNewPacketTimer if else\n");
    	wrNewfTimer.start(0.00001);
    }
    printf("resetNewPacketTimer done\n");
}

void
More::resetDestinationACKTimer(Packet* p)
{

    printf("resetDestinationACKTimer  at index ==%d\n",index);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    struct hdr_cmn* ch = HDR_CMN(p);

    int cur_num = ph->cur_wait_num-1;
    double backtime = cur_num*onePacketSendingDelay;

    if(destionACKTimer.busy())
    {
    	destionACKTimer.stop();
    	destionACKTimer.start(backtime);
    }
    else
    {
    	destionACKTimer.start(backtime);
    }
}



void
More::resetSendTimer()
{
	// after sending packet, how long it need to wait
	int backoff = op.sendTransmissionTime(index);
	double backtime = backoffpacketNum*backoff*onePacketSendingDelay;

    if(wHighpsTimer.busy())
    {
    	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
    			- Scheduler::instance().clock();
    	wHighpsTimer.stop();

    	if(needwait < backtime) wHighpsTimer.start(backtime);
    	else wHighpsTimer.start(needwait);
    }
    else
    {
		wHighpsTimer.start(backtime);
    }
}

void
More::resetOverhearHighPriorityTimer(const Packet* p,int ReceiverIndex)
{
    printf("resetOverhearHighPriorityTimer  at index ==%d\n",index);

    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

    int cur_num = ph->cur_wait_num;

    int backoff = op.getBackoffTime(p,ReceiverIndex);

    double backtime = backoffpacketNum*backoff*onePacketSendingDelay;

    if(wHighpsTimer.busy())
    {
    	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
    	    			- Scheduler::instance().clock();
		wHighpsTimer.stop();
//    	if(needwait < backtime) wHighpsTimer.start(needwait);
//    	else
    	wHighpsTimer.start(backtime);
    }
    else
    {
		wHighpsTimer.start(backtime);
    }
}

void
More::resetHighPriorityTimer(Packet* p,int ReceiverIndex)
{
	// after received packet, how long it needs to wait
    printf("resetHighPriorityTimer  at index ==%d\n",index);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    struct hdr_cmn* ch = HDR_CMN(p);

    int cur_num = ph->cur_wait_num-1;
    int backoff = op.getBackoffTime(p,ReceiverIndex);

    double backtime = backoffpacketNum*backoff*onePacketSendingDelay+
    		cur_num*onePacketSendingDelay;
	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
	    			- Scheduler::instance().clock();

    if(ch->ptype_ == 5)
    {
    	cur_num = 0;
    	if(index == 3)backtime = onePacketSendingDelay*2;//0;//0.002;
    	else if(index == 0)backtime = 0;
    }

    if(wHighpsTimer.busy())
    {

        printf("needwait ==%f\n",needwait);
    	wHighpsTimer.stop();
        wHighpsTimer.start(backtime);
     }
     else
     {
        printf("backtime  =%f\n",backtime);
    	wHighpsTimer.start(backtime);
     }

}



//void
//More::resetTemperorayQueue()
//{
//
//	if(temporaryUnAckedPacketNumberInFirQueue[11]==0){
//
//		for(int i=0;i< 10;i++)
//		{
//			temporaryUnAckedPacketNumberInFirQueue[i] =
//					temporaryUnAckedPacketNumberInQueue[i];
//		}
//		temporaryUnAckedPacketNumberInFirQueue[11]= 1;
//
//	    if(destionACKTimer.busy())
//		{
//	    	printf("timer error---------if--------\n");
//	    	destionACKTimer.stop();
//	    	destionACKTimer.start(0.02);
//	    	destionACKTimer.wftime = 0.02;
//		}
//	    else
//	    {
//	    	destionACKTimer.wftime = 0.02;
//	    	destionACKTimer.start(0.02);
//	    }
//
//	}else if(temporaryUnAckedPacketNumberInSecQueue[11]==0){
//
//		for(int i=0;i< 10;i++)
//		{
//			temporaryUnAckedPacketNumberInSecQueue[i] =
//					temporaryUnAckedPacketNumberInQueue[i];
//		}
//		temporaryUnAckedPacketNumberInSecQueue[11]=1;
//
//	    if(destionACKTimer.busy())
//		{
//	    	double needwait = (destionACKTimer.stime + destionACKTimer.rtime)
//	    		    	    			- Scheduler::instance().clock();
//	    	destionACKTimer.wstime = 0.02-needwait;
//		}
//	    else
//	    {
//	    	printf("timer error---------if-else-------\n");
//	    	destionACKTimer.wftime = 0.02;
//	    	destionACKTimer.start(0.02);
//	    }
//
//
//	}else if(temporaryUnAckedPacketNumberInThirQueue[11]==0){
//
//		for(int i=0;i< 10;i++)
//		{
//			temporaryUnAckedPacketNumberInThirQueue[i] =
//					temporaryUnAckedPacketNumberInQueue[i];
//		}
//		temporaryUnAckedPacketNumberInThirQueue[11]=1;
//
//	    if(destionACKTimer.busy())
//		{
//	    	double needwait = (destionACKTimer.stime + destionACKTimer.rtime)
//	    		    	    			- Scheduler::instance().clock();
//
//	    	destionACKTimer.wttime = 0.02-needwait-destionACKTimer.wstime;
//		}
//	    else
//	    {
//	    	printf("timer error---------if-else-------\n");
//	    	destionACKTimer.wftime = 0.02;
//	    	destionACKTimer.start(0.02);
//	    }
//
//
//	}else{
//		// reset timer and roll back.
//
//	    if(destionACKTimer.busy())
//	    {
//	    	double needwait = (destionACKTimer.stime + destionACKTimer.rtime)
//	    	    			- Scheduler::instance().clock();
//	    	destionACKTimer.stop();
//
//	    	destionACKTimer.wftime = destionACKTimer.wstime - needwait;
//	    	destionACKTimer.wstime = destionACKTimer.wttime - needwait;
//	    	destionACKTimer.wttime = 0.02-(destionACKTimer.wftime+destionACKTimer.wstime);
//
//
//	    	DectinationACKWaitingTimerHandler();
//	    	WaitForHighPrioritySendingTimerHandler();
//	    	destionACKTimer.start(destionACKTimer.wftime);
//	    }
//	    else
//	    {
//	    	printf("timer error----------else-------\n");
//	    	destionACKTimer.start(0.02);
//	    }
//
//	}
//}
//
//void
//More::copyTemporaryQueue(){
//
//	for(int i=0;i< 10;i++)
//	{
//		temporaryUnAckedPacketNumberInQueue[i] =
//				temporaryUnAckedPacketNumberInFirQueue[i];
//	}
//	temporaryUnAckedPacketNumberInFirQueue[11] =
//			temporaryUnAckedPacketNumberInSecQueue[11];
//
//	for(int i=0;i< 10;i++)
//	{
//		temporaryUnAckedPacketNumberInFirQueue[i] =
//				temporaryUnAckedPacketNumberInSecQueue[i];
//	}
//	temporaryUnAckedPacketNumberInSecQueue[11] =
//			temporaryUnAckedPacketNumberInThirQueue[11];
//
//	for(int i=0;i< 10;i++)
//	{
//		temporaryUnAckedPacketNumberInSecQueue[i] =
//				temporaryUnAckedPacketNumberInThirQueue[i];
//		temporaryUnAckedPacketNumberInThirQueue[i] = 0;
//	}
//	temporaryUnAckedPacketNumberInThirQueue[11] = 0;
//}
//
//void
//More::WaitForReceivingNewpacketsFinishTimerHandler()
//{
//    printf("index == %d WaitForReceivingNewpacketsFinishTimerHandler timer expired\n",index);
//    //source_send_dataPackets();
////    if(sendingOrWaitingIndex == 0)
////    {
////    	sendingOrWaitingIndex = 1;
////    } else if (sendingOrWaitingIndex == 1){
////    	sendingOrWaitingIndex = 0;
////    	source_send_newDataPacket();
////    }
//    if(wHighpsTimer.busy())
//    {
//
//    }else{
//    	source_send_newDataPacket();
//    }
////    receiveNewPacketTimer = 1;
////    if(index == 0)
////
////
////    	source_send_dataPackets();
////    else if (index == 2) destination_send_ACKPackets();
////    else intermediates_send_dataPackets();
//}
//
//void
//More::WaitForReceivingACKpacketsFinishTimerHandler()
//{
//	// this function is used by intermediate node to delay the transmission after its recevie new data
//	// packets from upstream nodes
////    if(sendingOrWaitingIndex == 0)
////    {
////    	sendingOrWaitingIndex = 1;
////    } else if (sendingOrWaitingIndex == 1){
////    	sendingOrWaitingIndex = 0;
////    	intermediate_send_newdataPackets();
////    }
//    if(wHighpsTimer.busy())
//    {
//
//    }else{
//    	intermediates_send_dataPackets();
//    	//intermediate_send_newdataPackets();
//    }
//}
//
//void
//More::WaitForHighPrioritySendingTimerHandler()
//{
//	//printf("index == %d WaitForHighPrioritySendingTimerHandler timer expired\n",index);
////    if(sendingOrWaitingIndex == 0)
////    {
////    	sendingOrWaitingIndex = 1;
////    } else if (sendingOrWaitingIndex == 1){
////
////    	sendingOrWaitingIndex = 0;
////
////    	if(index != 0)
////    	{
////    		intermediates_send_dataPackets();
////    	}
////    	else
////    	{
////    		source_send_dataPackets();
////    	}
////    }
//	//source_send_dataPackets();
//
//	if(index != 0)
//	{
//
//		if(index == 1 || index ==2 || index == 4)
//		{
//			printf("WaitForHighPrioritySendingTimerHandler expired at index = %d\n",index);
//		}
//
//	    if(wrAckTimer.busy())
//	    {
//
//	    }else{
//	    	intermediates_send_dataPackets();
//	    	intermediate_send_newdataPackets();
//	    }
//	}
//	else
//	{
//		if(wrNewfTimer.busy())
//		{
//
//		}else{
//			source_send_dataPackets();
//			source_send_newDataPacket();
//		}
//	}
//}
//
//void
//More::DectinationACKWaitingTimerHandler()
//{
//	// this is used by nodes to increase Unack packets
//
////    for(int i=0;i<totalNumberOfGroup;i++)
////    {
////    	unAckedPackeNumberInQueue[i] = temporaryUnAckedPacketNumberInQueue[i];
////    }
//	//copyTemporaryQueue();
//	destination_send_ACKPackets(0);
//}
//
//void
//More::resetNewPacketTimer()
//{
//    printf("resetNewPacketTimer\n");
//    if(wrNewfTimer.busy())
//    {
//    	printf("resetNewPacketTimer if\n");
//		receiveNewPacketTimer = 0;
//		wrNewfTimer.stop();
//		printf("resetNewPacketTimer stop\n");
//		wrNewfTimer.start(0.00001);
//		printf("resetNewPacketTimer start\n");
//    }
//    else
//    {
//    	printf("resetNewPacketTimer if else\n");
//    	wrNewfTimer.start(0.00001);
//    }
//    printf("resetNewPacketTimer done\n");
//}
//
//void
//More::resetSendTimer()
//{
//	// after sending packet, how long it need to wait
//	int backoff = op.sendTransmissionTime(index);
//	double backtime = backoffpacketNum*backoff*onePacketSendingDelay;
//
//    if(wHighpsTimer.busy())
//    {
//    	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
//    			- Scheduler::instance().clock();
//    	wHighpsTimer.stop();
//
//    	if(needwait < backtime) wHighpsTimer.start(backtime);
//    	else wHighpsTimer.start(needwait);
//    }
//    else
//    {
//		wHighpsTimer.start(backtime);
//    }
//}
//
//void
//More::resetOverhearHighPriorityTimer(const Packet* p,int ReceiverIndex)
//{
//    printf("resetOverhearHighPriorityTimer  at index ==%d\n",index);
//
//    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
//
//    int cur_num = ph->cur_wait_num;
//
//    int backoff = op.getBackoffTime(p,ReceiverIndex);
//
//    double backtime = backoffpacketNum*backoff*onePacketSendingDelay;
//
//    if(wHighpsTimer.busy())
//    {
//    	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
//    	    			- Scheduler::instance().clock();
//		wHighpsTimer.stop();
////    	if(needwait < backtime) wHighpsTimer.start(needwait);
////    	else
//    	wHighpsTimer.start(backtime);
//    }
//    else
//    {
//		wHighpsTimer.start(backtime);
//    }
//}
//
//void
//More::resetHighPriorityTimer(Packet* p,int ReceiverIndex)
//{
//	// after received packet, how long it needs to wait
//    printf("resetHighPriorityTimer  at index ==%d\n",index);
//    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
//    struct hdr_cmn* ch = HDR_CMN(p);
//
//    int cur_num = ph->cur_wait_num-1;
//    int backoff = op.getBackoffTime(p,ReceiverIndex);
//
//    double backtime = backoffpacketNum*backoff*onePacketSendingDelay+
//    		cur_num*onePacketSendingDelay;
//	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
//	    			- Scheduler::instance().clock();
//
//    if(ch->ptype_ == 5)
//    {
//    	cur_num = 0;
//    	if(index == 3)backtime = onePacketSendingDelay;//0;//0.002;
//    	else if(index == 0)backtime = 0;
//    }
//
//
////   // receive downstream nodes's packets
////    if(ch->prev_hop_ > ReceiverIndex){
////
////    	double backtime = 0.018;
////        printf("backtime  =%f\n",backtime);
////        //printf("time error  =%f\n",Scheduler::instance().clock());
////        if(wHighpsTimer.busy())
////        {
////
////        	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
////        	    			- Scheduler::instance().clock();
////        	printf("needwait ==%f\n",needwait);
////    		wHighpsTimer.stop();
//////        	if(needwait < backtime) wHighpsTimer.start(needwait);
//////        	else
////        	wHighpsTimer.start(backtime);
////        }
////        else
////        {
////        	printf("backtime  =%f\n",backtime);
////    		wHighpsTimer.start(backtime);
////        }
////
////    }else {
//    	// receive upstream nodes's packets
//
//    if(wHighpsTimer.busy())
//    {
//
//        printf("needwait ==%f\n",needwait);
//    	wHighpsTimer.stop();
//    //    	if(needwait < backtime) wHighpsTimer.start(needwait);
//    //    	else
//        wHighpsTimer.start(backtime);
//     }
//     else
//     {
//        printf("backtime  =%f\n",backtime);
//    	wHighpsTimer.start(backtime);
//     }
//    //}
//}
//
//
////it doesn't use in current project
//void
//More::resetRecevingAckTimer(Packet* p,int ReceiverIndex)
//{
//	// this function is used by intermediate node to delay the transmission
//	//after its recevie new data
//	// packets from upstream nodes
//
//    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
////    struct hdr_cmn* ch = HDR_CMN(p);
////    if(ph->newPacketIndex_ > newpacketRound) newpacketRound = ph->newPacketIndex_;
//    int cur_num = ph->cur_wait_num-1;
//    double backtime = cur_num*onePacketSendingDelay;
//    if(wrAckTimer.busy())
//    {
//    	wrAckTimer.stop();
//    	wrAckTimer.start(backtime);
//    }
//    else
//    {
//    	wrAckTimer.start(backtime);
//    }
//}
//
//void
//More::resetDestinationACKTimer(Packet* p)
//{
//
//    printf("resetDestinationACKTimer  at index ==%d\n",index);
//    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
//    struct hdr_cmn* ch = HDR_CMN(p);
//
//    int cur_num = ph->cur_wait_num-1;
//    double backtime = cur_num*onePacketSendingDelay;
//
//    if(destionACKTimer.busy())
//    {
//    	destionACKTimer.stop();
//    	destionACKTimer.start(backtime);
//    }
//    else
//    {
//    	destionACKTimer.start(backtime);
//    }
//}

//testing function
void
More::printPacketContent(Packet* packetObj)
{
    PacketData* packdata_1 = (PacketData*)packetObj->userdata();

    unsigned char* data_for_add_1 = (unsigned char*)packdata_1->data();

     printf("printPacketContent	 data: ");
     for(int i=0;i<512;i++)
     {
	 if(i <10)printf("%d-",*data_for_add_1);
	data_for_add_1++;
     }
     printf("	encoding vector");
     for(int i=0;i<codeingPacketNumber;i++)
     {
	printf("%d-",*data_for_add_1);
	data_for_add_1++;
     }
     printf("\n");
}

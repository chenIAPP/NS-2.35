/*
 * more_pkt.h
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */

#ifndef MORE_PKT_H_
#define MORE_PKT_H_




#define MORETYPE_HELLO  	0x01
#define MORETYPE_RREQ   	0x02
#define MORETYPE_RREP   	0x04
#define MORETYPE_RERR   	0x08
#define MORETYPE_RREP_ACK  	0x10
#define MORETYPE_DATA	  	0x12

#include <packet.h>

#define HDR_MORE_PKT(p) hdr_more_pkt::access(p)
#define HDR_MORE_REQUEST(p)  	((struct hdr_more_request*)hdr_more_pkt::access(p))
#define HDR_MORE_REPLY(p)	((struct hdr_more_reply*)hdr_more_pkt::access(p))
#define HDR_MORE_ERROR(p)	((struct hdr_more_error*)hdr_more_pkt::access(p))
#define HDR_MORE_RREP_ACK(p)	((struct hdr_more_rrep_ack*)hdr_more_pkt::access(p))

struct hdr_more_pkt {

	u_int8_t        more_type;

	nsaddr_t pkt_src_;  // Node which originated this packet

	u_int16_t pkt_len_; //Packet length (in bytes)

	u_int32_t batchNum;
	int indexforthebatch;
	int indexforFragment;
	int totalFragmentNum;
	int cur_wait_num;
	int currentIndexReceived;

	u_int8_t pkt_num_0;
	u_int8_t pkt_num_1;
	u_int8_t pkt_num_2;
	u_int8_t pkt_num_3;
	u_int8_t pkt_num_4;
	u_int8_t pkt_num_5;
	u_int8_t pkt_num_6;
	u_int8_t pkt_num_7;
	u_int8_t pkt_num_8;
	u_int8_t pkt_num_9;
	u_int8_t pkt_num_10;

	u_int8_t pkt_num_11;
	u_int8_t pkt_num_12;
	u_int8_t pkt_num_13;
	u_int8_t pkt_num_14;
	u_int8_t pkt_num_15;
	u_int8_t pkt_num_16;
	u_int8_t pkt_num_17;
	u_int8_t pkt_num_18;
	u_int8_t pkt_num_19;
	u_int8_t pkt_num_20;

	u_int8_t pkt_num_21;
	u_int8_t pkt_num_22;
	u_int8_t pkt_num_23;
	u_int8_t pkt_num_24;
	u_int8_t pkt_num_25;
	u_int8_t pkt_num_26;
	u_int8_t pkt_num_27;
	u_int8_t pkt_num_28;
	u_int8_t pkt_num_29;
	u_int8_t pkt_num_30;

	u_int8_t pkt_num_31;
	u_int8_t pkt_num_32;
	u_int8_t pkt_num_33;
	u_int8_t pkt_num_34;
	u_int8_t pkt_num_35;
	u_int8_t pkt_num_36;
	u_int8_t pkt_num_37;
	u_int8_t pkt_num_38;
	u_int8_t pkt_num_39;
	u_int8_t pkt_num_40;

	u_int8_t pkt_num_41;
	u_int8_t pkt_num_42;
	u_int8_t pkt_num_43;
	u_int8_t pkt_num_44;
	u_int8_t pkt_num_45;
	u_int8_t pkt_num_46;
	u_int8_t pkt_num_47;
	u_int8_t pkt_num_48;
	u_int8_t pkt_num_49;
	u_int8_t pkt_num_50;

	u_int8_t pkt_num_51;
	u_int8_t pkt_num_52;
	u_int8_t pkt_num_53;
	u_int8_t pkt_num_54;
	u_int8_t pkt_num_55;
	u_int8_t pkt_num_56;
	u_int8_t pkt_num_57;
	u_int8_t pkt_num_58;
	u_int8_t pkt_num_59;
	u_int8_t pkt_num_60;


	u_int8_t pkt_num_61;
	u_int8_t pkt_num_62;
	u_int8_t pkt_num_63;
	u_int8_t pkt_num_64;
	u_int8_t pkt_num_65;
	u_int8_t pkt_num_66;
	u_int8_t pkt_num_67;
	u_int8_t pkt_num_68;
	u_int8_t pkt_num_69;
	u_int8_t pkt_num_70;


	u_int8_t pkt_num_71;
	u_int8_t pkt_num_72;
	u_int8_t pkt_num_73;
	u_int8_t pkt_num_74;
	u_int8_t pkt_num_75;
	u_int8_t pkt_num_76;
	u_int8_t pkt_num_77;
	u_int8_t pkt_num_78;
	u_int8_t pkt_num_79;
	u_int8_t pkt_num_80;


	u_int8_t pkt_num_81;
	u_int8_t pkt_num_82;
	u_int8_t pkt_num_83;
	u_int8_t pkt_num_84;
	u_int8_t pkt_num_85;
	u_int8_t pkt_num_86;
	u_int8_t pkt_num_87;
	u_int8_t pkt_num_88;
	u_int8_t pkt_num_89;
	u_int8_t pkt_num_90;


	u_int8_t pkt_num_91;
	u_int8_t pkt_num_92;
	u_int8_t pkt_num_93;
	u_int8_t pkt_num_94;
	u_int8_t pkt_num_95;
	u_int8_t pkt_num_96;
	u_int8_t pkt_num_97;
	u_int8_t pkt_num_98;
	u_int8_t pkt_num_99;

	static int offset_;

	inline nsaddr_t& pkt_src() {return pkt_src_;}

	inline u_int16_t& pkt_len() { return pkt_len_;}

	inline static int& offset() { return offset_;}

	inline static hdr_more_pkt * access (const Packet*p) {
		return (hdr_more_pkt*) p->access(offset_);
	}

};

struct hdr_more_request {
        u_int8_t        more_type;	// Packet Type
        u_int8_t        reserved[2];
        u_int8_t        rq_hop_count;   // Hop Count
        u_int32_t       rq_bcast_id;    // Broadcast ID

        nsaddr_t        rq_dst;         // Destination IP Address
        u_int32_t       rq_dst_seqno;   // Destination Sequence Number
        nsaddr_t        rq_src;         // Source IP Address
        u_int32_t       rq_src_seqno;   // Source Sequence Number

        double          rq_timestamp;   // when REQUEST sent;
					// used to compute route discovery latency
  inline int size() {
  int sz = 0;
  	sz = 7*sizeof(u_int32_t);
  	assert (sz >= 0);
	return sz;
  }
};

struct hdr_more_reply {
        u_int8_t        more_type;        // Packet Type

        u_int8_t		rp_batch_num;

        u_int8_t		rp_token_num;

        u_int8_t        reserved[2];
        u_int8_t        rp_hop_count;           // Hop Count
        nsaddr_t        rp_dst;                 // Destination IP Address
        u_int32_t       rp_dst_seqno;           // Destination Sequence Number
        nsaddr_t        rp_src;                 // Source IP Address
        double	        rp_lifetime;            // Lifetime

        double          rp_timestamp;           // when corresponding REQ sent;
						// used to compute route discovery latency

  inline int size() {
  int sz = 0;
  	sz = 6*sizeof(u_int32_t);
  	assert (sz >= 0);
	return sz;
  }

};


struct hdr_more_error {
        u_int8_t        more_type;                // Type
        u_int8_t        reserved[2];            // Reserved
        u_int8_t        DestCount;                 // DestCount
        // List of Unreachable destination IP addresses and sequence numbers
        nsaddr_t        unreachable_dst[100];
        u_int32_t       unreachable_dst_seqno[100];

  inline int size() {
  int sz = 0;
  	sz = (DestCount*2 + 1)*sizeof(u_int32_t);
	assert(sz);
        return sz;
  }

};

struct hdr_more_rrep_ack {
	u_int8_t	more_type;
	u_int8_t	reserved;
};

union hdr_all_more {
	hdr_more_pkt          more_data;
	hdr_more_request  more_request;
	hdr_more_reply    more_reply;
	hdr_more_error    more_error;
	hdr_more_rrep_ack more_ack;
};
#endif /* MORE_PKT_H_ */




/*
 * more_batch.h
 *
 *  Created on: 2014-08-25
 *      Author: winemocol
 */


#ifndef MORE_BATCH_H_
#define MORE_BATCH_H_

#include "more_rqueue.h"

class More_batch
{
public:
	More_batch(int size);

	int generation_size;
	int rankOfQueue;
	more_rqueue batch_queue;
};
#endif /* MORE_BATCH_H_ */

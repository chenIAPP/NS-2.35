/*
 * more_timer.h
 *
 *  Created on: 2015-03-18
 *      Author: winemocol
 */
#include "scheduler.h"
#include "more.h"
#ifndef MORE_TIMER_H_
#define MORE_TIMER_H_

class More;


class MoreTimer : public Handler {
public:
    MoreTimer(More* moreObj) : mFender(moreObj) {
		busy_ = paused_ = 0; stime = rtime = 0.0;
	}

	virtual void handle(Event *e) = 0;
	virtual void start(double time);
	virtual void stop(void);
	virtual void pause(void) {  }
	virtual void resume(void) {  }

	inline int busy(void) { return busy_; }
	inline int paused(void) { return paused_; }
	inline double expire(void) {
		return ((stime + rtime) - Scheduler::instance().clock());
	}

public:
	More		*mFender;
	int		busy_;
	int		paused_;
	Event		intr;
	double		stime;	// start time
	double		rtime;	// remaining time

	double		wftime;	// temporary first wait time;
	double		wstime;	// temporary second wait time;
	double		wttime;	// temporary third wait time;
};


//chen ExOR timer begin
class WaitForReceivingNewpacketsFinishTimer : public MoreTimer {
public:
    WaitForReceivingNewpacketsFinishTimer(More* moreObj) : MoreTimer(moreObj) {}

	void	handle(Event *e);
};

class WaitForReceivingACKpacketsFinishTimer : public MoreTimer {
public:
    WaitForReceivingACKpacketsFinishTimer(More* moreObj) : MoreTimer(moreObj) {}

	void	handle(Event *e);
};

class WaitForHighPrioritySendingTimer : public MoreTimer {
public:
    WaitForHighPrioritySendingTimer(More* moreObj) : MoreTimer(moreObj) {}

	void	handle(Event *e);
};

class DectinationACKWaitingTimer : public MoreTimer {
public:
    DectinationACKWaitingTimer(More* moreObj) : MoreTimer(moreObj) {}

	void	handle(Event *e);
};

//chen ExOR timer end

#endif /* MORE_TIMER_H_ */

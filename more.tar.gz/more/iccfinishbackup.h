/*
 * more.h
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */

#ifndef MORE_H_
#define MORE_H_

#include "more_pkt.h" //数据包的头文件
#include "more_rtable.h"
#include "more_nc.h"
#include "more_rqueue.h"
#include "udp.h"
#include <agent.h> //代理基本类
#include <packet.h> //数据包类
#include <trace.h> //跟踪文件的描述类，里面定义了如何显示trace file的内容
#include <timer-handler.h> //计时器基本类，创建我们自定义的计时器
#include <random.h>
#include <classifier-port.h> //端口分类器，具体不清楚 **********
#include "scheduler.h"
#include <mobilenode.h>
#include "arp.h"
#include "ll.h"
#include "mac.h"
#include "ip.h"
#include "delay.h"
#include "more_timer.h"
#include "more_node.h"
#include "more_neighborNode.h"
#include "more_buffer.h"
#include "more_op.h"
#define CURRENT_TIME Scheduler::instance().clock()//定义一个得到当前时间的宏
#define JITTER (Random::uniform()*0.05)//返回一个0-0.5之间的随机数
#define NO_DELAY 0.0
#define HELLO_INTERVAL          1               // 1000 ms

class More;


class More : public Tap, public Agent {
    //default variable and function --begin
public:

	void tap(const Packet *p);

    nsaddr_t ra_addr_;
    more_rtable rtable_;
    int accessible_var_;//用来读取TCL代码或者脚本语言
    nsaddr_t        index;
    Trace* logtarget_;//写跟踪日志
    PortClassifier* dmux_;//把包向上传给agents,是端口分类器

    inline nsaddr_t& ra_addr(){
	    return ra_addr_;
    }

    inline int& accessible_var(){
	    return accessible_var_;
    }

    More(nsaddr_t);

    int command(int,const char*const*);

    void recv(Packet*, Handler*);


    //default variable and function --end

    //---------------------------------------------------------------------------------

    friend class WaitForReceivingNewpacketsFinishTimer;
    friend class WaitForReceivingACKpacketsFinishTimer;
    friend class WaitForHighPrioritySendingTimer;
    friend class DectinationACKWaitingTimer;
    //timer function  and variable begin

    void	WaitForReceivingNewpacketsFinishTimerHandler();
    void	WaitForReceivingACKpacketsFinishTimerHandler();
    void	WaitForHighPrioritySendingTimerHandler();
    void	DectinationACKWaitingTimerHandler();

    void resetNewPacketTimer();
    void resetHighPriorityTimer(Packet* p,int ReceiverIndex);
    void resetOverhearHighPriorityTimer(const Packet* p,int ReceiverIndex);
    void resetSendTimer();
    void resetRecevingAckTimer(Packet* p,int ReceiverIndex);
    void resetDestinationACKTimer(Packet* p);

    WaitForReceivingNewpacketsFinishTimer wrNewfTimer;
    WaitForReceivingACKpacketsFinishTimer wrAckTimer;
    WaitForHighPrioritySendingTimer wHighpsTimer;
    DectinationACKWaitingTimer destionACKTimer;


    //timer function end

    more_rqueue SR_Q;//source receive queue directly get packets from App layer.


	//ExOR required -- begin
    int codeingPacketNumber;
    int totalNumberOfGroup;
    int batchIndex;
    int totalNumberOfCBRPacket;
    int senderSendingIndex;

    int sendingIndex;

    double onePacketSendingDelay;
    double backoffpacketNum;

	//ExOR required -- end


    // more variable and function ---begin
    More_nc networkcoding;
    More_op op;


    int totalSendingPacketNum;
    int newpacketRound;
    int newBatchIndex;
    int destinationReceivedPacketNum;
    int sendingPacketNumberInEachNode;


    u_int8_t source_index;
    u_int8_t destination_index;
    int sourceSendPacketMAXSequence;
    int sourceReceivedMAXACKSequence;
    int sourceReceivedPacketMAXQueueIndex;

    int destinationReceivedPacketMAXSequence;
    int destinationReceivedMaxQueueIndex;

    int receiveNewPacketTimer;
    int	highPriorityNodesTimer;
    int NotSendingPacket;

    // 4 kinds of different parameters
    //int currentRoundValueInQueue[10];
    int receivedNewPacketNumberInQueue[10];
    int unAckedPackeNumberInQueue[10];

    int temporaryUnAckedPacketNumberInQueue[10];
    int temporaryUnAckedPacketNumberInFirQueue[11];
    int temporaryUnAckedPacketNumberInSecQueue[11];
    int temporaryUnAckedPacketNumberInThirQueue[11];

    int receivedPackeNumberInQueue[10];
    int requiredSendingPackeNumberInQueue[10];

    int finishedACKNumInQueue[10];
    int ACkedNumInQueue[10];

    int sendingPackeSequence[10];
    int sendinPacketRoundIndex[10];
    int packetretransmissionIndex;

    Packet* destinationLastReceivedPacket;


    more_rqueue rqueue_0;
    more_rqueue rqueue_1;
    more_rqueue rqueue_2;
    more_rqueue rqueue_3;
    more_rqueue rqueue_4;
    more_rqueue rqueue_5;
    more_rqueue rqueue_6;
    more_rqueue rqueue_7;
    more_rqueue rqueue_8;
    more_rqueue rqueue_9;

    more_rqueue squeue_0;
    more_rqueue squeue_1;
    more_rqueue squeue_2;
    more_rqueue squeue_3;
    more_rqueue squeue_4;
    more_rqueue squeue_5;
    more_rqueue squeue_6;
    more_rqueue squeue_7;
    more_rqueue squeue_8;
    more_rqueue squeue_9;

//test correct index;

    int sendingTestCorrect;
    int recevingTestCorrect;

//ExOR begin

	u_int8_t pkt_num_0;
	u_int8_t pkt_num_1;
	u_int8_t pkt_num_2;
	u_int8_t pkt_num_3;
	u_int8_t pkt_num_4;
	u_int8_t pkt_num_5;
	u_int8_t pkt_num_6;
	u_int8_t pkt_num_7;
	u_int8_t pkt_num_8;
	u_int8_t pkt_num_9;
	u_int8_t pkt_num_10;

	u_int8_t pkt_num_11;
	u_int8_t pkt_num_12;
	u_int8_t pkt_num_13;
	u_int8_t pkt_num_14;
	u_int8_t pkt_num_15;
	u_int8_t pkt_num_16;
	u_int8_t pkt_num_17;
	u_int8_t pkt_num_18;
	u_int8_t pkt_num_19;
	u_int8_t pkt_num_20;

	u_int8_t pkt_num_21;
	u_int8_t pkt_num_22;
	u_int8_t pkt_num_23;
	u_int8_t pkt_num_24;
	u_int8_t pkt_num_25;
	u_int8_t pkt_num_26;
	u_int8_t pkt_num_27;
	u_int8_t pkt_num_28;
	u_int8_t pkt_num_29;
	u_int8_t pkt_num_30;

	u_int8_t pkt_num_31;
	u_int8_t pkt_num_32;
	u_int8_t pkt_num_33;
	u_int8_t pkt_num_34;
	u_int8_t pkt_num_35;
	u_int8_t pkt_num_36;
	u_int8_t pkt_num_37;
	u_int8_t pkt_num_38;
	u_int8_t pkt_num_39;
	u_int8_t pkt_num_40;

	u_int8_t pkt_num_41;
	u_int8_t pkt_num_42;
	u_int8_t pkt_num_43;
	u_int8_t pkt_num_44;
	u_int8_t pkt_num_45;
	u_int8_t pkt_num_46;
	u_int8_t pkt_num_47;
	u_int8_t pkt_num_48;
	u_int8_t pkt_num_49;
	u_int8_t pkt_num_50;

	u_int8_t pkt_num_51;
	u_int8_t pkt_num_52;
	u_int8_t pkt_num_53;
	u_int8_t pkt_num_54;
	u_int8_t pkt_num_55;
	u_int8_t pkt_num_56;
	u_int8_t pkt_num_57;
	u_int8_t pkt_num_58;
	u_int8_t pkt_num_59;
	u_int8_t pkt_num_60;


	u_int8_t pkt_num_61;
	u_int8_t pkt_num_62;
	u_int8_t pkt_num_63;
	u_int8_t pkt_num_64;
	u_int8_t pkt_num_65;
	u_int8_t pkt_num_66;
	u_int8_t pkt_num_67;
	u_int8_t pkt_num_68;
	u_int8_t pkt_num_69;
	u_int8_t pkt_num_70;


	u_int8_t pkt_num_71;
	u_int8_t pkt_num_72;
	u_int8_t pkt_num_73;
	u_int8_t pkt_num_74;
	u_int8_t pkt_num_75;
	u_int8_t pkt_num_76;
	u_int8_t pkt_num_77;
	u_int8_t pkt_num_78;
	u_int8_t pkt_num_79;
	u_int8_t pkt_num_80;


	u_int8_t pkt_num_81;
	u_int8_t pkt_num_82;
	u_int8_t pkt_num_83;
	u_int8_t pkt_num_84;
	u_int8_t pkt_num_85;
	u_int8_t pkt_num_86;
	u_int8_t pkt_num_87;
	u_int8_t pkt_num_88;
	u_int8_t pkt_num_89;
	u_int8_t pkt_num_90;


	u_int8_t pkt_num_91;
	u_int8_t pkt_num_92;
	u_int8_t pkt_num_93;
	u_int8_t pkt_num_94;
	u_int8_t pkt_num_95;
	u_int8_t pkt_num_96;
	u_int8_t pkt_num_97;
	u_int8_t pkt_num_98;
	u_int8_t pkt_num_99;


    void ExOR(Packet* p);

    void OriginalSendACK();
    void OriginalReceive(Packet* p);
    void checkDownstreamNode(Packet* p);

    void Original();
    void OriginalTwoHop(Packet* p);
    void source_receive_dataPackets(Packet* p);
    void source_send_newDataPacket();
    void source_send_dataPackets();
    Packet* source_generate_codedPackets();
    void source_receive_downstream_dataPackets(Packet* p);
    void source_receive_ACKPackets(Packet* p);
    void intermediates_receive_dataPackets(Packet* p);
    void intermediates_send_dataPackets();

    void intermediates_receive_downstream_dataPackets(Packet* p);
    void intermediates_receive_ACKPackets(Packet*p);
    Packet* intermediate_configure_receivedPacketNum_batch(Packet* p);
    void destination_receive_dataPackets(Packet* p);
    void destination_send_ACKPackets(int queueIndex);
    void destination_generate_data(int sequence);

    int ExOR_schedule(int sender, int receiver);

    void updateUnReceivedPacketIndex(Packet* p);
    void resetPktNum();

//ExOR end



//testing function
    void printPacketContent(Packet* packetObj);

    // more variable and function ---end

    // traditional TCP variable and function ---begin

    void traditionalTCP_flow(Packet* p);

    void traditionalSendPacket(Packet* p);

    void traditionalReceiveACK(Packet* p);

    // traditional TCP variable and function ---end
protected:
    Mac *mac_;
};

#endif /* MORE_H_ */

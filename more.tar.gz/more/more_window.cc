/*
 * more_window.cc
 *
 *  Created on: 2014-08-25
 *      Author: winemocol
 */


/*
 * more_timer.cc
 *
 *  Created on: 2015-03-18
 *      Author: winemocol
 */

#include "more_timer.h"

#define ROUND_TIME()	\
	{								\
		assert(slottime);					\
		double rmd = remainder(s.clock() + rtime, slottime);	\
		if(rmd > 0.0)						\
			rtime += (slottime - rmd);			\
		else							\
			rtime += (-rmd);				\
	}


/* ======================================================================
   Timers
   ====================================================================== */

void
MoreTimer::start(double time)
{
	Scheduler &s = Scheduler::instance();
	assert(busy_ == 0);

	busy_ = 1;
	paused_ = 0;
	stime = s.clock();
	rtime = time;
	assert(rtime >= 0.0);
	s.schedule(this, &intr, rtime);
}

void
MoreTimer::stop(void)
{
	Scheduler &s = Scheduler::instance();

	assert(busy_);

	if(paused_ == 0)
		s.cancel(&intr);

	busy_ = 0;
	paused_ = 0;
	stime = 0.0;
	rtime = 0.0;
}


void
WaitForReceivingNewpacketsFinishTimer::handle(Event* e)
{
    busy_ = 0;
    paused_ = 0;
    stime = 0.0;
    rtime = 0.0;

   mFender->WaitForReceivingNewpacketsFinishTimerHandler();
}

void
WaitForReceivingACKpacketsFinishTimer::handle(Event* e)
{
    busy_ = 0;
    paused_ = 0;
    stime = 0.0;
    rtime = 0.0;

   mFender->WaitForReceivingACKpacketsFinishTimerHandler();
}

void
WaitForHighPrioritySendingTimer::handle(Event* e)
{
    busy_ = 0;
    paused_ = 0;
    stime = 0.0;
    rtime = 0.0;

   mFender->WaitForHighPrioritySendingTimerHandler();
}

void
DectinationACKWaitingTimer::handle(Event* e)
{
    busy_ = 0;
    paused_ = 0;
    stime = 0.0;
    rtime = 0.0;

   mFender->DectinationACKWaitingTimerHandler();
}


//chen ExOR timer end

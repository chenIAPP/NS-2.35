/*
 * more.cc
 *
 *  Created on: Feb 13, 2014
 *      Author: chenzhang
 */
#include "more.h"
#include "more_loss.h"
#include "more_pkt.h"
#include <packet.h>
#include <random.h>
#include <cmu-trace.h>
#include <iostream>
#include <stdio.h>
#include <sys/time.h>
#include <random.h>
#define CURRENT_TIME    Scheduler::instance().clock()
int hdr_more_pkt::offset_;

static class MoreHeaderClass : public PacketHeaderClass {
public:

	MoreHeaderClass():PacketHeaderClass("PacketHeader/More",sizeof(hdr_all_more))
	{
		bind_offset(&hdr_more_pkt::offset_);
	}
}class_rtProtoMore_hdr;

static class MoreClass : public TclClass{

public:

	MoreClass():TclClass("Agent/More"){}

	TclObject* create(int argc, const char*const* argv){
		assert(argc ==5);
		return (new More((nsaddr_t) Address ::instance().str2addr(argv[4])));
	}

}class_rtProtoMore;

int
More::command(int argc, const char*const *argv)
{

	if(argc ==2 )
	{
	    if(strcasecmp(argv[1],"start") == 0)
	    {
		return TCL_OK;
	    }
	}
	else if (strcasecmp(argv[1],"print_rtable") == 0)
	{
	    if(logtarget_ != 0)
	    {
		sprintf(logtarget_->pt_->buffer(), "P %f _%d_ Routing Table", CURRENT_TIME, ra_addr());

		logtarget_->pt_->dump();

		rtable_.print(logtarget_);
	    }
	    else{

                    fprintf(stdout, "%f _%d_ If you want to print this routing table "

                    "you must create a trace file in your tcl script", CURRENT_TIME, ra_addr());

		}

	    return TCL_OK;
	}
	else if (argc ==3)
	{
		//Obtatins corresponding dumx to carry packets to upper layers
		if(strcmp(argv[1], "port-dmux") == 0){
            dmux_ = (PortClassifier*)TclObject::lookup(argv[2]);

                  if (dmux_ == 0) {

                      fprintf(stderr, "%s: %s lookup of %s failed\n", __FILE__, argv[1], argv[2]);
                      return TCL_ERROR;
                  }

                  return TCL_OK;
		}

        // Obtains corresponding tracer

        else if (strcmp(argv[1], "log-target") == 0 || strcmp(argv[1], "tracetarget") == 0) {

               logtarget_ = (Trace*)TclObject::lookup(argv[2]);
               if (logtarget_ == 0)return TCL_ERROR;
               return TCL_OK;

        }

        else if(strcmp(argv[1], "drop-target") == 0) {
        int stat = SR_Q.command(argc,argv);
        if (stat != TCL_OK) return stat;
        return Agent::command(argc, argv);
        }

        else if (strcmp(argv[1], "install-tap") == 0) {
        	mac_ = (Mac*)TclObject::lookup(argv[2]);
        	if (mac_ == 0) return TCL_ERROR;
        	mac_->installTap(this);
        	return TCL_OK;
        }
	}
    // Pass the command to the base class

    return Agent::command(argc, argv);
}

void
More::tap(const Packet *p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);



	if(ch->ptype_ == 5 && ch->prev_hop_ > index && ch->next_hop_ != index)
	{
		printf("index==%d---",index);
		printf("type==%d---",ch->ptype_);
		printf("address=dis=%d---",ih->daddr());
		printf("address=sour=%d---",ih->saddr());
		printf("do something here\n");

		printf("do something here 2\n");
		//intermediates_overhear_ACKPackets(p);
		//resetOverhearHighPriorityTimer(p,index);
	}

	//fprintf(stdout,"Node in Promiscuous Mode");
}

More::More(nsaddr_t id) : Agent(PT_MORE),rqueue_0(),rqueue_1(),
			rqueue_2(),rqueue_3(),rqueue_4(),rqueue_5(),rqueue_6(),
			rqueue_7(),rqueue_8(),rqueue_9(),squeue_0(),squeue_1(),
			squeue_2(),squeue_3(),squeue_4(),squeue_5(),squeue_6(),
			squeue_7(),squeue_8(),squeue_9(),
			wrNewfTimer(this),wrAckTimer(this),wHighpsTimer(this),
			destionACKTimer(this){

	bind_bool("accessible_var_",&accessible_var_);

    onePacketSendingDelay = 0.0095;
    backoffpacketNum = 5;
    totalSendingPacketNum = 0;

	ra_addr_= id;
	index = id;
	//ExOR required -- begin
	codeingPacketNumber = 100;
	totalNumberOfGroup = 10;
	batchIndex = 0;
	totalNumberOfCBRPacket = 0;
	senderSendingIndex = 0;
	op.sourceIndex = 0;
	op.destinationIndex = 19;
	newBatchIndex = 0;
	destinationReceivedPacketNum = 0;
	sendingPacketNumberInEachNode = 0;
	resetPktNum();
	//ExOR required -- end
}

void
More::recv(Packet* p, Handler*h)
{
	ExOR(p);
	//Original(p);
	//OriginalTwoHop(p);
	//checkDownstreamNode(p);
}



void
More::checkDownstreamNode(Packet* p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	if(ch->prev_hop_ > index)
	{
		if(wrNewfTimer.busy())
		{
			printf("index == %d-- sending packet number ===%d\n",index,totalSendingPacketNum);
			wrNewfTimer.stop();
		}
	}
	else
	{
		OriginalReceive(p);
	}
}

void
More::OriginalReceive(Packet* p)
{

	if(index ==0){

		if(sendingIndex == 0)
		{
			resetNewPacketTimer();
			sendingIndex++;
		}

	}
	else if(index == 2)
	{
		totalNumberOfCBRPacket++;
		printf("index ===%d   ",index);
		printf("totalNumberOfCBRPacket ===%d\n",totalNumberOfCBRPacket);
		if(totalNumberOfCBRPacket == 1000){

			OriginalSendACK();
			OriginalSendACK();
			OriginalSendACK();

			if(sendingIndex == 0)
			{
				resetNewPacketTimer();
				sendingIndex++;
			}
		}
	}
	else if(index == 5)
	{
		totalNumberOfCBRPacket++;
		printf("index ===%d   ",index);
		printf("totalNumberOfCBRPacket ===%d\n",totalNumberOfCBRPacket);
		if(totalNumberOfCBRPacket == 1000){

			OriginalSendACK();
			OriginalSendACK();
			OriginalSendACK();

			if(sendingIndex == 0)
			{
				resetNewPacketTimer();
				sendingIndex++;
			}
		}
	}
	else if(index == 8)
	{
		totalNumberOfCBRPacket++;
		printf("index ===%d   ",index);
		printf("totalNumberOfCBRPacket ===%d\n",totalNumberOfCBRPacket);
		if(totalNumberOfCBRPacket == 1000){

			OriginalSendACK();
			OriginalSendACK();
			OriginalSendACK();

			if(sendingIndex == 0)
			{
				resetNewPacketTimer();
				sendingIndex++;
			}
		}
	}
	else if(index == 11)
	{
		totalNumberOfCBRPacket++;
		printf("index ===%d   ",index);
		printf("totalNumberOfCBRPacket ===%d\n",totalNumberOfCBRPacket);
		if(totalNumberOfCBRPacket == 1000){

			OriginalSendACK();
			OriginalSendACK();
			OriginalSendACK();

			if(sendingIndex == 0)
			{
				resetNewPacketTimer();
				sendingIndex++;
			}
		}
	}
	else if(index == 14)
	{
		totalNumberOfCBRPacket++;
		printf("index ===%d   ",index);
		printf("totalNumberOfCBRPacket ===%d\n",totalNumberOfCBRPacket);
		if(totalNumberOfCBRPacket == 1000){

			OriginalSendACK();
			OriginalSendACK();
			OriginalSendACK();

			if(sendingIndex == 0)
			{
				resetNewPacketTimer();
				sendingIndex++;
			}
		}
	}
	else if(index == 17)
	{
		totalNumberOfCBRPacket++;
		printf("index ===%d   ",index);
		printf("totalNumberOfCBRPacket ===%d\n",totalNumberOfCBRPacket);
		if(totalNumberOfCBRPacket == 1000){

			OriginalSendACK();
			OriginalSendACK();
			OriginalSendACK();

			if(sendingIndex == 0)
			{
				resetNewPacketTimer();
				sendingIndex++;
			}
		}
	}
	else if(index == 19)
	{
		totalNumberOfCBRPacket++;
		printf("index ===%d   ",index);
		printf("totalNumberOfCBRPacket ===%d\n",totalNumberOfCBRPacket);
		if(totalNumberOfCBRPacket == 1000){
			OriginalSendACK();
			OriginalSendACK();
			OriginalSendACK();

			printf("CURRENT_TIME == %f ---------------------------------------------------------\n",CURRENT_TIME);
			double duringTime = CURRENT_TIME - 5;
			double throughput = 1024*1000*8/duringTime;
			printf("throughput == %f ------------------------------------------------------------\n",throughput);
		}
	}


}

void
More::OriginalSendACK()
{
	Packet* p = allocpkt();
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);
	ch->ptype_ = PT_CBR;
	ch->size() = 50;
	ch->addr_type() = NS_AF_INET;
	ch->direction() = hdr_cmn::DOWN;
    ch->error() = 0;
	ih->saddr() = 0;
	ih->daddr() = 1;
	ih->sport() = 0;
	ih->dport() = 0;
	ih->ttl() = ih->ttl()-1;

	if(index == 19)
	{
		printf("ACKcoming0\n");
		ch->next_hop_ = 17;
		ch->prev_hop_ = 19;
	}
	else if (index == 17)
	{
		printf("ACKcoming3\n");
		ch->next_hop_ = 14;
		ch->prev_hop_ =17;
	}
	else if (index == 14)
	{
		printf("ACKcoming3\n");
		ch->next_hop_ = 11;
		ch->prev_hop_ =14;
	}
	else if (index == 11)
	{
		printf("ACKcoming3\n");
		ch->next_hop_ = 8;
		ch->prev_hop_ =11;
	}
	else if (index == 8)
	{
		printf("ACKcoming3\n");
		ch->next_hop_ = 5;
		ch->prev_hop_ =8;
	}
	else if (index == 5)
	{
		printf("ACKcoming3\n");
		ch->next_hop_ = 2;
		ch->prev_hop_ =5;
	}
	else if (index == 2)
	{
		printf("ACKcoming3\n");
		ch->next_hop_ = 0;
		ch->prev_hop_ =2;
	}
	else
	{
		Packet::free(p);
		return;
	}
	Scheduler::instance().schedule(target_, p,NO_DELAY);
}

//void
//More::OriginalSendACK()
//{
//	Packet* p = allocpkt();
//	struct hdr_cmn* ch = HDR_CMN(p);
//	struct hdr_ip* ih = HDR_IP(p);
//	ch->ptype_ = PT_CBR;
//	ch->size() = 50;
//	ch->addr_type() = NS_AF_INET;
//	ch->direction() = hdr_cmn::DOWN;
//    ch->error() = 0;
//	ih->saddr() = 0;
//	ih->daddr() = 3;
//	ih->sport() = 0;
//	ih->dport() = 0;
//	ih->ttl() = ih->ttl()-1;
//
//	if(index == 7)
//	{
//		printf("ACKcoming0\n");
//		ch->next_hop_ = 5;
//		ch->prev_hop_ = 7;
//	}
//	else if (index == 5)
//	{
//		printf("ACKcoming3\n");
//		ch->next_hop_ = 2;
//		ch->prev_hop_ =5;
//	}
//	else if (index == 2)
//	{
//		printf("ACKcoming3\n");
//		ch->next_hop_ = 0;
//		ch->prev_hop_ =2;
//	}
//	else
//	{
//		Packet::free(p);
//		return;
//	}
//	Scheduler::instance().schedule(target_, p,NO_DELAY);
//}


//void
//More::Original()
//{
//	totalSendingPacketNum++;
//	Packet* p = allocpkt();
//	struct hdr_cmn* ch = HDR_CMN(p);
//	struct hdr_ip* ih = HDR_IP(p);
//	ch->ptype_ = PT_CBR;
//	ch->size() = 1024;
//	ch->addr_type() = NS_AF_INET;
//	ch->direction() = hdr_cmn::DOWN;
//    ch->error() = 0;
//	ih->saddr() = 0;
//	ih->daddr() = 3;
//	ih->sport() = 0;
//	ih->dport() = 0;
//	ih->ttl() = ih->ttl()-1;
//
//	if(index == 0)
//	{
//		printf("coming0\n");
//		ch->next_hop_ = 2;
//		ch->prev_hop_ = 0;
//	}
//	else if (index == 2)
//	{
//		printf("coming3\n");
//		ch->next_hop_ = 5;
//		ch->prev_hop_ = 2;
//	}
//	else if (index == 5)
//	{
//		printf("coming3\n");
//		ch->next_hop_ = 7;
//		ch->prev_hop_ = 0;
//	}
//	else
//	{
//		Packet::free(p);
//		return;
//	}
//
//	Scheduler::instance().schedule(target_, p,NO_DELAY);
//}

void
More::Original()
{
	totalSendingPacketNum++;
	Packet* p = allocpkt();
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);
	ch->ptype_ = PT_CBR;
	ch->size() = 1024;
	ch->addr_type() = NS_AF_INET;
	ch->direction() = hdr_cmn::DOWN;
    ch->error() = 0;
	ih->saddr() = 0;
	ih->daddr() = 3;
	ih->sport() = 0;
	ih->dport() = 0;
	ih->ttl() = ih->ttl()-1;

	if(index == 0)
	{
		printf("coming0\n");
		ch->next_hop_ = 2;
		ch->prev_hop_ = 0;
	}
	else if (index == 2)
	{
		printf("coming3\n");
		ch->next_hop_ = 5;
		ch->prev_hop_ = 2;
	}
	else if (index == 5)
	{
		printf("coming3\n");
		ch->next_hop_ = 8;
		ch->prev_hop_ = 0;
	}
	else if (index == 8)
	{
		printf("coming3\n");
		ch->next_hop_ = 11;
		ch->prev_hop_ = 8;
	}
	else if (index == 11)
	{
		printf("coming3\n");
		ch->next_hop_ = 14;
		ch->prev_hop_ = 11;
	}
	else if (index == 14)
	{
		printf("coming3\n");
		ch->next_hop_ = 17;
		ch->prev_hop_ = 14;
	}
	else if (index == 17)
	{
		printf("coming3\n");
		ch->next_hop_ = 19;
		ch->prev_hop_ = 17;
	}
	else
	{
		Packet::free(p);
		return;
	}

	Scheduler::instance().schedule(target_, p,NO_DELAY);
}



//void
//More::OriginalTwoHop(Packet* p)
//{
//	struct hdr_cmn* ch = HDR_CMN(p);
//	struct hdr_ip* ih = HDR_IP(p);
////	hdr_tcp *tcph = hdr_tcp::access(p);
//	ch->size() = 1024;
//	ch->addr_type() = NS_AF_INET;
//	ih->daddr() = 5;
//	ih->sport() = 0;
//	ih->dport() = 0;
//	ih->ttl() = ih->ttl()-1;
//	ch->direction() = hdr_cmn::DOWN;
//	if(index == 0)
//	{
//		printf("coming0\n");
//		ch->next_hop_ = 2;
//		ch->prev_hop_ = 0;
//	}
//	else if (index == 2)
//	{
//		printf("coming3\n");
//		ch->next_hop_ = 4;
//		ch->prev_hop_ = 2;
//	}
//	else if (index == 4)
//	{
//		ch->next_hop_ = 5;
//		ch->prev_hop_ = 4;
//	}
//	else
//	{
//		Packet::free(p);
//		return;
//	}
//
//	Scheduler::instance().schedule(target_, p,NO_DELAY);
//}


void
More::ExOR(Packet* p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);
	hdr_tcp *tcph = hdr_tcp::access(p);
	ns_addr_t desti = ih->dst_;
	ns_addr_t source= ih->src_;

    if (ih->saddr() == ra_addr()) {
	// If there exists a loop, must drop the packet
       if (ch->num_forwards() > 0)
       {
    	   drop(p, DROP_RTR_ROUTE_LOOP);
    	   return;
       }
    // else if this is a packet I am originating, must add IP header
       else if (ch->num_forwards() == 0)
       {
    	   ch->size() += IP_HDR_LEN;
       }
    }

    printf("TCPFender_flow---------------   ----------   ---------- "
    		" ----------  ------------  ---------  ------------  ---------\n");
    printf("a node receive packets with uid=%d, index=%d, destination port=%d,source port=%d,"
	    "\n",ch->uid_,index,desti.port_,source.port_);
    printf("TCP packet----sequence-%d---packet type-%d--------from %d------------uid=%d--"
	    "------------\n",tcph->seqno(),ch->ptype_,ch->prev_hop_,ch->uid_);

    int state = op.checkstate(p,index);

   printf("state = %d\n",state);
    switch (state)
    {
    	case 0:
    		source_receive_dataPackets(p);
    		break;
    	case 1:
    		source_receive_downstream_dataPackets(p);
    		break;
    	case 2:
    		destination_receive_dataPackets(p);
    		break;
    	case 3:
    		intermediates_receive_dataPackets(p);
    		break;
    	case 4:
    		intermediates_receive_downstream_dataPackets(p);
    		break;
    	case 5:
    		source_receive_ACKPackets(p);
    		break;
    	case 6:
    		intermediates_receive_ACKPackets(p);
    		break;
    }
}

void
More::source_receive_dataPackets(Packet* p)
{
	struct hdr_cmn* ch = HDR_CMN(p);
	//printf("the type of packet == %d\n",ch->ptype_);
	if(senderSendingIndex == 0 )
	{
		source_send_newDataPacket();
		senderSendingIndex++;
	}
	drop(p);
//	totalNumberOfCBRPacket ++ ;
//	printf("-----------------received packet total == %d\n",totalNumberOfCBRPacket);
}

void
More::source_send_newDataPacket()
{
	printf("<-----@@@@@@@@@@@@------>source_");
	printf("index ==%d begin source_send_newDataPacket<------@@@@@@@@@@@@------>\n",index);

	for(int i=0;i<codeingPacketNumber; i++)
	{
		sendingPacketNumberInEachNode++;
		Packet* newpacket = source_generate_codedPackets();
		struct hdr_more_pkt* ph = HDR_MORE_PKT(newpacket);
		ph->indexforthebatch = i;
		ph->indexforFragment = i;
		ph->totalFragmentNum = codeingPacketNumber;
		ph->cur_wait_num = codeingPacketNumber-1-i;
		ph->batchNum = batchIndex;

	    Packet* packet_backoff = newpacket->copy();
	    rqueue_0.enque(packet_backoff);
	    printPacketContent(packet_backoff);

	    struct hdr_cmn* ch = HDR_CMN(newpacket);
		printf("sendingPacketNumberInEachNode------------uid------------%d\n",ch->uid_);

		Scheduler::instance().schedule(target_, newpacket,NO_DELAY);
	}
	printf("sendingPacketNumberInEachNode-----------------source-------%d\n",sendingPacketNumberInEachNode);
	printf("sendingPacketNumberInEachNode--------------index=%d----------%d\n",index,sendingPacketNumberInEachNode);
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}


void
More::source_send_dataPackets()
{
	printf("<-----@@@@@@@@@@@@------>source_");
	printf("index ==%d begin send_dataPackets<------@@@@@@@@@@@@------>\n",index);
	int length = rqueue_0.lenghtofQueue();

	for(int i=0; i<length;i++)
	{
		Packet* PacketInQueue = rqueue_0.deque();
		struct hdr_more_pkt* ph = HDR_MORE_PKT(PacketInQueue);
		if(ph->currentIndexReceived != 1)rqueue_0.enque(PacketInQueue);
	}

	int updatedLength = rqueue_0.lenghtofQueue();


	if(updatedLength < 10)
	{
		batchIndex++;
		newBatchIndex = 1;
		//source_send_newDataPacket();
	    printf("source_send_dataPackets resetHighPriorityTimer  at index ==%d\n",index);


	    int backoff = ExOR_schedule(0,index);

	    double backtime = backoffpacketNum*backoff*onePacketSendingDelay;

	    printf("resetHighPriorityTimer backoff time = %f\n",backtime);

	    printf("CURRENT_TIME == %f resetHighPriorityTimer\n",CURRENT_TIME);

	    if(wHighpsTimer.busy())
	    {
	    	wHighpsTimer.stop();
	        wHighpsTimer.start(backtime);
	     }
	     else
	     {
	    	wHighpsTimer.start(backtime);
	     }
	}
	else {

		for(int i=0;i<updatedLength; i++)
			{

				sendingPacketNumberInEachNode++;

				Packet* PacketInQueue = rqueue_0.deque();
				struct hdr_more_pkt* ph = HDR_MORE_PKT(PacketInQueue);

				ph->indexforFragment = i;
				ph->totalFragmentNum = updatedLength;
				ph->cur_wait_num = updatedLength-1-i;
				ph->batchNum = batchIndex;

			    Packet* packet_backoff = PacketInQueue->copy();
			    rqueue_0.enque(packet_backoff);
			    printPacketContent(packet_backoff);
				Scheduler::instance().schedule(target_, PacketInQueue,NO_DELAY);
			}
	}
	printf("sendingPacketNumberInEachNode--------------index=%d----------%d\n",index,sendingPacketNumberInEachNode);
	printf("sendingPacketNumberInEachNode-----------------source-------%d\n",sendingPacketNumberInEachNode);
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}

Packet*
More::source_generate_codedPackets()
{
    Packet* codedPacket = allocpkt();
    struct hdr_cmn* ch = HDR_CMN(codedPacket);
    struct hdr_ip* ih = HDR_IP(codedPacket);

    ch->ptype_ = PT_CBR;
    ch->direction_ = hdr_cmn::DOWN;;
    ch->size() = 1024;
    ch->error() = 0;
    ch->next_hop() = IP_BROADCAST;
    ch->prev_hop_ = index;
    ch->addr_type() = NS_AF_INET;//NS_AF_ILINK;//

    ih->saddr() = ra_addr();
    ih->daddr() = 19;
    ih->sport() = 0;
    ih->dport() = 0;

    codedPacket->allocdata(512);
    PacketData* packdata = (PacketData*)codedPacket->userdata();
    unsigned char* data_zc = (unsigned char*)packdata->data();
    *data_zc = 65;
    for(int i=0;i <511;i++)
    {
		data_zc++;
		*data_zc = 65;
    }
    return codedPacket;
}

void
More::source_receive_downstream_dataPackets(Packet* p)
{
	printf("-------------------------source_receive_downstream_dataPackets------------------------\n");

	updateUnReceivedPacketIndex(p);

	resetHighPriorityTimer(p,index);

//	int updatedLength = rqueue_0.lenghtofQueue();
//
//	int pkt_num_0 = 0;
//	int pkt_num_1 = 0;
//	int pkt_num_2 = 0;
//	int pkt_num_3 = 0;
//	int pkt_num_4 = 0;
//	int pkt_num_5 = 0;
//	int pkt_num_6 = 0;
//	int pkt_num_7 = 0;
//	int pkt_num_8 = 0;
//	int pkt_num_9 = 0;
//
////	printf("pkt_num_0 %d\n",pkt_num_0);
////	printf("pkt_num_1 %d\n",pkt_num_1);
////	printf("pkt_num_2 %d\n",pkt_num_2);
////	printf("pkt_num_3 %d\n",pkt_num_3);
////	printf("pkt_num_4 %d\n",pkt_num_4);
////	printf("pkt_num_5 %d\n",pkt_num_5);
////	printf("pkt_num_6 %d\n",pkt_num_6);
////	printf("pkt_num_7 %d\n",pkt_num_7);
////	printf("pkt_num_8 %d\n",pkt_num_8);
////	printf("pkt_num_9 %d\n",pkt_num_9);
//
//	struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
//
//	if(ph->pkt_num_0 == 1)pkt_num_0 = 1;
//	if(ph->pkt_num_1 == 1)pkt_num_1 = 1;
//	if(ph->pkt_num_2 == 1)pkt_num_2 = 1;
//	if(ph->pkt_num_3 == 1)pkt_num_3 = 1;
//	if(ph->pkt_num_4 == 1)pkt_num_4 = 1;
//	if(ph->pkt_num_5 == 1)pkt_num_5 = 1;
//	if(ph->pkt_num_6 == 1)pkt_num_6 = 1;
//	if(ph->pkt_num_7 == 1)pkt_num_7 = 1;
//	if(ph->pkt_num_8 == 1)pkt_num_8 = 1;
//	if(ph->pkt_num_9 == 1)pkt_num_9 = 1;
//
//	for(int i=0;i<updatedLength; i++)
//	{
//
//		Packet* PacketInQueue = rqueue_0.deque();
//		struct hdr_more_pkt* ph_queue = HDR_MORE_PKT(PacketInQueue);
//		if(ph_queue->indexforthebatch == 0)ph_queue->currentIndexReceived = pkt_num_0;
//		else if(ph_queue->indexforthebatch == 1)ph_queue->currentIndexReceived = pkt_num_1;
//		else if(ph_queue->indexforthebatch == 2)ph_queue->currentIndexReceived = pkt_num_2;
//		else if(ph_queue->indexforthebatch == 3)ph_queue->currentIndexReceived = pkt_num_3;
//		else if(ph_queue->indexforthebatch == 4)ph_queue->currentIndexReceived = pkt_num_4;
//		else if(ph_queue->indexforthebatch == 5)ph_queue->currentIndexReceived = pkt_num_5;
//		else if(ph_queue->indexforthebatch == 6)ph_queue->currentIndexReceived = pkt_num_6;
//		else if(ph_queue->indexforthebatch == 7)ph_queue->currentIndexReceived = pkt_num_7;
//		else if(ph_queue->indexforthebatch == 8)ph_queue->currentIndexReceived = pkt_num_8;
//		else if(ph_queue->indexforthebatch == 9)ph_queue->currentIndexReceived = pkt_num_9;
//
//		rqueue_0.enque(PacketInQueue);
//	}
////	printf("pkt_num_0 %d\n",pkt_num_0);
////	printf("pkt_num_1 %d\n",pkt_num_1);
////	printf("pkt_num_2 %d\n",pkt_num_2);
////	printf("pkt_num_3 %d\n",pkt_num_3);
////	printf("pkt_num_4 %d\n",pkt_num_4);
////	printf("pkt_num_5 %d\n",pkt_num_5);
////	printf("pkt_num_6 %d\n",pkt_num_6);
////	printf("pkt_num_7 %d\n",pkt_num_7);
////	printf("pkt_num_8 %d\n",pkt_num_8);
////	printf("pkt_num_9 %d\n",pkt_num_9);
//	resetHighPriorityTimer(p,index);
}

void
More::source_receive_ACKPackets(Packet* p)
{
	source_receive_downstream_dataPackets(p);
}



void
More::intermediates_receive_dataPackets(Packet* p)
{
	printf("intermediates_receive_dataPackets -- index--%d",index);

	totalNumberOfCBRPacket ++ ;
	printf("-----------------received packet total == %d\n",totalNumberOfCBRPacket);

	struct hdr_more_pkt* ph_coming = HDR_MORE_PKT(p);
	int roundIndexOfReceivedPacket = ph_coming->batchNum;
	if(batchIndex < roundIndexOfReceivedPacket)
	{
		printf("remove index of packet = %d\n",ph_coming->indexforthebatch);
		batchIndex = roundIndexOfReceivedPacket;
		rqueue_0.remove_all_packet();
		resetPktNum();
	}


	int updatedLength = rqueue_0.lenghtofQueue();
	int newPacket = 0;
	for(int i=0;i<updatedLength; i++)
	{
		Packet* PacketInQueue = rqueue_0.deque();
		struct hdr_more_pkt* ph_queue = HDR_MORE_PKT(PacketInQueue);
		if(ph_coming->indexforthebatch == ph_queue->indexforthebatch)
		{
			newPacket = 1;
		}
		rqueue_0.enque(PacketInQueue);
	}

	if(newPacket == 0)
	{
	    Packet* packet_backoff = p->copy();
	    printf("index of pakcet = %d\n",ph_coming->indexforthebatch);
	    rqueue_0.enque(packet_backoff);
	    printf("rqueue_0.lenghtofQueue() = %d\n",rqueue_0.lenghtofQueue());
	    printPacketContent(packet_backoff);
	}

	resetHighPriorityTimer(p,index);

}


void
More::intermediates_send_dataPackets()
{
	printf("<-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d begin send_dataPackets<------@@@@@@@@@@@@------>\n",index);

	int length = rqueue_0.lenghtofQueue();

	int fragementLength = 0;
	for(int i=0; i<length;i++)
	{
		Packet* PacketInQueue = rqueue_0.deque();
		struct hdr_more_pkt* ph = HDR_MORE_PKT(PacketInQueue);
		if(ph->currentIndexReceived != 1){
			fragementLength++;
		}
		rqueue_0.enque(PacketInQueue);
	}

	int updatedLength = rqueue_0.lenghtofQueue();
	int indexFragement = 0;
	for(int i=0;i<updatedLength; i++)
	{



		Packet* PacketInQueue = rqueue_0.deque();
		struct hdr_more_pkt* ph = HDR_MORE_PKT(PacketInQueue);
		if(ph->currentIndexReceived != 1){
			ph->indexforFragment = indexFragement;
			ph->totalFragmentNum = fragementLength;
			ph->cur_wait_num = fragementLength-1-indexFragement;
			ph->batchNum = batchIndex;
			indexFragement++;
		    Packet* packet_backoff = PacketInQueue->copy();
		    rqueue_0.enque(packet_backoff);

			PacketInQueue = intermediate_configure_receivedPacketNum_batch(PacketInQueue);

		    printPacketContent(packet_backoff);
		    struct hdr_cmn* ch = HDR_CMN(PacketInQueue);
		    printf("sendingPacketNumberInEachNode------------uid------------uid=%d\n",ch->uid_);
		    sendingPacketNumberInEachNode++;
			Scheduler::instance().schedule(target_, PacketInQueue,NO_DELAY);

		}
	}
	printf("fragementLength------------------------%d\n",fragementLength);
	printf("-----------------received packet total == %d\n",totalNumberOfCBRPacket);
	printf("sendingPacketNumberInEachNode--------------index=%d----------%d\n",index,sendingPacketNumberInEachNode);
	printf("<-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d   end send_dataPackets<------@@@@@@@@@@@@------>\n",index);
}

void
More::intermediates_receive_downstream_dataPackets(Packet* p)
{
    // do something when it receives the downstream data;
	printf("----being receive packet ----intermediates_==%d receive_downstream_dataPackets\n",index);

	struct hdr_more_pkt* ph_coming = HDR_MORE_PKT(p);
	int roundIndexOfReceivedPacket = ph_coming->batchNum;
	if(batchIndex > roundIndexOfReceivedPacket)
	{
		printf("---in if\n");
		resetHighPriorityTimer(p,index);
		return;
	}

	updateUnReceivedPacketIndex(p);

	resetHighPriorityTimer(p,index);

}

void
More::intermediates_receive_ACKPackets(Packet*p)
{
    //do something before forward this ACK;
	printf("<ACK-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d begin send_ACKPackets<------@@@@@@@@@@@@------>\n",index);
//
//    intermediates_receive_downstream_dataPackets(p);
//    struct hdr_cmn* ch = HDR_CMN(p);
//    struct hdr_ip* ih = HDR_IP(p);
//    ch->direction() = hdr_cmn::DOWN;
//    ch->prev_hop_ = index;
//    ch->ptype() = PT_ACK;
//    ch->error() = 0;
//    if(index == 3)ch->next_hop() = 1;
//    else if (index == 1)ch->next_hop() = 0;
//    ch->addr_type() = NS_AF_INET;
//    ch->size() = 20+20+20;
//    ih->saddr() = 5;
//    ih->daddr() = 9;
//    ih->sport() = 0;
//    ih->dport() = 0;
//    ih->ttl() = ih->ttl()-1;
//    Scheduler::instance().schedule(target_, p,NO_DELAY);

	printf("<ACK-----@@@@@@@@@@@@------>intermediates_");
	printf("index ==%d   end send_ACKPackets<------@@@@@@@@@@@@------>\n",index);
}

Packet*
More::intermediate_configure_receivedPacketNum_batch(Packet* p)
{
	struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
	struct hdr_cmn* ch = HDR_CMN(p);
	struct hdr_ip* ih = HDR_IP(p);

    ch->ptype_ = PT_CBR;
    ch->direction_ = hdr_cmn::DOWN;;
    ch->size() = 1024;
    ch->error() = 0;
    ch->next_hop() = IP_BROADCAST;
    ch->prev_hop_ = index;
    ch->addr_type() = NS_AF_INET;//NS_AF_ILINK;//

    ih->saddr() = ra_addr();
    ih->daddr() = IP_BROADCAST;
    ih->sport() = 0;
    ih->dport() = 0;


	ph->pkt_num_0 = pkt_num_0;
	ph->pkt_num_1 = pkt_num_1;
	ph->pkt_num_2 = pkt_num_2;
	ph->pkt_num_3 = pkt_num_3;
	ph->pkt_num_4 = pkt_num_4;
	ph->pkt_num_5 = pkt_num_5;
	ph->pkt_num_6 = pkt_num_6;
	ph->pkt_num_7 = pkt_num_7;
	ph->pkt_num_8 = pkt_num_8;
	ph->pkt_num_9 = pkt_num_9;

	ph->pkt_num_10 = pkt_num_10;
	ph->pkt_num_11 = pkt_num_11;
	ph->pkt_num_12 = pkt_num_12;
	ph->pkt_num_13 = pkt_num_13;
	ph->pkt_num_14 = pkt_num_14;
	ph->pkt_num_15 = pkt_num_15;
	ph->pkt_num_16 = pkt_num_16;
	ph->pkt_num_17 = pkt_num_17;
	ph->pkt_num_18 = pkt_num_18;
	ph->pkt_num_19 = pkt_num_19;

	ph->pkt_num_20 = pkt_num_20;
	ph->pkt_num_21 = pkt_num_21;
	ph->pkt_num_22 = pkt_num_22;
	ph->pkt_num_23 = pkt_num_23;
	ph->pkt_num_24 = pkt_num_24;
	ph->pkt_num_25 = pkt_num_25;
	ph->pkt_num_26 = pkt_num_26;
	ph->pkt_num_27 = pkt_num_27;
	ph->pkt_num_28 = pkt_num_28;
	ph->pkt_num_29 = pkt_num_29;

	ph->pkt_num_30 = pkt_num_30;
	ph->pkt_num_31 = pkt_num_31;
	ph->pkt_num_32 = pkt_num_32;
	ph->pkt_num_33 = pkt_num_33;
	ph->pkt_num_34 = pkt_num_34;
	ph->pkt_num_35 = pkt_num_35;
	ph->pkt_num_36 = pkt_num_36;
	ph->pkt_num_37 = pkt_num_37;
	ph->pkt_num_38 = pkt_num_38;
	ph->pkt_num_39 = pkt_num_39;

	ph->pkt_num_40 = pkt_num_40;
	ph->pkt_num_41 = pkt_num_41;
	ph->pkt_num_42 = pkt_num_42;
	ph->pkt_num_43 = pkt_num_43;
	ph->pkt_num_44 = pkt_num_44;
	ph->pkt_num_45 = pkt_num_45;
	ph->pkt_num_46 = pkt_num_46;
	ph->pkt_num_47 = pkt_num_47;
	ph->pkt_num_48 = pkt_num_48;
	ph->pkt_num_49 = pkt_num_49;

	ph->pkt_num_50 = pkt_num_50;
	ph->pkt_num_51 = pkt_num_51;
	ph->pkt_num_52 = pkt_num_52;
	ph->pkt_num_53 = pkt_num_53;
	ph->pkt_num_54 = pkt_num_54;
	ph->pkt_num_55 = pkt_num_55;
	ph->pkt_num_56 = pkt_num_56;
	ph->pkt_num_57 = pkt_num_57;
	ph->pkt_num_58 = pkt_num_58;
	ph->pkt_num_59 = pkt_num_59;

	ph->pkt_num_60 = pkt_num_60;
	ph->pkt_num_61 = pkt_num_61;
	ph->pkt_num_62 = pkt_num_62;
	ph->pkt_num_63 = pkt_num_63;
	ph->pkt_num_64 = pkt_num_64;
	ph->pkt_num_65 = pkt_num_65;
	ph->pkt_num_66 = pkt_num_66;
	ph->pkt_num_67 = pkt_num_67;
	ph->pkt_num_68 = pkt_num_68;
	ph->pkt_num_69 = pkt_num_69;

	ph->pkt_num_70 = pkt_num_70;
	ph->pkt_num_71 = pkt_num_71;
	ph->pkt_num_72 = pkt_num_72;
	ph->pkt_num_73 = pkt_num_73;
	ph->pkt_num_74 = pkt_num_74;
	ph->pkt_num_75 = pkt_num_75;
	ph->pkt_num_76 = pkt_num_76;
	ph->pkt_num_77 = pkt_num_77;
	ph->pkt_num_78 = pkt_num_78;
	ph->pkt_num_79 = pkt_num_79;

	ph->pkt_num_80 = pkt_num_80;
	ph->pkt_num_81 = pkt_num_81;
	ph->pkt_num_82 = pkt_num_82;
	ph->pkt_num_83 = pkt_num_83;
	ph->pkt_num_84 = pkt_num_84;
	ph->pkt_num_85 = pkt_num_85;
	ph->pkt_num_86 = pkt_num_86;
	ph->pkt_num_87 = pkt_num_87;
	ph->pkt_num_88 = pkt_num_88;
	ph->pkt_num_89 = pkt_num_89;

	ph->pkt_num_90 = pkt_num_90;
	ph->pkt_num_91 = pkt_num_91;
	ph->pkt_num_92 = pkt_num_92;
	ph->pkt_num_93 = pkt_num_93;
	ph->pkt_num_94 = pkt_num_94;
	ph->pkt_num_95 = pkt_num_95;
	ph->pkt_num_96 = pkt_num_96;
	ph->pkt_num_97 = pkt_num_97;
	ph->pkt_num_98 = pkt_num_98;
	ph->pkt_num_99 = pkt_num_99;

//	int receivedByCurrent_0 = 0;
//	int receivedByCurrent_1 = 0;
//	int receivedByCurrent_2 = 0;
//	int receivedByCurrent_3 = 0;
//	int receivedByCurrent_4 = 0;
//	int receivedByCurrent_5 = 0;
//	int receivedByCurrent_6 = 0;
//	int receivedByCurrent_7 = 0;
//	int receivedByCurrent_8 = 0;
//	int receivedByCurrent_9 = 0;
//
//
//	int receivedByCurrent_10 = 0;
//	int receivedByCurrent_11 = 0;
//	int receivedByCurrent_12 = 0;
//	int receivedByCurrent_13 = 0;
//	int receivedByCurrent_14 = 0;
//	int receivedByCurrent_15 = 0;
//	int receivedByCurrent_16 = 0;
//	int receivedByCurrent_17 = 0;
//	int receivedByCurrent_18 = 0;
//	int receivedByCurrent_19 = 0;
//
//
//	int receivedByCurrent_20 = 0;
//	int receivedByCurrent_21 = 0;
//	int receivedByCurrent_22 = 0;
//	int receivedByCurrent_23 = 0;
//	int receivedByCurrent_24 = 0;
//	int receivedByCurrent_25 = 0;
//	int receivedByCurrent_26 = 0;
//	int receivedByCurrent_27 = 0;
//	int receivedByCurrent_28 = 0;
//	int receivedByCurrent_29 = 0;
//
//	int receivedByCurrent_30 = 0;
//	int receivedByCurrent_31 = 0;
//	int receivedByCurrent_32 = 0;
//	int receivedByCurrent_33 = 0;
//	int receivedByCurrent_34 = 0;
//	int receivedByCurrent_35 = 0;
//	int receivedByCurrent_36 = 0;
//	int receivedByCurrent_37 = 0;
//	int receivedByCurrent_38 = 0;
//	int receivedByCurrent_39 = 0;
//
//	int receivedByCurrent_40 = 0;
//	int receivedByCurrent_41 = 0;
//	int receivedByCurrent_42 = 0;
//	int receivedByCurrent_43 = 0;
//	int receivedByCurrent_44 = 0;
//	int receivedByCurrent_45 = 0;
//	int receivedByCurrent_46 = 0;
//	int receivedByCurrent_47 = 0;
//	int receivedByCurrent_48 = 0;
//	int receivedByCurrent_49 = 0;
//
//	int receivedByCurrent_50 = 0;
//	int receivedByCurrent_51 = 0;
//	int receivedByCurrent_52 = 0;
//	int receivedByCurrent_53 = 0;
//	int receivedByCurrent_54 = 0;
//	int receivedByCurrent_55 = 0;
//	int receivedByCurrent_56 = 0;
//	int receivedByCurrent_57 = 0;
//	int receivedByCurrent_58 = 0;
//	int receivedByCurrent_59 = 0;
//
//	int receivedByCurrent_60 = 0;
//	int receivedByCurrent_61 = 0;
//	int receivedByCurrent_62 = 0;
//	int receivedByCurrent_63 = 0;
//	int receivedByCurrent_64 = 0;
//	int receivedByCurrent_65 = 0;
//	int receivedByCurrent_66 = 0;
//	int receivedByCurrent_67 = 0;
//	int receivedByCurrent_68 = 0;
//	int receivedByCurrent_69 = 0;
//
//	int receivedByCurrent_70 = 0;
//	int receivedByCurrent_71 = 0;
//	int receivedByCurrent_72 = 0;
//	int receivedByCurrent_73 = 0;
//	int receivedByCurrent_74 = 0;
//	int receivedByCurrent_75 = 0;
//	int receivedByCurrent_76 = 0;
//	int receivedByCurrent_77 = 0;
//	int receivedByCurrent_78 = 0;
//	int receivedByCurrent_79 = 0;
//
//	int receivedByCurrent_80 = 0;
//	int receivedByCurrent_81 = 0;
//	int receivedByCurrent_82 = 0;
//	int receivedByCurrent_83 = 0;
//	int receivedByCurrent_84 = 0;
//	int receivedByCurrent_85 = 0;
//	int receivedByCurrent_86 = 0;
//	int receivedByCurrent_87 = 0;
//	int receivedByCurrent_88 = 0;
//	int receivedByCurrent_89 = 0;
//
//	int receivedByCurrent_90 = 0;
//	int receivedByCurrent_91 = 0;
//	int receivedByCurrent_92 = 0;
//	int receivedByCurrent_93 = 0;
//	int receivedByCurrent_94 = 0;
//	int receivedByCurrent_95 = 0;
//	int receivedByCurrent_96 = 0;
//	int receivedByCurrent_97 = 0;
//	int receivedByCurrent_98 = 0;
//	int receivedByCurrent_99 = 0;


	int updatedLength = rqueue_0.lenghtofQueue();
	for(int i=0;i<updatedLength; i++)
	{
		Packet* PacketInQueue = rqueue_0.deque();
		struct hdr_more_pkt* ph_queue = HDR_MORE_PKT(PacketInQueue);

		if(ph_queue->indexforthebatch == 0)ph->pkt_num_0 = 1;
		else if(ph_queue->indexforthebatch == 1)ph->pkt_num_1 = 1;
		else if(ph_queue->indexforthebatch == 2)ph->pkt_num_2 = 1;
		else if(ph_queue->indexforthebatch == 3)ph->pkt_num_3 = 1;
		else if(ph_queue->indexforthebatch == 4)ph->pkt_num_4 = 1;
		else if(ph_queue->indexforthebatch == 5)ph->pkt_num_5 = 1;
		else if(ph_queue->indexforthebatch == 6)ph->pkt_num_6 = 1;
		else if(ph_queue->indexforthebatch == 7)ph->pkt_num_7 = 1;
		else if(ph_queue->indexforthebatch == 8)ph->pkt_num_8 = 1;
		else if(ph_queue->indexforthebatch == 9)ph->pkt_num_9 = 1;

		else if(ph_queue->indexforthebatch == 10)ph->pkt_num_10 = 1;
		else if(ph_queue->indexforthebatch == 11)ph->pkt_num_11 = 1;
		else if(ph_queue->indexforthebatch == 12)ph->pkt_num_12 = 1;
		else if(ph_queue->indexforthebatch == 13)ph->pkt_num_13 = 1;
		else if(ph_queue->indexforthebatch == 14)ph->pkt_num_14 = 1;
		else if(ph_queue->indexforthebatch == 15)ph->pkt_num_15 = 1;
		else if(ph_queue->indexforthebatch == 16)ph->pkt_num_16 = 1;
		else if(ph_queue->indexforthebatch == 17)ph->pkt_num_17 = 1;
		else if(ph_queue->indexforthebatch == 18)ph->pkt_num_18 = 1;
		else if(ph_queue->indexforthebatch == 19)ph->pkt_num_19 = 1;

		else if(ph_queue->indexforthebatch == 20)ph->pkt_num_20 = 1;
		else if(ph_queue->indexforthebatch == 21)ph->pkt_num_21 = 1;
		else if(ph_queue->indexforthebatch == 22)ph->pkt_num_22 = 1;
		else if(ph_queue->indexforthebatch == 23)ph->pkt_num_23 = 1;
		else if(ph_queue->indexforthebatch == 24)ph->pkt_num_24 = 1;
		else if(ph_queue->indexforthebatch == 25)ph->pkt_num_25 = 1;
		else if(ph_queue->indexforthebatch == 26)ph->pkt_num_26 = 1;
		else if(ph_queue->indexforthebatch == 27)ph->pkt_num_27 = 1;
		else if(ph_queue->indexforthebatch == 28)ph->pkt_num_28 = 1;
		else if(ph_queue->indexforthebatch == 29)ph->pkt_num_29 = 1;

		else if(ph_queue->indexforthebatch == 30)ph->pkt_num_30 = 1;
		else if(ph_queue->indexforthebatch == 31)ph->pkt_num_31 = 1;
		else if(ph_queue->indexforthebatch == 32)ph->pkt_num_32 = 1;
		else if(ph_queue->indexforthebatch == 33)ph->pkt_num_33 = 1;
		else if(ph_queue->indexforthebatch == 34)ph->pkt_num_34 = 1;
		else if(ph_queue->indexforthebatch == 35)ph->pkt_num_35 = 1;
		else if(ph_queue->indexforthebatch == 36)ph->pkt_num_36 = 1;
		else if(ph_queue->indexforthebatch == 37)ph->pkt_num_37 = 1;
		else if(ph_queue->indexforthebatch == 38)ph->pkt_num_38 = 1;
		else if(ph_queue->indexforthebatch == 39)ph->pkt_num_39 = 1;

		else if(ph_queue->indexforthebatch == 40)ph->pkt_num_40 = 1;
		else if(ph_queue->indexforthebatch == 41)ph->pkt_num_41 = 1;
		else if(ph_queue->indexforthebatch == 42)ph->pkt_num_42 = 1;
		else if(ph_queue->indexforthebatch == 43)ph->pkt_num_43 = 1;
		else if(ph_queue->indexforthebatch == 44)ph->pkt_num_44 = 1;
		else if(ph_queue->indexforthebatch == 45)ph->pkt_num_45 = 1;
		else if(ph_queue->indexforthebatch == 46)ph->pkt_num_46 = 1;
		else if(ph_queue->indexforthebatch == 47)ph->pkt_num_47 = 1;
		else if(ph_queue->indexforthebatch == 48)ph->pkt_num_48 = 1;
		else if(ph_queue->indexforthebatch == 49)ph->pkt_num_49 = 1;

		else if(ph_queue->indexforthebatch == 50)ph->pkt_num_50 = 1;
		else if(ph_queue->indexforthebatch == 51)ph->pkt_num_51 = 1;
		else if(ph_queue->indexforthebatch == 52)ph->pkt_num_52 = 1;
		else if(ph_queue->indexforthebatch == 53)ph->pkt_num_53 = 1;
		else if(ph_queue->indexforthebatch == 54)ph->pkt_num_54 = 1;
		else if(ph_queue->indexforthebatch == 55)ph->pkt_num_55 = 1;
		else if(ph_queue->indexforthebatch == 56)ph->pkt_num_56 = 1;
		else if(ph_queue->indexforthebatch == 57)ph->pkt_num_57 = 1;
		else if(ph_queue->indexforthebatch == 58)ph->pkt_num_58 = 1;
		else if(ph_queue->indexforthebatch == 59)ph->pkt_num_59 = 1;

		else if(ph_queue->indexforthebatch == 60)ph->pkt_num_60 = 1;
		else if(ph_queue->indexforthebatch == 61)ph->pkt_num_61 = 1;
		else if(ph_queue->indexforthebatch == 62)ph->pkt_num_62 = 1;
		else if(ph_queue->indexforthebatch == 63)ph->pkt_num_63 = 1;
		else if(ph_queue->indexforthebatch == 64)ph->pkt_num_64 = 1;
		else if(ph_queue->indexforthebatch == 65)ph->pkt_num_65 = 1;
		else if(ph_queue->indexforthebatch == 66)ph->pkt_num_66 = 1;
		else if(ph_queue->indexforthebatch == 67)ph->pkt_num_67 = 1;
		else if(ph_queue->indexforthebatch == 68)ph->pkt_num_68 = 1;
		else if(ph_queue->indexforthebatch == 69)ph->pkt_num_69 = 1;

		else if(ph_queue->indexforthebatch == 70)ph->pkt_num_70 = 1;
		else if(ph_queue->indexforthebatch == 71)ph->pkt_num_71 = 1;
		else if(ph_queue->indexforthebatch == 72)ph->pkt_num_72 = 1;
		else if(ph_queue->indexforthebatch == 73)ph->pkt_num_73 = 1;
		else if(ph_queue->indexforthebatch == 74)ph->pkt_num_74 = 1;
		else if(ph_queue->indexforthebatch == 75)ph->pkt_num_75 = 1;
		else if(ph_queue->indexforthebatch == 76)ph->pkt_num_76 = 1;
		else if(ph_queue->indexforthebatch == 77)ph->pkt_num_77 = 1;
		else if(ph_queue->indexforthebatch == 78)ph->pkt_num_78 = 1;
		else if(ph_queue->indexforthebatch == 79)ph->pkt_num_79 = 1;

		else if(ph_queue->indexforthebatch == 80)ph->pkt_num_80 = 1;
		else if(ph_queue->indexforthebatch == 81)ph->pkt_num_81 = 1;
		else if(ph_queue->indexforthebatch == 82)ph->pkt_num_82 = 1;
		else if(ph_queue->indexforthebatch == 83)ph->pkt_num_83 = 1;
		else if(ph_queue->indexforthebatch == 84)ph->pkt_num_84 = 1;
		else if(ph_queue->indexforthebatch == 85)ph->pkt_num_85 = 1;
		else if(ph_queue->indexforthebatch == 86)ph->pkt_num_86 = 1;
		else if(ph_queue->indexforthebatch == 87)ph->pkt_num_87 = 1;
		else if(ph_queue->indexforthebatch == 88)ph->pkt_num_88 = 1;
		else if(ph_queue->indexforthebatch == 89)ph->pkt_num_89 = 1;

		else if(ph_queue->indexforthebatch == 90)ph->pkt_num_90 = 1;
		else if(ph_queue->indexforthebatch == 91)ph->pkt_num_91 = 1;
		else if(ph_queue->indexforthebatch == 92)ph->pkt_num_92 = 1;
		else if(ph_queue->indexforthebatch == 93)ph->pkt_num_93 = 1;
		else if(ph_queue->indexforthebatch == 94)ph->pkt_num_94 = 1;
		else if(ph_queue->indexforthebatch == 95)ph->pkt_num_95 = 1;
		else if(ph_queue->indexforthebatch == 96)ph->pkt_num_96 = 1;
		else if(ph_queue->indexforthebatch == 97)ph->pkt_num_97 = 1;
		else if(ph_queue->indexforthebatch == 98)ph->pkt_num_98 = 1;
		else if(ph_queue->indexforthebatch == 99)ph->pkt_num_99 = 1;

		rqueue_0.enque(PacketInQueue);
	}

	printf("ph->pkt_num_0=%d\n",ph->pkt_num_0);
	printf("ph->pkt_num_1=%d\n",ph->pkt_num_1);
	printf("ph->pkt_num_2=%d\n",ph->pkt_num_2);
	printf("ph->pkt_num_3=%d\n",ph->pkt_num_3);
	printf("ph->pkt_num_4=%d\n",ph->pkt_num_4);
	printf("ph->pkt_num_5=%d\n",ph->pkt_num_5);
	printf("ph->pkt_num_6=%d\n",ph->pkt_num_6);
	printf("ph->pkt_num_7=%d\n",ph->pkt_num_7);
	printf("ph->pkt_num_8=%d\n",ph->pkt_num_8);
	printf("ph->pkt_num_9=%d\n",ph->pkt_num_9);
	printf("ph->pkt_num_10=%d\n",ph->pkt_num_10);


	return p;
}





void
More::destination_receive_dataPackets(Packet* p)
{
	printf("<-----############------>destination_");
	struct hdr_more_pkt* ph_coming = HDR_MORE_PKT(p);

	int roundIndexOfReceivedPacket = ph_coming->batchNum;
	if(batchIndex < roundIndexOfReceivedPacket)
	{
		batchIndex = roundIndexOfReceivedPacket;
		rqueue_0.remove_all_packet();
		resetPktNum();
	}

	int updatedLength = rqueue_0.lenghtofQueue();
	int newPacket = 0;
	for(int i=0;i<updatedLength; i++)
	{
		Packet* PacketInQueue = rqueue_0.deque();
		struct hdr_more_pkt* ph_queue = HDR_MORE_PKT(PacketInQueue);
		if(ph_coming->indexforthebatch == ph_queue->indexforthebatch)
		{
			newPacket = 1;
		}
		rqueue_0.enque(PacketInQueue);
	}

	if(newPacket == 0)
	{
		destinationReceivedPacketNum++;
	    Packet* packet_backoff = p->copy();
	    rqueue_0.enque(packet_backoff);
	    //destination_generate_data(0);
	    printPacketContent(packet_backoff);
	}
	printf("destinationReceivedPacketNum ===---===%d\n",destinationReceivedPacketNum);
	if(destinationReceivedPacketNum==200)
	{
		printf("CURRENT_TIME == %f ---------------------------6666666666666666666666666666----------------"
				"------------------------------------------------------------\n",CURRENT_TIME);
		double duringTime = CURRENT_TIME - 5;
		double throughput = 1024*1000*8/duringTime;
		printf("throughput == %f ----------------------------------666666666666666666666-------------"
				"----------------------------------------------------------\n",throughput);
	}
	resetHighPriorityTimer(p,index);
	printf("index ==%d   end receive_dataPackets<------############------>\n",index);
}


void
More::destination_send_ACKPackets(int queueIndex)
{
	printf("<-----############------>destination_send_ACKPackets\n");

    Packet* ack = allocpkt();

	struct hdr_more_pkt* ph = HDR_MORE_PKT(ack);
	ph->batchNum = batchIndex;

    ack = intermediate_configure_receivedPacketNum_batch(ack);
    // add received packets information
//    struct hdr_cmn* ch = HDR_CMN(ack);
//    struct hdr_ip* ih = HDR_IP(ack);
//    struct hdr_more_pkt* ph = HDR_MORE_PKT(ack);
//    ph->pkt_src() = ra_addr();
//    ph->batchNum = batchIndex;
//    ch->direction() = hdr_cmn::DOWN;
//    ch->prev_hop_ = index;
//    ch->ptype() = PT_CBR;
//    ch->error() = 0;
//    ch->next_hop() = IP_BROADCAST;
//    ch->addr_type() = NS_AF_INET;
//    ch->size() = 20+20+20;
//    ih->saddr() = 5;
//    ih->daddr() = 0;
//    ih->sport() = 0;
//    ih->dport() = 0;
//    ih->ttl() = ih->ttl()-1;

    struct hdr_cmn* ch = HDR_CMN(ack);
    printf("<ACK-----@@@@@@@@@@@@------>uid==%d\n",ch->uid_);
    Scheduler::instance().schedule(target_, ack,NO_DELAY);
	printf("<ACK-----@@@@@@@@@@@@------>destination_");
	printf("index ==%d   end send_ACKPackets<------@@@@@@@@@@@@------>\n",index);

}

void
More::destination_generate_data(int sequence)
{
    Packet* data = allocpkt();
    struct hdr_cmn* ch = HDR_CMN(data);
    struct hdr_ip* ih = HDR_IP(data);
    //struct hdr_cbr* ih = HDR_CBR(data);
    ch->direction() = hdr_cmn::UP;
    ch->prev_hop_ = index;
    ch->ptype() = PT_CBR;
    ch->error() = 0;
    ch->addr_type() = NS_AF_INET;
    ch->size() = 20+20+20;//ip,tcp.more
    ih->saddr() = 0;
    ih->daddr() = 19;
    ih->sport() = 0;
    ih->dport() = 0;
    ih->ttl() = ih->ttl()-1;
    Scheduler::instance().schedule(target_,data,NO_DELAY);
}


void
More::updateUnReceivedPacketIndex(Packet* p)
{
	struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

	if(ph->pkt_num_0 == 1)pkt_num_0 = 1;
	if(ph->pkt_num_1 == 1)pkt_num_1 = 1;
	if(ph->pkt_num_2 == 1)pkt_num_2 = 1;
	if(ph->pkt_num_3 == 1)pkt_num_3 = 1;
	if(ph->pkt_num_4 == 1)pkt_num_4 = 1;
	if(ph->pkt_num_5 == 1)pkt_num_5 = 1;
	if(ph->pkt_num_6 == 1)pkt_num_6 = 1;
	if(ph->pkt_num_7 == 1)pkt_num_7 = 1;
	if(ph->pkt_num_8 == 1)pkt_num_8 = 1;
	if(ph->pkt_num_9 == 1)pkt_num_9 = 1;

	if(ph->pkt_num_10 == 1)pkt_num_10 = 1;
	if(ph->pkt_num_11 == 1)pkt_num_11 = 1;
	if(ph->pkt_num_12 == 1)pkt_num_12 = 1;
	if(ph->pkt_num_13 == 1)pkt_num_13 = 1;
	if(ph->pkt_num_14 == 1)pkt_num_14 = 1;
	if(ph->pkt_num_15 == 1)pkt_num_15 = 1;
	if(ph->pkt_num_16 == 1)pkt_num_16 = 1;
	if(ph->pkt_num_17 == 1)pkt_num_17 = 1;
	if(ph->pkt_num_18 == 1)pkt_num_18 = 1;
	if(ph->pkt_num_19 == 1)pkt_num_19 = 1;

	if(ph->pkt_num_20 == 1)pkt_num_20 = 1;
	if(ph->pkt_num_21 == 1)pkt_num_21 = 1;
	if(ph->pkt_num_22 == 1)pkt_num_22 = 1;
	if(ph->pkt_num_23 == 1)pkt_num_23 = 1;
	if(ph->pkt_num_24 == 1)pkt_num_24 = 1;
	if(ph->pkt_num_25 == 1)pkt_num_25 = 1;
	if(ph->pkt_num_26 == 1)pkt_num_26 = 1;
	if(ph->pkt_num_27 == 1)pkt_num_27 = 1;
	if(ph->pkt_num_28 == 1)pkt_num_28 = 1;
	if(ph->pkt_num_29 == 1)pkt_num_29 = 1;

	if(ph->pkt_num_30 == 1)pkt_num_30 = 1;
	if(ph->pkt_num_31 == 1)pkt_num_31 = 1;
	if(ph->pkt_num_32 == 1)pkt_num_32 = 1;
	if(ph->pkt_num_33 == 1)pkt_num_33 = 1;
	if(ph->pkt_num_34 == 1)pkt_num_34 = 1;
	if(ph->pkt_num_35 == 1)pkt_num_35 = 1;
	if(ph->pkt_num_36 == 1)pkt_num_36 = 1;
	if(ph->pkt_num_37 == 1)pkt_num_37 = 1;
	if(ph->pkt_num_38 == 1)pkt_num_38 = 1;
	if(ph->pkt_num_39 == 1)pkt_num_39 = 1;

	if(ph->pkt_num_40 == 1)pkt_num_40 = 1;
	if(ph->pkt_num_41 == 1)pkt_num_41 = 1;
	if(ph->pkt_num_42 == 1)pkt_num_42 = 1;
	if(ph->pkt_num_43 == 1)pkt_num_43 = 1;
	if(ph->pkt_num_44 == 1)pkt_num_44 = 1;
	if(ph->pkt_num_45 == 1)pkt_num_45 = 1;
	if(ph->pkt_num_46 == 1)pkt_num_46 = 1;
	if(ph->pkt_num_47 == 1)pkt_num_47 = 1;
	if(ph->pkt_num_48 == 1)pkt_num_48 = 1;
	if(ph->pkt_num_49 == 1)pkt_num_49 = 1;

	if(ph->pkt_num_50 == 1)pkt_num_50 = 1;
	if(ph->pkt_num_51 == 1)pkt_num_51 = 1;
	if(ph->pkt_num_52 == 1)pkt_num_52 = 1;
	if(ph->pkt_num_53 == 1)pkt_num_53 = 1;
	if(ph->pkt_num_54 == 1)pkt_num_54 = 1;
	if(ph->pkt_num_55 == 1)pkt_num_55 = 1;
	if(ph->pkt_num_56 == 1)pkt_num_56 = 1;
	if(ph->pkt_num_57 == 1)pkt_num_57 = 1;
	if(ph->pkt_num_58 == 1)pkt_num_58 = 1;
	if(ph->pkt_num_59 == 1)pkt_num_59 = 1;

	if(ph->pkt_num_60 == 1)pkt_num_60 = 1;
	if(ph->pkt_num_61 == 1)pkt_num_61 = 1;
	if(ph->pkt_num_62 == 1)pkt_num_62 = 1;
	if(ph->pkt_num_63 == 1)pkt_num_63 = 1;
	if(ph->pkt_num_64 == 1)pkt_num_64 = 1;
	if(ph->pkt_num_65 == 1)pkt_num_65 = 1;
	if(ph->pkt_num_66 == 1)pkt_num_66 = 1;
	if(ph->pkt_num_67 == 1)pkt_num_67 = 1;
	if(ph->pkt_num_68 == 1)pkt_num_68 = 1;
	if(ph->pkt_num_69 == 1)pkt_num_69 = 1;

	if(ph->pkt_num_70 == 1)pkt_num_70 = 1;
	if(ph->pkt_num_71 == 1)pkt_num_71 = 1;
	if(ph->pkt_num_72 == 1)pkt_num_72 = 1;
	if(ph->pkt_num_73 == 1)pkt_num_73 = 1;
	if(ph->pkt_num_74 == 1)pkt_num_74 = 1;
	if(ph->pkt_num_75 == 1)pkt_num_75 = 1;
	if(ph->pkt_num_76 == 1)pkt_num_76 = 1;
	if(ph->pkt_num_77 == 1)pkt_num_77 = 1;
	if(ph->pkt_num_78 == 1)pkt_num_78 = 1;
	if(ph->pkt_num_79 == 1)pkt_num_79 = 1;

	if(ph->pkt_num_80 == 1)pkt_num_80 = 1;
	if(ph->pkt_num_81 == 1)pkt_num_81 = 1;
	if(ph->pkt_num_82 == 1)pkt_num_82 = 1;
	if(ph->pkt_num_83 == 1)pkt_num_83 = 1;
	if(ph->pkt_num_84 == 1)pkt_num_84 = 1;
	if(ph->pkt_num_85 == 1)pkt_num_85 = 1;
	if(ph->pkt_num_86 == 1)pkt_num_86 = 1;
	if(ph->pkt_num_87 == 1)pkt_num_87 = 1;
	if(ph->pkt_num_88 == 1)pkt_num_88 = 1;
	if(ph->pkt_num_89 == 1)pkt_num_89 = 1;

	if(ph->pkt_num_90 == 1)pkt_num_90 = 1;
	if(ph->pkt_num_91 == 1)pkt_num_91 = 1;
	if(ph->pkt_num_92 == 1)pkt_num_92 = 1;
	if(ph->pkt_num_93 == 1)pkt_num_93 = 1;
	if(ph->pkt_num_94 == 1)pkt_num_94 = 1;
	if(ph->pkt_num_95 == 1)pkt_num_95 = 1;
	if(ph->pkt_num_96 == 1)pkt_num_96 = 1;
	if(ph->pkt_num_97 == 1)pkt_num_97 = 1;
	if(ph->pkt_num_98 == 1)pkt_num_98 = 1;
	if(ph->pkt_num_99 == 1)pkt_num_99 = 1;

	int updatedLength = rqueue_0.lenghtofQueue();
	for(int i=0;i<updatedLength; i++)
	{
		Packet* PacketInQueue = rqueue_0.deque();
		struct hdr_more_pkt* ph_queue = HDR_MORE_PKT(PacketInQueue);

		if(ph_queue->indexforthebatch == 0)ph_queue->currentIndexReceived = pkt_num_0;
		else if(ph_queue->indexforthebatch == 1)ph_queue->currentIndexReceived = pkt_num_1;
		else if(ph_queue->indexforthebatch == 2)ph_queue->currentIndexReceived = pkt_num_2;
		else if(ph_queue->indexforthebatch == 3)ph_queue->currentIndexReceived = pkt_num_3;
		else if(ph_queue->indexforthebatch == 4)ph_queue->currentIndexReceived = pkt_num_4;
		else if(ph_queue->indexforthebatch == 5)ph_queue->currentIndexReceived = pkt_num_5;
		else if(ph_queue->indexforthebatch == 6)ph_queue->currentIndexReceived = pkt_num_6;
		else if(ph_queue->indexforthebatch == 7)ph_queue->currentIndexReceived = pkt_num_7;
		else if(ph_queue->indexforthebatch == 8)ph_queue->currentIndexReceived = pkt_num_8;
		else if(ph_queue->indexforthebatch == 9)ph_queue->currentIndexReceived = pkt_num_9;

		else if(ph_queue->indexforthebatch == 10)ph_queue->currentIndexReceived = pkt_num_10;
		else if(ph_queue->indexforthebatch == 11)ph_queue->currentIndexReceived = pkt_num_11;
		else if(ph_queue->indexforthebatch == 12)ph_queue->currentIndexReceived = pkt_num_12;
		else if(ph_queue->indexforthebatch == 13)ph_queue->currentIndexReceived = pkt_num_13;
		else if(ph_queue->indexforthebatch == 14)ph_queue->currentIndexReceived = pkt_num_14;
		else if(ph_queue->indexforthebatch == 15)ph_queue->currentIndexReceived = pkt_num_15;
		else if(ph_queue->indexforthebatch == 16)ph_queue->currentIndexReceived = pkt_num_16;
		else if(ph_queue->indexforthebatch == 17)ph_queue->currentIndexReceived = pkt_num_17;
		else if(ph_queue->indexforthebatch == 18)ph_queue->currentIndexReceived = pkt_num_18;
		else if(ph_queue->indexforthebatch == 19)ph_queue->currentIndexReceived = pkt_num_19;

		else if(ph_queue->indexforthebatch == 20)ph_queue->currentIndexReceived = pkt_num_20;
		else if(ph_queue->indexforthebatch == 21)ph_queue->currentIndexReceived = pkt_num_21;
		else if(ph_queue->indexforthebatch == 22)ph_queue->currentIndexReceived = pkt_num_22;
		else if(ph_queue->indexforthebatch == 23)ph_queue->currentIndexReceived = pkt_num_23;
		else if(ph_queue->indexforthebatch == 24)ph_queue->currentIndexReceived = pkt_num_24;
		else if(ph_queue->indexforthebatch == 25)ph_queue->currentIndexReceived = pkt_num_25;
		else if(ph_queue->indexforthebatch == 26)ph_queue->currentIndexReceived = pkt_num_26;
		else if(ph_queue->indexforthebatch == 27)ph_queue->currentIndexReceived = pkt_num_27;
		else if(ph_queue->indexforthebatch == 28)ph_queue->currentIndexReceived = pkt_num_28;
		else if(ph_queue->indexforthebatch == 29)ph_queue->currentIndexReceived = pkt_num_29;

		else if(ph_queue->indexforthebatch == 30)ph_queue->currentIndexReceived = pkt_num_30;
		else if(ph_queue->indexforthebatch == 31)ph_queue->currentIndexReceived = pkt_num_31;
		else if(ph_queue->indexforthebatch == 32)ph_queue->currentIndexReceived = pkt_num_32;
		else if(ph_queue->indexforthebatch == 33)ph_queue->currentIndexReceived = pkt_num_33;
		else if(ph_queue->indexforthebatch == 34)ph_queue->currentIndexReceived = pkt_num_34;
		else if(ph_queue->indexforthebatch == 35)ph_queue->currentIndexReceived = pkt_num_35;
		else if(ph_queue->indexforthebatch == 36)ph_queue->currentIndexReceived = pkt_num_36;
		else if(ph_queue->indexforthebatch == 37)ph_queue->currentIndexReceived = pkt_num_37;
		else if(ph_queue->indexforthebatch == 38)ph_queue->currentIndexReceived = pkt_num_38;
		else if(ph_queue->indexforthebatch == 39)ph_queue->currentIndexReceived = pkt_num_39;

		else if(ph_queue->indexforthebatch == 40)ph_queue->currentIndexReceived = pkt_num_40;
		else if(ph_queue->indexforthebatch == 41)ph_queue->currentIndexReceived = pkt_num_41;
		else if(ph_queue->indexforthebatch == 42)ph_queue->currentIndexReceived = pkt_num_42;
		else if(ph_queue->indexforthebatch == 43)ph_queue->currentIndexReceived = pkt_num_43;
		else if(ph_queue->indexforthebatch == 44)ph_queue->currentIndexReceived = pkt_num_44;
		else if(ph_queue->indexforthebatch == 45)ph_queue->currentIndexReceived = pkt_num_45;
		else if(ph_queue->indexforthebatch == 46)ph_queue->currentIndexReceived = pkt_num_46;
		else if(ph_queue->indexforthebatch == 47)ph_queue->currentIndexReceived = pkt_num_47;
		else if(ph_queue->indexforthebatch == 48)ph_queue->currentIndexReceived = pkt_num_48;
		else if(ph_queue->indexforthebatch == 49)ph_queue->currentIndexReceived = pkt_num_49;

		else if(ph_queue->indexforthebatch == 50)ph_queue->currentIndexReceived = pkt_num_50;
		else if(ph_queue->indexforthebatch == 51)ph_queue->currentIndexReceived = pkt_num_51;
		else if(ph_queue->indexforthebatch == 52)ph_queue->currentIndexReceived = pkt_num_52;
		else if(ph_queue->indexforthebatch == 53)ph_queue->currentIndexReceived = pkt_num_53;
		else if(ph_queue->indexforthebatch == 54)ph_queue->currentIndexReceived = pkt_num_54;
		else if(ph_queue->indexforthebatch == 55)ph_queue->currentIndexReceived = pkt_num_55;
		else if(ph_queue->indexforthebatch == 56)ph_queue->currentIndexReceived = pkt_num_56;
		else if(ph_queue->indexforthebatch == 57)ph_queue->currentIndexReceived = pkt_num_57;
		else if(ph_queue->indexforthebatch == 58)ph_queue->currentIndexReceived = pkt_num_58;
		else if(ph_queue->indexforthebatch == 59)ph_queue->currentIndexReceived = pkt_num_59;

		else if(ph_queue->indexforthebatch == 60)ph_queue->currentIndexReceived = pkt_num_60;
		else if(ph_queue->indexforthebatch == 61)ph_queue->currentIndexReceived = pkt_num_61;
		else if(ph_queue->indexforthebatch == 62)ph_queue->currentIndexReceived = pkt_num_62;
		else if(ph_queue->indexforthebatch == 63)ph_queue->currentIndexReceived = pkt_num_63;
		else if(ph_queue->indexforthebatch == 64)ph_queue->currentIndexReceived = pkt_num_64;
		else if(ph_queue->indexforthebatch == 65)ph_queue->currentIndexReceived = pkt_num_65;
		else if(ph_queue->indexforthebatch == 66)ph_queue->currentIndexReceived = pkt_num_66;
		else if(ph_queue->indexforthebatch == 67)ph_queue->currentIndexReceived = pkt_num_67;
		else if(ph_queue->indexforthebatch == 68)ph_queue->currentIndexReceived = pkt_num_68;
		else if(ph_queue->indexforthebatch == 69)ph_queue->currentIndexReceived = pkt_num_69;

		else if(ph_queue->indexforthebatch == 70)ph_queue->currentIndexReceived = pkt_num_70;
		else if(ph_queue->indexforthebatch == 71)ph_queue->currentIndexReceived = pkt_num_71;
		else if(ph_queue->indexforthebatch == 72)ph_queue->currentIndexReceived = pkt_num_72;
		else if(ph_queue->indexforthebatch == 73)ph_queue->currentIndexReceived = pkt_num_73;
		else if(ph_queue->indexforthebatch == 74)ph_queue->currentIndexReceived = pkt_num_74;
		else if(ph_queue->indexforthebatch == 75)ph_queue->currentIndexReceived = pkt_num_75;
		else if(ph_queue->indexforthebatch == 76)ph_queue->currentIndexReceived = pkt_num_76;
		else if(ph_queue->indexforthebatch == 77)ph_queue->currentIndexReceived = pkt_num_77;
		else if(ph_queue->indexforthebatch == 78)ph_queue->currentIndexReceived = pkt_num_78;
		else if(ph_queue->indexforthebatch == 79)ph_queue->currentIndexReceived = pkt_num_79;

		else if(ph_queue->indexforthebatch == 80)ph_queue->currentIndexReceived = pkt_num_80;
		else if(ph_queue->indexforthebatch == 81)ph_queue->currentIndexReceived = pkt_num_81;
		else if(ph_queue->indexforthebatch == 82)ph_queue->currentIndexReceived = pkt_num_82;
		else if(ph_queue->indexforthebatch == 83)ph_queue->currentIndexReceived = pkt_num_83;
		else if(ph_queue->indexforthebatch == 84)ph_queue->currentIndexReceived = pkt_num_84;
		else if(ph_queue->indexforthebatch == 85)ph_queue->currentIndexReceived = pkt_num_85;
		else if(ph_queue->indexforthebatch == 86)ph_queue->currentIndexReceived = pkt_num_86;
		else if(ph_queue->indexforthebatch == 87)ph_queue->currentIndexReceived = pkt_num_87;
		else if(ph_queue->indexforthebatch == 88)ph_queue->currentIndexReceived = pkt_num_88;
		else if(ph_queue->indexforthebatch == 89)ph_queue->currentIndexReceived = pkt_num_89;

		else if(ph_queue->indexforthebatch == 90)ph_queue->currentIndexReceived = pkt_num_90;
		else if(ph_queue->indexforthebatch == 91)ph_queue->currentIndexReceived = pkt_num_91;
		else if(ph_queue->indexforthebatch == 92)ph_queue->currentIndexReceived = pkt_num_92;
		else if(ph_queue->indexforthebatch == 93)ph_queue->currentIndexReceived = pkt_num_93;
		else if(ph_queue->indexforthebatch == 94)ph_queue->currentIndexReceived = pkt_num_94;
		else if(ph_queue->indexforthebatch == 95)ph_queue->currentIndexReceived = pkt_num_95;
		else if(ph_queue->indexforthebatch == 96)ph_queue->currentIndexReceived = pkt_num_96;
		else if(ph_queue->indexforthebatch == 97)ph_queue->currentIndexReceived = pkt_num_97;
		else if(ph_queue->indexforthebatch == 98)ph_queue->currentIndexReceived = pkt_num_98;
		else if(ph_queue->indexforthebatch == 99)ph_queue->currentIndexReceived = pkt_num_99;

		rqueue_0.enque(PacketInQueue);
	}

}

void
More::resetPktNum()
{
	 pkt_num_0 = 0;
	 pkt_num_1 = 0;
	 pkt_num_2 = 0;
	 pkt_num_3 = 0;
	 pkt_num_4 = 0;
	 pkt_num_5 = 0;
	 pkt_num_6 = 0;
	 pkt_num_7 = 0;
	 pkt_num_8 = 0;
	 pkt_num_9 = 0;
	 pkt_num_10 = 0;

	 pkt_num_11 = 0;
	 pkt_num_12 = 0;
	 pkt_num_13 = 0;
	 pkt_num_14 = 0;
	 pkt_num_15 = 0;
	 pkt_num_16 = 0;
	 pkt_num_17 = 0;
	 pkt_num_18 = 0;
	 pkt_num_19 = 0;
	 pkt_num_20 = 0;

	 pkt_num_21 = 0;
	 pkt_num_22 = 0;
	 pkt_num_23 = 0;
	 pkt_num_24 = 0;
	 pkt_num_25 = 0;
	 pkt_num_26 = 0;
	 pkt_num_27 = 0;
	 pkt_num_28 = 0;
	 pkt_num_29 = 0;
	 pkt_num_30 = 0;

	 pkt_num_31 = 0;
	 pkt_num_32 = 0;
	 pkt_num_33 = 0;
	 pkt_num_34 = 0;
	 pkt_num_35 = 0;
	 pkt_num_36 = 0;
	 pkt_num_37 = 0;
	 pkt_num_38 = 0;
	 pkt_num_39 = 0;
	 pkt_num_40 = 0;

	 pkt_num_41 = 0;
	 pkt_num_42 = 0;
	 pkt_num_43 = 0;
	 pkt_num_44 = 0;
	 pkt_num_45 = 0;
	 pkt_num_46 = 0;
	 pkt_num_47 = 0;
	 pkt_num_48 = 0;
	 pkt_num_49 = 0;
	 pkt_num_50 = 0;

	 pkt_num_51 = 0;
	 pkt_num_52 = 0;
	 pkt_num_53 = 0;
	 pkt_num_54 = 0;
	 pkt_num_55 = 0;
	 pkt_num_56 = 0;
	 pkt_num_57 = 0;
	 pkt_num_58 = 0;
	 pkt_num_59 = 0;
	 pkt_num_60 = 0;



	 pkt_num_61 = 0;
	 pkt_num_62 = 0;
	 pkt_num_63 = 0;
	 pkt_num_64 = 0;
	 pkt_num_65 = 0;
	 pkt_num_66 = 0;
	 pkt_num_67 = 0;
	 pkt_num_68 = 0;
	 pkt_num_69 = 0;
	 pkt_num_70 = 0;

	 pkt_num_71 = 0;
	 pkt_num_72 = 0;
	 pkt_num_73 = 0;
	 pkt_num_74 = 0;
	 pkt_num_75 = 0;
	 pkt_num_76 = 0;
	 pkt_num_77 = 0;
	 pkt_num_78 = 0;
	 pkt_num_79 = 0;
	 pkt_num_80 = 0;

	 pkt_num_81 = 0;
	 pkt_num_82 = 0;
	 pkt_num_83 = 0;
	 pkt_num_84 = 0;
	 pkt_num_85 = 0;
	 pkt_num_86 = 0;
	 pkt_num_87 = 0;
	 pkt_num_88 = 0;
	 pkt_num_89 = 0;
	 pkt_num_90 = 0;



	 pkt_num_91 = 0;
	 pkt_num_92 = 0;
	 pkt_num_93 = 0;
	 pkt_num_94 = 0;
	 pkt_num_95 = 0;
	 pkt_num_96 = 0;
	 pkt_num_97 = 0;
	 pkt_num_98 = 0;
	 pkt_num_99 = 0;


}

//int
//More::ExOR_schedule(int sender, int receiver)
//{
//
//	if(newBatchIndex == 1)
//	{
//		return 2;
//	}
//	//                                     up wait  + down wait
//	if(sender == 0 && receiver == 1) return 0 + 5;
//	if(sender == 0 && receiver == 2) return 0 + 4;
//	if(sender == 0 && receiver == 3) return 0 + 3;
//	if(sender == 0 && receiver == 4) return 0 + 2;
//	if(sender == 0 && receiver == 5) return 0 + 1;
//	if(sender == 0 && receiver == 6) return 0 + 0;
//
//
//	if(sender == 1 && receiver == 0) return 0;
//	if(sender == 1 && receiver == 2) return 1 + 5;
//	if(sender == 1 && receiver == 3) return 1 + 4;
//	if(sender == 1 && receiver == 4) return 1 + 3;
//	if(sender == 1 && receiver == 5) return 1 + 2;
//	if(sender == 1 && receiver == 6) return 1 + 1;
//	if(sender == 1 && receiver == 7) return 1 + 0;
//
//	if(sender == 2 && receiver == 0) return 1 + 0;
//	if(sender == 2 && receiver == 1) return 0;
//	if(sender == 2 && receiver == 3) return 2 + 4;
//	if(sender == 2 && receiver == 4) return 2 + 3;
//	if(sender == 2 && receiver == 5) return 2 + 2;
//	if(sender == 2 && receiver == 6) return 2 + 1;
//	if(sender == 2 && receiver == 7) return 2 + 0;
//
//	if(sender == 3 && receiver == 0) return 2;
//	if(sender == 3 && receiver == 1) return 1;
//	if(sender == 3 && receiver == 2) return 0;
//	if(sender == 3 && receiver == 4) return 3 + 3;
//	if(sender == 3 && receiver == 5) return 3 + 2;
//	if(sender == 3 && receiver == 6) return 3 + 1;
//	if(sender == 3 && receiver == 7) return 3 + 0;
//
//
//	if(sender == 4 && receiver == 0) return 3;
//	if(sender == 4 && receiver == 1) return 2;
//	if(sender == 4 && receiver == 2) return 1;
//	if(sender == 4 && receiver == 3) return 0;
//	if(sender == 4 && receiver == 5) return 4 + 2;
//	if(sender == 4 && receiver == 6) return 4 + 1;
//	if(sender == 4 && receiver == 7) return 4 + 0;
//
//	if(sender == 5 && receiver == 0) return 4;
//	if(sender == 5 && receiver == 1) return 3;
//	if(sender == 5 && receiver == 2) return 2;
//	if(sender == 5 && receiver == 3) return 1;
//	if(sender == 5 && receiver == 4) return 0;
//	if(sender == 5 && receiver == 6) return 5 + 1;
//	if(sender == 5 && receiver == 7) return 5 + 0;
//
//	if(sender == 6 && receiver == 0) return 5;
//	if(sender == 6 && receiver == 1) return 4;
//	if(sender == 6 && receiver == 2) return 3;
//	if(sender == 6 && receiver == 3) return 2;
//	if(sender == 6 && receiver == 4) return 1;
//	if(sender == 6 && receiver == 5) return 0;
//	if(sender == 6 && receiver == 7) return 6 + 0;
//
//	if(sender == 7 && receiver == 0) return 6;
//	if(sender == 7 && receiver == 1) return 5;
//	if(sender == 7 && receiver == 2) return 4;
//	if(sender == 7 && receiver == 3) return 3;
//	if(sender == 7 && receiver == 4) return 2;
//	if(sender == 7 && receiver == 5) return 1;
//	if(sender == 7 && receiver == 6) return 0;
//
//	return 10;
//
//}


int
More::ExOR_schedule(int sender, int receiver)
{

	if(newBatchIndex == 1)
	{
		return 2;
	}
	//                                     up wait  + down wait
	if(sender == 0 && receiver == 2) return 0 + 6;
	if(sender == 0 && receiver == 5) return 0 + 5;



	if(sender == 2 && receiver == 5) return 1+ 3;
	if(sender == 2 && receiver == 8) return 1+ 4;
	if(sender == 2 && receiver == 0) return 0;


	if(sender == 5 && receiver == 11) return 2 + 3;
	if(sender == 5 && receiver == 8) return 2 + 4;
	if(sender == 5 && receiver == 2) return 0;
	if(sender == 5 && receiver == 0) return 1;


	if(sender == 8 && receiver == 14) return 3 + 2;
	if(sender == 8 && receiver == 11) return 3 + 3;
	if(sender == 8 && receiver == 5) return 0;
	if(sender == 8 && receiver == 2) return 1;

	if(sender == 11 && receiver == 17) return 4 + 1;
	if(sender == 11 && receiver == 14) return 4 + 2;
	if(sender == 11 && receiver == 8) return 0;
	if(sender == 11 && receiver == 5) return 1;

	if(sender == 14 && receiver == 19) return 5 + 0;
	if(sender == 14 && receiver == 17) return 5 + 1;
	if(sender == 14 && receiver == 11) return 0;
	if(sender == 14 && receiver == 8) return 1;

	if(sender == 17 && receiver == 19) return 6 + 0;
	if(sender == 17 && receiver == 14) return 0;
	if(sender == 17 && receiver == 11) return 1;


	if(sender == 19 && receiver == 17) return 0;
	if(sender == 19 && receiver == 14) return 1;


	return 10;

}


//timer function


void
More::WaitForReceivingNewpacketsFinishTimerHandler()
{
    printf("index == %d WaitForReceivingNewpacketsFinishTimerHandler timer expired\n",index);

    Original();


    if(wrNewfTimer.busy())
    {
    	 wrNewfTimer.stop();
    	 wrNewfTimer.start(0.05);
    }
    else
    {
        wrNewfTimer.start(0.05);
    }
}


void
More::WaitForHighPrioritySendingTimerHandler()
{
	printf("index == %d WaitForHighPrioritySendingTimerHandler\n",index);
	printf("CURRENT_TIME == %f WaitForHighPrioritySendingTimerHandler\n",CURRENT_TIME);

	printf("newBatchIndex == %d newBatchIndex\n",newBatchIndex);

	if(index !=19 && index !=0)
	intermediates_send_dataPackets();
	else if(index == 0)
	{
		if(newBatchIndex == 1)
		{
			source_send_newDataPacket();
			newBatchIndex = 0;
		}
		else
		{
			source_send_dataPackets();
		}
	}
	else if(index == 19)
	destination_send_ACKPackets(0);

}

void
More::WaitForReceivingACKpacketsFinishTimerHandler()
{

}

void
More::DectinationACKWaitingTimerHandler()
{
	// this is used by nodes to increase Unack packets
	//destination_send_ACKPackets(0);
}

void
More::resetNewPacketTimer()
{
    printf("resetNewPacketTimer\n");


    wrNewfTimer.start(0.008);


    printf("resetNewPacketTimer done\n");
}

void
More::resetDestinationACKTimer(Packet* p)
{

    printf("resetDestinationACKTimer  at index ==%d\n",index);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    struct hdr_cmn* ch = HDR_CMN(p);

    int cur_num = ph->cur_wait_num-1;
    double backtime = cur_num*onePacketSendingDelay;

    if(destionACKTimer.busy())
    {
    	destionACKTimer.stop();
    	destionACKTimer.start(backtime);
    }
    else
    {
    	destionACKTimer.start(backtime);
    }
}



void
More::resetSendTimer()
{
	// after sending packet, how long it need to wait
	int backoff = op.sendTransmissionTime(index);
	double backtime = backoffpacketNum*backoff*onePacketSendingDelay;

    if(wHighpsTimer.busy())
    {
    	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
    			- Scheduler::instance().clock();
    	wHighpsTimer.stop();

    	if(needwait < backtime) wHighpsTimer.start(backtime);
    	else wHighpsTimer.start(needwait);
    }
    else
    {
		wHighpsTimer.start(backtime);
    }
}

void
More::resetOverhearHighPriorityTimer(const Packet* p,int ReceiverIndex)
{
    printf("resetOverhearHighPriorityTimer  at index ==%d\n",index);

    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);

    int cur_num = ph->cur_wait_num;

    int backoff = op.getBackoffTime(p,ReceiverIndex);

    double backtime = backoffpacketNum*backoff*onePacketSendingDelay;

    if(wHighpsTimer.busy())
    {
    	double needwait = (wHighpsTimer.stime + wHighpsTimer.rtime)
    	    			- Scheduler::instance().clock();
		wHighpsTimer.stop();
//    	if(needwait < backtime) wHighpsTimer.start(needwait);
//    	else
    	wHighpsTimer.start(backtime);
    }
    else
    {
		wHighpsTimer.start(backtime);
    }
}

void
More::resetHighPriorityTimer(Packet* p,int ReceiverIndex)
{
	// after received packet, how long it needs to wait
    printf("resetHighPriorityTimer  at index ==%d\n",index);
    struct hdr_more_pkt* ph = HDR_MORE_PKT(p);
    struct hdr_cmn* ch = HDR_CMN(p);

    int cur_num = ph->cur_wait_num;
    printf("cur_num backoff time = %d\n",cur_num);
    int backoff = ExOR_schedule(ch->prev_hop_,index);
    printf("resetHighPriorityTimer backoff backoff = %d\n",backoff);
    double backtime = backoffpacketNum*backoff*onePacketSendingDelay+
    		cur_num*onePacketSendingDelay+2*onePacketSendingDelay;


    printf("resetHighPriorityTimer backoff time = %f\n",backoffpacketNum*backoff*onePacketSendingDelay);

    printf("resetHighPriorityTimer backoff time = %f\n",backtime);

    printf("CURRENT_TIME == %f resetHighPriorityTimer\n",CURRENT_TIME);
    if(wHighpsTimer.busy())
    {
    	wHighpsTimer.stop();
        wHighpsTimer.start(backtime);
     }
     else
     {
    	wHighpsTimer.start(backtime);
     }

}



//testing function
void
More::printPacketContent(Packet* packetObj)
{
    PacketData* packdata_1 = (PacketData*)packetObj->userdata();

    unsigned char* data_for_add_1 = (unsigned char*)packdata_1->data();

     printf("printPacketContent	 data: ");
     for(int i=0;i<512;i++)
     {
    	 if(i <10)printf("%d-",*data_for_add_1);
    	 data_for_add_1++;
     }

//     printf("	encoding vector");
//     for(int i=0;i<codeingPacketNumber;i++)
//     {
//    	 printf("%d-",*data_for_add_1);
//    	 data_for_add_1++;
//     }

     printf("\n");
}

/*
 * more_nc.h
 *
 *  Created on: Feb 24, 2014
 *      Author: chenzhang
 */

#ifndef MORE_NC_H_
#define MORE_NC_H_

#include <ip.h>
#include <agent.h>
#include "more_rqueue.h"

class More_nc
{
public:
	More_nc();
	unsigned int generationSize;
	unsigned int symbolNumber;
	static const unsigned int symbolSize = 8;
	static const unsigned int divisor = 1;
	static const int LengthofMaxSymbol=32;


//encoding
	uint8_t multiplyFunction(uint8_t a,uint8_t b);
	void maintainRowEchelon();
	unsigned char* getRandomEncodingVector(unsigned int symbolSize_,unsigned int packetNumber_);
	Packet* encodingPacket(unsigned char encoding,unsigned int packetNumber_, Packet* originalPacket,int packetLength,int position);
	more_rqueue enqueCodedPacket(Packet* p,unsigned int packetNumber_,int packetLength,more_rqueue rqueue,more_rqueue rqueue_send);
	more_rqueue enqueAllCodedPacketInQueueToOneCodedPacket(unsigned int packetNumber_,int packetLength,more_rqueue receive_queue,more_rqueue rqueue_send);
	Packet* addTwoPackets(Packet*p1, Packet*p2,unsigned int packetNumber_,int packetLength);
	Packet* encodingPacketByCoefficient(Packet*p1,unsigned int packetNumber_,int packetLength);

//decoding
	unsigned char getInverseValue(unsigned char inputValue);
	Packet*	multipleAPacketByCoefficient(Packet*p,int packetNumber_,int packetLength,unsigned char encoding);
	Packet*	minusOrAddTwoPacketsTogtherReturnTheFirstPacket(Packet*p1,Packet*p2,int packetNumber_,int packetLength);
	int getTheFirstNotNullValueOfCoefficientPosition(Packet*p,int packetNumber_,int packetLength);
	Packet*	setFirstNotNullValuesOfCoefficientToOneByMultiplyInverseValueForWholePacket(Packet*p,unsigned char inverseValue,int packetNumber_,int packetLength);
	more_rqueue changePositionOfQueueBasedOnFirstNotNullValueOfCoefficient(more_rqueue receiveQueue,int packetNumber_,int packetLength,Packet* newPacket);
	more_rqueue changeValueOfQueueBasedOnOthersFirstNotNullValueOfCoefficient(more_rqueue receiveQueue,int packetNumber_,int packetLength,Packet* newPacket);

	unsigned char getCoefficientByCoefficientPosition(Packet* p,int position,int packetNumber_,int packetLength);
	more_rqueue createReduceRowEchelon(more_rqueue receiveQueue,int packetNumber_,int packetLength,Packet* newPacket);
	Packet* insertNewReceiveCodedPacket(Packet*newPacket,more_rqueue receiveQueue,int packetNumber_,int packetLength);
	Packet* enqueCodedPacket(unsigned int packetNumber_,int packetLength,more_rqueue rqueue_send);
	int queueLength(more_rqueue receiveQueue,unsigned int packetNumber_,int packetLength);
	int* testPoint(int* a);

};

#endif /* MORE_NC_H_ */
